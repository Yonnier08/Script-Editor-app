using System.Collections.Generic;
using System.IO;

namespace EditMode.Diva2nd;

public class EditPvCommand
{
	public Opcode Opcode { get; set; }

	public List<int> Parameters { get; set; } = new List<int>();


	private string FormatParameters()
	{
		return string.Join(", ", Parameters);
	}

	private void ParseParameters(BinaryReader reader, int shortCount, int intCount)
	{
		for (int i = 0; i < shortCount; i++)
		{
			Parameters.Add(reader.ReadInt16());
		}
		for (int j = 0; j < intCount; j++)
		{
			Parameters.Add(reader.ReadInt32());
		}
	}

	public EditPvCommand()
	{
	}

	public EditPvCommand(BinaryReader reader, Opcode opcode)
	{
		ParseCommand(reader, opcode);
	}

	public void ParseCommand(BinaryReader reader, Opcode opcode)
	{
		Opcode = opcode;
		switch (opcode)
		{
		case Opcode.TIME:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.CHANGE_FIELD:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.HIDE_FIELD:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.EDIT_MOTION:
			ParseParameters(reader, 0, 4);
			break;
		case Opcode.EDIT_FACE:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.MOVE_CAMERA:
			ParseParameters(reader, 2, 20);
			break;
		case Opcode.EDIT_LYRIC:
			ParseParameters(reader, 0, 2);
			break;
		case Opcode.EDIT_TARGET:
			ParseParameters(reader, 0, 5);
			break;
		case Opcode.EDIT_MOUTH:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.SET_CHARA:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.EDIT_MOVE:
			ParseParameters(reader, 2, 6);
			break;
		case Opcode.EDIT_SHADOW:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.EDIT_EYELID:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.EDIT_EYE:
			ParseParameters(reader, 0, 2);
			break;
		case Opcode.EDIT_ITEM:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.EDIT_EFFECT:
			ParseParameters(reader, 0, 2);
			break;
		case Opcode.EDIT_DISP:
			ParseParameters(reader, 0, 1);
			break;
		case Opcode.EDIT_BLUSH:
			ParseParameters(reader, 0, 1);
			break;
		}
	}

	public override string ToString()
	{
		return $"{Opcode}({FormatParameters()})";
	}
}
