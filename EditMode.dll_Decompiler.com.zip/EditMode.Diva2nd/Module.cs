namespace EditMode.Diva2nd;

public enum Module
{
	none = -1
}
