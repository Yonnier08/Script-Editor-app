using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace EditMode.Diva2nd;

public class Edit
{
	private readonly Encoding Encoding = Encoding.GetEncoding(932);

	public const int BEATS_PER_BAR = 8;

	public const int BAR_COUNT = 600;

	public const int LYRICS_LENGTH = 41;

	private int RECENT_BPM;

	private List<int> changeBars = new List<int>();

	public string EditName { get; set; } = string.Empty;


	public string SongName { get; set; } = string.Empty;


	public float StartTime { get; set; }

	public Module Module1 { get; set; } = Module.none;


	public Module Module2 { get; set; } = Module.none;


	public TimeSpan StartTimeSpan => TimeSpan.FromSeconds(StartTime);

	public int SongEndBeat { get; set; } = 4800;


	public SeName ButtonSound { get; set; }

	public List<Stage> Stages { get; set; } = new List<Stage>();


	public List<Effect> Effects { get; set; } = new List<Effect>();


	public List<HandItem> HandItems { get; set; } = new List<HandItem>();


	public List<Motion> Motions { get; set; } = new List<Motion>();


	public List<string> Lyrics { get; set; } = new List<string>(600);


	public List<(int bpm, int bar)> BpmChanges { get; set; } = new List<(int, int)>(600);


	public List<(int sig, int bar)> SigChanges { get; set; } = new List<(int, int)>(600);


	public List<EditPvCommand> PvCommands { get; set; } = new List<EditPvCommand>();


	public TimeSpan[] TimelineTimes { get; private set; }

	public double increment2 { get; set; }

	public Edit()
	{
	}

	public Edit(string filePath)
	{
		LoadFromFile(filePath);
		CalculateTimelineTimes();
	}

	public void CalculateTimelineTimes()
	{
		TimelineTimes = new TimeSpan[4800];
		double num = 0.0;
		for (int i = 1; i < TimelineTimes.Length; i++)
		{
			double num3 = (increment2 = 240.0 / (double)GetBpmAt(i) * 1000.0 / 8.0);
			num += num3;
			Console.WriteLine(num3);
			TimelineTimes[i] = TimeSpan.FromMilliseconds(double.IsInfinity(num) ? 0.0 : num);
		}
	}

	public float GetBpmAt(int totalBeat)
	{
		if (BpmChanges.Count < 1)
		{
			return 0f;
		}
		if (BpmChanges.Count == 1)
		{
			return BpmChanges[0].bpm;
		}
		int index = (totalBeat - 1) / 8;
		Console.WriteLine(BpmChanges[index].bpm);
		return BpmChanges[index].bpm;
	}

	public TimeSpan GetTimeAt(int totalBeat)
	{
		try
		{
			if (TimelineTimes == null)
			{
				return TimeSpan.Zero;
			}
			if (totalBeat < 0)
			{
				totalBeat = 0;
			}
			else if (totalBeat > TimelineTimes.Length - 1)
			{
				totalBeat = TimelineTimes.Length - 1;
			}
			return TimelineTimes[totalBeat];
		}
		catch (Exception)
		{
			return TimeSpan.Zero;
		}
	}

	public double GetTimeFrom(int lastBeat, int duration)
	{
		try
		{
			return GetTimeAt(lastBeat + duration).TotalMilliseconds - GetTimeAt(lastBeat).TotalMilliseconds;
		}
		catch (Exception)
		{
			return 0.0;
		}
	}

	private void LoadFromFile(string filePath)
	{
		LoadFromStream(File.OpenRead(filePath));
	}

	private void LoadFromStream(Stream stream)
	{
		using BinaryReader binaryReader = new BinaryReader(stream);
		binaryReader.Seek(57608L);
		ParsePvCommands(binaryReader);
		binaryReader.Seek(180908L);
		ParseLyrics(binaryReader);
		binaryReader.Seek(210908L);
		ParseBpmChanges(binaryReader);
		ParseSigChanges(binaryReader);
		binaryReader.Seek(218108L);
		SongEndBeat = binaryReader.ReadInt32() * 8;
		Module1 = (Module)binaryReader.ReadInt32();
		Module2 = (Module)binaryReader.ReadInt32();
		binaryReader.Seek(218120L);
		ParseStages(binaryReader);
		ParseMotions(binaryReader);
		ButtonSound = (SeName)binaryReader.ReadInt32();
		ParseHandItems(binaryReader);
		ParseEffects(binaryReader);
		ParseEditInfo(binaryReader);
	}

	private void ParsePvCommands(BinaryReader reader)
	{
		for (int i = 0; i < 32767; i++)
		{
			Opcode opcode = (Opcode)reader.ReadInt32();
			if (!Enum.IsDefined(typeof(Opcode), opcode))
			{
				break;
			}
			PvCommands.Add(new EditPvCommand(reader, opcode));
		}
	}

	private void ParseLyrics(BinaryReader reader)
	{
		for (int i = 0; i < 600; i++)
		{
			string text = ParseString(reader, 41);
			if (!string.IsNullOrEmpty(text))
			{
				Lyrics.Add(text);
			}
		}
	}

	private void ParseBpmChanges(BinaryReader reader)
	{
		List<int> list = new List<int>(600);
		for (int i = 0; i < 600; i++)
		{
			int num = reader.ReadInt32();
			if (num >= 60)
			{
				list.Add(num);
			}
			else
			{
				list.Add(list.LastOrDefault());
			}
		}
		for (int j = 0; j < 600; j++)
		{
			changeBars.Add(reader.ReadInt32());
		}
		for (int k = 0; k < list.Count; k++)
		{
			BpmChanges.Add((list[k], changeBars[k]));
		}
	}

	private void ParseSigChanges(BinaryReader reader)
	{
		for (int i = 0; i < 600; i++)
		{
			int num = reader.ReadInt32();
			if (num != -1)
			{
				SigChanges.Add((num, changeBars[i]));
			}
		}
	}

	private void ParseStages(BinaryReader reader)
	{
		for (int i = 0; i < 20; i++)
		{
			int num = reader.ReadInt32();
			if (num != -1)
			{
				Stages.Add((Stage)num);
			}
		}
	}

	private void ParseMotions(BinaryReader reader)
	{
		for (int i = 0; i < 30; i++)
		{
			int num = reader.ReadInt32();
			if (num != -1)
			{
				Motions.Add((Motion)num);
			}
		}
	}

	private void ParseHandItems(BinaryReader reader)
	{
		for (int i = 0; i < 9; i++)
		{
			int num = reader.ReadInt32();
			if (num != -1)
			{
				HandItems.Add((HandItem)num);
			}
		}
	}

	private void ParseEffects(BinaryReader reader)
	{
		for (int i = 0; i < 11; i++)
		{
			int num = reader.ReadInt32();
			if (num != -1)
			{
				Effects.Add((Effect)num);
			}
		}
	}

	private void ParseEditInfo(BinaryReader reader)
	{
		EditName = ParseString(reader, 40);
		reader.ReadInt32();
		SongName = ParseString(reader, 40);
		reader.ReadInt32();
		StartTime = reader.ReadSingle();
	}

	private string ParseString(BinaryReader reader, int length)
	{
		return Encoding.GetString(reader.ReadBytes(length)).TrimEnd(new char[1]);
	}
}
