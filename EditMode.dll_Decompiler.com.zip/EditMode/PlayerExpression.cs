using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerExpression
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Unknown1 { get; set; }

	[FieldOrder(2)]
	public byte Unknown2 { get; set; }

	[FieldOrder(3)]
	public byte Unknown3 { get; set; }

	[FieldOrder(4)]
	public byte Unknown4 { get; set; }

	[FieldOrder(5)]
	public Expression ExpressionID { get; set; }

	[FieldOrder(6)]
	public uint Interpolation { get; set; }
}
