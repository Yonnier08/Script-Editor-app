using System;
using System.IO;
using System.Text;

namespace EditMode;

public static class BinaryHelper
{
	public static void Seek(this BinaryReader binaryReader, long position, SeekOrigin seekOrigin = SeekOrigin.Begin)
	{
		if (position >= 0 && position <= binaryReader.GetLength())
		{
			binaryReader.BaseStream.Seek(position, seekOrigin);
		}
	}

	public static long GetPosition(this BinaryReader binaryReader)
	{
		return binaryReader.BaseStream.Position;
	}

	public static long GetLength(this BinaryReader binaryReader)
	{
		return binaryReader.BaseStream.Length;
	}

	public static int GetStringLength(this BinaryReader binaryReader)
	{
		long position = binaryReader.GetPosition();
		int num = 0;
		while (binaryReader.GetPosition() < binaryReader.GetLength() && binaryReader.ReadByte() != 0)
		{
			num++;
		}
		binaryReader.Seek(position);
		return num;
	}

	public static string ReadAsciiString(this BinaryReader binaryReader)
	{
		int stringLength = binaryReader.GetStringLength();
		return Encoding.ASCII.GetString(binaryReader.ReadBytes(stringLength));
	}

	public static (int pointer, int value) ReadInt32Ptr(this BinaryReader binaryReader, SeekOrigin seekOrigin = SeekOrigin.Begin)
	{
		long position = binaryReader.GetPosition();
		int num = binaryReader.ReadInt32();
		binaryReader.Seek(num, seekOrigin);
		int item = binaryReader.ReadInt32();
		binaryReader.Seek(position + 4);
		return (pointer: num, value: item);
	}

	public static (int pointer, string value) ReadStringPtr(this BinaryReader binaryReader, SeekOrigin seekOrigin = SeekOrigin.Begin)
	{
		long position = binaryReader.GetPosition();
		int num = binaryReader.ReadInt32();
		binaryReader.Seek(num, seekOrigin);
		string item = binaryReader.ReadAsciiString();
		binaryReader.Seek(position + 4);
		return (pointer: num, value: item);
	}

	public static (float x, float y) ReadVector2(this BinaryReader binaryReader)
	{
		return (x: binaryReader.ReadSingle(), y: binaryReader.ReadSingle());
	}

	public static short ReadStaticInt16(this BinaryReader binaryReader)
	{
		int num = binaryReader.ReadInt16();
		binaryReader.Seek(-2L, SeekOrigin.Current);
		return (short)num;
	}

	public static int ReadStaticInt32(this BinaryReader binaryReader)
	{
		int result = binaryReader.ReadInt32();
		binaryReader.Seek(-4L, SeekOrigin.Current);
		return result;
	}

	public static long ReadStaticInt64(this BinaryReader binaryReader)
	{
		long result = binaryReader.ReadInt64();
		binaryReader.Seek(-8L, SeekOrigin.Current);
		return result;
	}

	public static float ReadStaticSingle(this BinaryReader binaryReader)
	{
		double num = binaryReader.ReadSingle();
		binaryReader.Seek(-4L, SeekOrigin.Current);
		return (float)num;
	}

	public static double ReadStaticDouble(this BinaryReader binaryReader)
	{
		double result = binaryReader.ReadDouble();
		binaryReader.Seek(-8L, SeekOrigin.Current);
		return result;
	}

	public static byte ReadStaticByte(this BinaryReader binaryReader)
	{
		int num = binaryReader.ReadByte();
		binaryReader.Seek(-1L, SeekOrigin.Current);
		return (byte)num;
	}

	public static byte[] ReadStaticBytes(this BinaryReader binaryReader, int count)
	{
		byte[] result = binaryReader.ReadBytes(count);
		binaryReader.Seek(-count, SeekOrigin.Current);
		return result;
	}

	public static string ReadFormattedBytes(this BinaryReader binaryReader, int count)
	{
		return BitConverter.ToString(binaryReader.ReadBytes(count));
	}

	public static string ReadFormattedBytes(this BinaryReader binaryReader, int count, int chunks)
	{
		string[] array = new string[chunks];
		for (int i = 0; i < chunks; i++)
		{
			array[i] = binaryReader.ReadFormattedBytes(count);
		}
		return string.Join(" ", array);
	}
}
