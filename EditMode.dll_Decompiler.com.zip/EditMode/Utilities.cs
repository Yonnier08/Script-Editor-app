using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EditMode;

public class Utilities
{
	private const float PositionMultiplier = 362.5f;

	private const float PVTimeMultiplier = 1666.666f;

	public static uint CalculatePVTime(uint timestamp)
	{
		return Convert.ToUInt32((float)timestamp / 1666.666f);
	}

	public static float CalculateTargetPosition(uint position)
	{
		return (float)position / 362.5f;
	}

	public static float CalculateAngle(int angle)
	{
		return (angle + 5000) / 1000;
	}

	public static byte[] GetBytes(string inputString, int length, Encoding encoding)
	{
		byte[] bytes = Encoding.BigEndianUnicode.GetBytes(inputString);
		if (encoding == Encoding.ASCII)
		{
			bytes = Encoding.ASCII.GetBytes(inputString);
		}
		else if (encoding == Encoding.Unicode)
		{
			bytes = Encoding.BigEndianUnicode.GetBytes(inputString);
		}
		else if (encoding == Encoding.UTF8)
		{
			bytes = Encoding.UTF8.GetBytes(inputString);
		}
		List<byte> list = new List<byte>();
		for (byte b = 0; b < length; b++)
		{
			try
			{
				list.Add(bytes.ElementAt(b));
			}
			catch (Exception)
			{
				list.Add(0);
			}
		}
		byte[] array = new byte[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = list[i];
		}
		return array;
	}

	public static string GetString(byte[] bytes, Encoding encoding)
	{
		if (encoding == Encoding.UTF8)
		{
			return Encoding.UTF8.GetString(bytes).Trim(new char[1]);
		}
		if (encoding == Encoding.Unicode)
		{
			string text = Encoding.BigEndianUnicode.GetString(bytes).TrimEnd(new char[1]);
			if (text.Length > 0 && (char.IsControl(text[0]) || text.Contains("\ufffd")))
			{
				text = Encoding.Unicode.GetString(bytes).TrimEnd(new char[1]);
			}
			return text;
		}
		return (encoding == Encoding.ASCII) ? Encoding.ASCII.GetString(bytes).Trim(new char[1]) : "ERROR";
	}

	private static bool ContainsJapanese(string text)
	{
		foreach (char c in text)
		{
			if ((c >= '\u3040' && c <= 'ゟ') || (c >= '゠' && c <= 'ヿ') || (c >= '一' && c <= '\u9fff'))
			{
				return true;
			}
		}
		return false;
	}
}
