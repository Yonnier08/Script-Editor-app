using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class Edit
{
	[FieldOrder(33)]
	[FieldLength(38uL)]
	public byte[] editCreator = new byte[38];

	[FieldOrder(34)]
	[FieldLength(182uL)]
	public byte[] audioSource = new byte[182];

	[FieldOrder(35)]
	[FieldLength(194uL)]
	public byte[] editComment = new byte[194];

	[FieldOrder(36)]
	[FieldLength(64uL)]
	public byte[] songFile = new byte[62];

	[FieldOrder(44)]
	[FieldLength(150uL)]
	public byte[] mp3Name = new byte[150];

	[FieldOrder(46)]
	[FieldLength(74uL)]
	public byte[] editTitle = new byte[74];

	[FieldOrder(0)]
	[FieldLength(4uL)]
	public byte[] Magic { get; set; } = new byte[4] { 0, 0, 0, 100 };


	[FieldOrder(1)]
	public RegionValue RegionValue { get; set; } = RegionValue.JPN;


	[FieldOrder(2)]
	public uint Crc32Checksum { get; set; }

	[FieldOrder(3)]
	public uint Crc32ChecksumRange { get; set; }

	[FieldOrder(4)]
	public RegionValue RegionValue2 { get; set; } = RegionValue.JPN;


	[FieldOrder(5)]
	public uint EditDataSize { get; set; }

	[FieldOrder(6)]
	public uint TableSize { get; set; } = 1576u;


	[FieldOrder(7)]
	public float DisplayBpm { get; set; }

	[FieldOrder(8)]
	public Skins Skin { get; set; }

	[FieldOrder(9)]
	public Module Module1 { get; set; }

	[FieldOrder(10)]
	public Module Module2 { get; set; } = Module.なし;


	[FieldOrder(11)]
	public Module Module3 { get; set; } = Module.なし;


	[FieldOrder(12)]
	public ushort SongBase { get; set; } = 754;


	[FieldOrder(13)]
	public byte EditDifficulty { get; set; }

	[FieldOrder(14)]
	[FieldLength(35uL)]
	public byte[] EditMisc1 { get; set; } = new byte[35];


	[FieldOrder(15)]
	public int PvEnd { get; set; } = 72000;


	[FieldOrder(16)]
	public CustomizeItem Module1Face { get; set; } = CustomizeItem.縁なしメガネ_赤;


	[FieldOrder(17)]
	public CustomizeItem Module1Head { get; set; }

	[FieldOrder(18)]
	public CustomizeItem Module1Chest { get; set; }

	[FieldOrder(19)]
	public CustomizeItem Module1Back { get; set; }

	[FieldOrder(20)]
	public CustomizeItem Module2Face { get; set; }

	[FieldOrder(21)]
	public CustomizeItem Module2Head { get; set; }

	[FieldOrder(22)]
	public CustomizeItem Module2Chest { get; set; }

	[FieldOrder(23)]
	public CustomizeItem Module2Back { get; set; }

	[FieldOrder(24)]
	public CustomizeItem Module3Face { get; set; }

	[FieldOrder(25)]
	public CustomizeItem Module3Head { get; set; }

	[FieldOrder(26)]
	public CustomizeItem Module3Chest { get; set; }

	[FieldOrder(27)]
	public CustomizeItem Module3Back { get; set; }

	[FieldOrder(28)]
	[FieldLength(8uL)]
	public int[] EditMisc2 { get; set; } = new int[2] { -1, -1 };


	[FieldOrder(29)]
	public uint EditPassword { get; set; }

	[FieldOrder(30)]
	[FieldLength(24uL)]
	public byte[] EditMisc3 { get; set; } = new byte[24]
	{
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 76, 111, 192
	};


	[FieldOrder(31)]
	public float SongStartTime { get; set; }

	[FieldOrder(32)]
	[FieldLength(38uL)]
	public byte[] EditMisc4 { get; set; } = new byte[38];


	[Ignore]
	public string EditCreator
	{
		get
		{
			return Utilities.GetString(editCreator, Encoding.Unicode);
		}
		set
		{
			editCreator = Utilities.GetBytes(value, 38, Encoding.Unicode);
		}
	}

	[Ignore]
	public string AudioSource
	{
		get
		{
			return Utilities.GetString(audioSource, Encoding.Unicode);
		}
		set
		{
			audioSource = Utilities.GetBytes(value, 182, Encoding.Unicode);
		}
	}

	[Ignore]
	public string EditComment
	{
		get
		{
			return Utilities.GetString(editComment, Encoding.Unicode);
		}
		set
		{
			editComment = Utilities.GetBytes(value, 194, Encoding.Unicode);
		}
	}

	[Ignore]
	public string SongFile
	{
		get
		{
			return Utilities.GetString(songFile, Encoding.Unicode);
		}
		set
		{
			songFile = Utilities.GetBytes(value, 64, Encoding.Unicode);
		}
	}

	[FieldOrder(37)]
	public byte ButtonSound { get; set; }

	[FieldOrder(38)]
	public byte HoldSound { get; set; }

	[FieldOrder(39)]
	public byte ArrowSound { get; set; }

	[FieldOrder(40)]
	public byte StarSound { get; set; }

	[FieldOrder(41)]
	public byte DoubleStarSound { get; set; }

	[FieldOrder(42)]
	public byte LinkedSound { get; set; }

	[FieldOrder(43)]
	[FieldLength(140uL)]
	public byte[] Unknown { get; set; } = new byte[142]
	{
		0, 0, 0, 0, 1, 112, 118, 95, 55, 53,
		52, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0
	};


	[Ignore]
	public string Mp3Name
	{
		get
		{
			return Utilities.GetString(mp3Name, Encoding.Unicode);
		}
		set
		{
			mp3Name = Utilities.GetBytes(value, 150, Encoding.Unicode);
		}
	}

	[FieldOrder(45)]
	[FieldLength(84uL)]
	public byte[] UnknownString { get; set; } = new byte[84];


	[Ignore]
	public string EditTitle
	{
		get
		{
			return Utilities.GetString(editTitle, Encoding.Unicode);
		}
		set
		{
			editTitle = Utilities.GetBytes(value, 74, Encoding.Unicode);
		}
	}

	[FieldOrder(47)]
	[FieldLength(450uL)]
	public byte[] UnknownEmpty { get; set; } = new byte[450];


	[FieldOrder(48)]
	public int BpmChangesCount { get; set; }

	[FieldOrder(49)]
	[FieldCount("BpmChangesCount")]
	public List<BpmChange> BPMChanges { get; set; } = new List<BpmChange>();


	[FieldOrder(50)]
	public int TimeSigChangesCount { get; set; }

	[FieldOrder(51)]
	[FieldCount("TimeSigChangesCount")]
	public List<TimeSigChange> TimeSigChanges { get; set; } = new List<TimeSigChange>();


	[FieldOrder(52)]
	public int MarkersCount { get; set; }

	[FieldOrder(53)]
	[FieldCount("MarkersCount")]
	public List<Marker> Markers { get; set; } = new List<Marker>();


	[FieldOrder(54)]
	public int TupletAreasCount { get; set; }

	[FieldOrder(55)]
	[FieldCount("TupletAreasCount")]
	public List<TupletArea> TupletAreas { get; set; } = new List<TupletArea>();


	[FieldOrder(56)]
	public uint PvBaseTableSize { get; set; } = 64u;


	[FieldOrder(57)]
	[FieldLength(64uL)]
	public byte[] PvBaseName { get; set; } = new byte[64];


	[FieldOrder(58)]
	public uint TimelineTableSize { get; set; } = 52u;


	[FieldOrder(59)]
	public byte TimelineMarkers { get; set; } = 1;


	[FieldOrder(60)]
	public TimelineModule TimeLineModule1 { get; set; } = new TimelineModule();


	[FieldOrder(61)]
	public TimelineModule TimeLineModule2 { get; set; } = new TimelineModule();


	[FieldOrder(62)]
	public TimelineModule TimeLineModule3 { get; set; } = new TimelineModule();


	[FieldOrder(63)]
	public byte TimelineSoundStage { get; set; } = 1;


	[FieldOrder(64)]
	public byte TimelineCamera { get; set; } = 1;


	[FieldOrder(65)]
	public byte TimelineEffects { get; set; } = 1;


	[FieldOrder(66)]
	public byte TimelineFade { get; set; } = 1;


	[FieldOrder(67)]
	public byte TimelineLyrics { get; set; } = 1;


	[FieldOrder(68)]
	public byte TimelineRhythm { get; set; } = 1;


	[FieldOrder(69)]
	public byte TimelineTargets { get; set; } = 1;


	[FieldOrder(70)]
	public byte TimelineChanceTime { get; set; } = 1;


	[FieldOrder(71)]
	public byte TimelineTechnicalZone { get; set; } = 1;


	[FieldOrder(72)]
	public int ShowModulePlayer1sCount { get; set; }

	[FieldOrder(73)]
	[FieldCount("ShowModulePlayer1sCount")]
	public List<PlayerShowModule> ShowModulePlayer1s { get; set; } = new List<PlayerShowModule>();


	[FieldOrder(74)]
	public int ShowModulePlayer2sCount { get; set; }

	[FieldOrder(75)]
	[FieldCount("ShowModulePlayer2sCount")]
	public List<PlayerShowModule> ShowModulePlayer2s { get; set; } = new List<PlayerShowModule>();


	[FieldOrder(76)]
	public int ShowModulePlayer3sCount { get; set; }

	[FieldOrder(77)]
	[FieldCount("ShowModulePlayer3sCount")]
	public List<PlayerShowModule> ShowModulePlayer3s { get; set; } = new List<PlayerShowModule>();


	[FieldOrder(78)]
	public int ShowMiscPlayer1sCount { get; set; }

	[FieldOrder(79)]
	[FieldCount("ShowMiscPlayer1sCount")]
	public List<PlayerShowMisc> ShowMiscPlayer1s { get; set; } = new List<PlayerShowMisc>();


	[FieldOrder(80)]
	public int ShowMiscPlayer2sCount { get; set; }

	[FieldOrder(81)]
	[FieldCount("ShowMiscPlayer2sCount")]
	public List<PlayerShowMisc> ShowMiscPlayer2s { get; set; } = new List<PlayerShowMisc>();


	[FieldOrder(82)]
	public int ShowMiscPlayer3sCount { get; set; }

	[FieldOrder(83)]
	[FieldCount("ShowMiscPlayer3sCount")]
	public List<PlayerShowMisc> ShowMiscPlayer3s { get; set; } = new List<PlayerShowMisc>();


	[FieldOrder(84)]
	public int ShowShadowPlayer1sCount { get; set; }

	[FieldOrder(85)]
	[FieldCount("ShowShadowPlayer1sCount")]
	public List<PlayerShowShadow> ShowShadowPlayer1s { get; set; } = new List<PlayerShowShadow>();


	[FieldOrder(86)]
	public int ShowShadowPlayer2sCount { get; set; }

	[FieldOrder(87)]
	[FieldCount("ShowShadowPlayer2sCount")]
	public List<PlayerShowShadow> ShowShadowPlayer2s { get; set; } = new List<PlayerShowShadow>();


	[FieldOrder(88)]
	public int ShowShadowPlayer3sCount { get; set; }

	[FieldOrder(89)]
	[FieldCount("ShowShadowPlayer3sCount")]
	public List<PlayerShowShadow> ShowShadowPlayer3s { get; set; } = new List<PlayerShowShadow>();


	[FieldOrder(90)]
	public int PlayerPositionPlayer1sCount { get; set; }

	[FieldOrder(91)]
	[FieldCount("PlayerPositionPlayer1sCount")]
	public List<PlayerPosition> PlayerPositionPlayer1s { get; set; } = new List<PlayerPosition>();


	[FieldOrder(92)]
	public int PlayerPositionPlayer2sCount { get; set; }

	[FieldOrder(93)]
	[FieldCount("PlayerPositionPlayer2sCount")]
	public List<PlayerPosition> PlayerPositionPlayer2s { get; set; } = new List<PlayerPosition>();


	[FieldOrder(94)]
	public int PlayerPositionPlayer3sCount { get; set; }

	[FieldOrder(95)]
	[FieldCount("PlayerPositionPlayer3sCount")]
	public List<PlayerPosition> PlayerPositionPlayer3s { get; set; } = new List<PlayerPosition>();


	[FieldOrder(96)]
	public int PlayerMotionPlayer1sCount { get; set; }

	[FieldOrder(97)]
	[FieldCount("PlayerMotionPlayer1sCount")]
	public List<PlayerMotion> PlayerMotionPlayer1s { get; set; } = new List<PlayerMotion>();


	[FieldOrder(98)]
	public int PlayerMotionPlayer2sCount { get; set; }

	[FieldOrder(99)]
	[FieldCount("PlayerMotionPlayer2sCount")]
	public List<PlayerMotion> PlayerMotionPlayer2s { get; set; } = new List<PlayerMotion>();


	[FieldOrder(100)]
	public int PlayerMotionPlayer3sCount { get; set; }

	[FieldOrder(101)]
	[FieldCount("PlayerMotionPlayer3sCount")]
	public List<PlayerMotion> PlayerMotionPlayer3s { get; set; } = new List<PlayerMotion>();


	[FieldOrder(102)]
	public int PlayerExpressionPlayer1sCount { get; set; }

	[FieldOrder(103)]
	[FieldCount("PlayerExpressionPlayer1sCount")]
	public List<PlayerExpression> PlayerExpressionPlayer1s { get; set; } = new List<PlayerExpression>();


	[FieldOrder(104)]
	public int PlayerExpressionPlayer2sCount { get; set; }

	[FieldOrder(105)]
	[FieldCount("PlayerExpressionPlayer2sCount")]
	public List<PlayerExpression> PlayerExpressionPlayer2s { get; set; } = new List<PlayerExpression>();


	[FieldOrder(106)]
	public int PlayerExpressionPlayer3sCount { get; set; }

	[FieldOrder(107)]
	[FieldCount("PlayerExpressionPlayer3sCount")]
	public List<PlayerExpression> PlayerExpressionPlayer3s { get; set; } = new List<PlayerExpression>();


	[FieldOrder(108)]
	public int PlayerLeftHandPlayer1sCount { get; set; }

	[FieldOrder(109)]
	[FieldCount("PlayerLeftHandPlayer1sCount")]
	public List<PlayerHand> PlayerLeftHandPlayer1s { get; set; } = new List<PlayerHand>();


	[FieldOrder(110)]
	public int PlayerLeftHandPlayer2sCount { get; set; }

	[FieldOrder(111)]
	[FieldCount("PlayerLeftHandPlayer2sCount")]
	public List<PlayerHand> PlayerLeftHandPlayer2s { get; set; } = new List<PlayerHand>();


	[FieldOrder(112)]
	public int PlayerLeftHandPlayer3sCount { get; set; }

	[FieldOrder(113)]
	[FieldCount("PlayerLeftHandPlayer3sCount")]
	public List<PlayerHand> PlayerLeftHandPlayer3s { get; set; } = new List<PlayerHand>();


	[FieldOrder(114)]
	public int PlayerRightHandPlayer1sCount { get; set; }

	[FieldOrder(115)]
	[FieldCount("PlayerRightHandPlayer1sCount")]
	public List<PlayerHand> PlayerRightHandPlayer1s { get; set; } = new List<PlayerHand>();


	[FieldOrder(116)]
	public int PlayerRightHandPlayer2sCount { get; set; }

	[FieldOrder(117)]
	[FieldCount("PlayerRightHandPlayer2sCount")]
	public List<PlayerHand> PlayerRightHandPlayer2s { get; set; } = new List<PlayerHand>();


	[FieldOrder(118)]
	public int PlayerRightHandPlayer3sCount { get; set; }

	[FieldOrder(119)]
	[FieldCount("PlayerRightHandPlayer3sCount")]
	public List<PlayerHand> PlayerRightHandPlayer3s { get; set; } = new List<PlayerHand>();


	[FieldOrder(120)]
	public int PlayerLineOfSightPlayer1sCount { get; set; }

	[FieldOrder(121)]
	[FieldCount("PlayerLineOfSightPlayer1sCount")]
	public List<PlayerLineOfSight> PlayerLineOfSightPlayer1s { get; set; } = new List<PlayerLineOfSight>();


	[FieldOrder(122)]
	public int PlayerLineOfSightPlayer2sCount { get; set; }

	[FieldOrder(123)]
	[FieldCount("PlayerLineOfSightPlayer2sCount")]
	public List<PlayerLineOfSight> PlayerLineOfSightPlayer2s { get; set; } = new List<PlayerLineOfSight>();


	[FieldOrder(124)]
	public int PlayerLineOfSightPlayer3sCount { get; set; }

	[FieldOrder(125)]
	[FieldCount("PlayerLineOfSightPlayer3sCount")]
	public List<PlayerLineOfSight> PlayerLineOfSightPlayer3s { get; set; } = new List<PlayerLineOfSight>();


	[FieldOrder(126)]
	public int PlayerBlinkPlayer1sCount { get; set; }

	[FieldOrder(127)]
	[FieldCount("PlayerBlinkPlayer1sCount")]
	public List<PlayerBlink> PlayerBlinkPlayer1s { get; set; } = new List<PlayerBlink>();


	[FieldOrder(128)]
	public int PlayerBlinkPlayer2sCount { get; set; }

	[FieldOrder(129)]
	[FieldCount("PlayerBlinkPlayer2sCount")]
	public List<PlayerBlink> PlayerBlinkPlayer2s { get; set; } = new List<PlayerBlink>();


	[FieldOrder(130)]
	public int PlayerBlinkPlayer3sCount { get; set; }

	[FieldOrder(131)]
	[FieldCount("PlayerBlinkPlayer3sCount")]
	public List<PlayerBlink> PlayerBlinkPlayer3s { get; set; } = new List<PlayerBlink>();


	[FieldOrder(132)]
	public int PlayerFaceEffectPlayer1sCount { get; set; }

	[FieldOrder(133)]
	[FieldCount("PlayerFaceEffectPlayer1sCount")]
	public List<PlayerFaceEffect> PlayerFaceEffectPlayer1s { get; set; } = new List<PlayerFaceEffect>();


	[FieldOrder(134)]
	public int PlayerFaceEffectPlayer2sCount { get; set; }

	[FieldOrder(135)]
	[FieldCount("PlayerFaceEffectPlayer2sCount")]
	public List<PlayerFaceEffect> PlayerFaceEffectPlayer2s { get; set; } = new List<PlayerFaceEffect>();


	[FieldOrder(136)]
	public int PlayerFaceEffectPlayer3sCount { get; set; }

	[FieldOrder(137)]
	[FieldCount("PlayerFaceEffectPlayer3sCount")]
	public List<PlayerFaceEffect> PlayerFaceEffectPlayer3s { get; set; } = new List<PlayerFaceEffect>();


	[FieldOrder(138)]
	public int PlayerLipsyncPlayer1sCount { get; set; }

	[FieldOrder(139)]
	[FieldCount("PlayerLipsyncPlayer1sCount")]
	public List<PlayerLipsync> PlayerLipsyncPlayer1s { get; set; } = new List<PlayerLipsync>();


	[FieldOrder(140)]
	public int PlayerLipsyncPlayer2sCount { get; set; }

	[FieldOrder(141)]
	[FieldCount("PlayerLipsyncPlayer2sCount")]
	public List<PlayerLipsync> PlayerLipsyncPlayer2s { get; set; } = new List<PlayerLipsync>();


	[FieldOrder(142)]
	public int PlayerLipsyncPlayer3sCount { get; set; }

	[FieldOrder(143)]
	[FieldCount("PlayerLipsyncPlayer3sCount")]
	public List<PlayerLipsync> PlayerLipsyncPlayer3s { get; set; } = new List<PlayerLipsync>();


	[FieldOrder(144)]
	public int PlayerItemPlayer1sCount { get; set; }

	[FieldOrder(145)]
	[FieldCount("PlayerItemPlayer1sCount")]
	public List<PlayerItem> PlayerItemPlayer1s { get; set; } = new List<PlayerItem>();


	[FieldOrder(146)]
	public int PlayerItemPlayer2sCount { get; set; }

	[FieldOrder(147)]
	[FieldCount("PlayerItemPlayer2sCount")]
	public List<PlayerItem> PlayerItemPlayer2s { get; set; } = new List<PlayerItem>();


	[FieldOrder(148)]
	public int PlayerItemPlayer3sCount { get; set; }

	[FieldOrder(149)]
	[FieldCount("PlayerItemPlayer3sCount")]
	public List<PlayerItem> PlayerItemPlayer3s { get; set; } = new List<PlayerItem>();


	[FieldOrder(150)]
	public int EditCamerasCount { get; set; }

	[FieldOrder(151)]
	[FieldCount("EditCamerasCount")]
	public List<EditCamera> EditCameras { get; set; } = new List<EditCamera>();


	[FieldOrder(152)]
	public int EditStagesCount { get; set; }

	[FieldOrder(153)]
	[FieldCount("EditStagesCount")]
	public List<EditStage> EditStages { get; set; } = new List<EditStage>();


	[FieldOrder(154)]
	public int EditLyricsCount { get; set; }

	[FieldOrder(155)]
	[FieldCount("EditLyricsCount")]
	[SerializeWhen("RegionValue", RegionValue.JPN)]
	public List<EditLyric> EditLyrics { get; set; } = new List<EditLyric>();


	[FieldOrder(156)]
	[FieldCount("EditLyricsCount")]
	[SerializeWhen("RegionValue", RegionValue.KYS)]
	public List<KysEditLyric> KysEditLyrics
	{
		get
		{
			List<KysEditLyric> kys = new List<KysEditLyric>(EditLyrics.Count);
			EditLyrics.ForEach(delegate(EditLyric l)
			{
				kys.Add(new KysEditLyric(l));
			});
			return kys;
		}
		set
		{
			value.ForEach(delegate(KysEditLyric l)
			{
				EditLyrics.Add(l.GetEditLyric());
			});
		}
	}

	[FieldOrder(157)]
	public int EditFadesCount { get; set; }

	[FieldOrder(158)]
	[FieldCount("EditFadesCount")]
	public List<EditFade> EditFades { get; set; } = new List<EditFade>();


	[FieldOrder(159)]
	public int EditEffectsCount { get; set; }

	[FieldOrder(160)]
	[FieldCount("EditEffectsCount")]
	public List<EditEffect> EditEffects { get; set; } = new List<EditEffect>();


	[FieldOrder(161)]
	public int EditTargetsCount { get; set; }

	[FieldOrder(162)]
	[FieldCount("EditTargetsCount")]
	public List<EditTarget> EditTargets { get; set; } = new List<EditTarget>();


	[FieldOrder(163)]
	public int TechnicalZonesCount { get; set; }

	[FieldOrder(164)]
	[FieldCount("TechnicalZonesCount")]
	public List<TechZoneArea> TechnicalZones { get; set; } = new List<TechZoneArea>();


	[FieldOrder(165)]
	public int ChanceTimesCount { get; set; }

	[FieldOrder(166)]
	[FieldCount("ChanceTimesCount")]
	public List<ChanceTimeArea> ChanceTimes { get; set; } = new List<ChanceTimeArea>();


	public void Serialize(string editPath, bool header = true)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Expected O, but got Unknown
		FileStream fileStream = new FileStream(editPath, FileMode.Create);
		BinarySerializer val = new BinarySerializer();
		val.Endianness = (Endianness)2;
		UpdateCounts();
		val.Serialize((Stream)fileStream, (object)this, (object)null);
		fileStream.Dispose();
		Crc32.UpdateChecksum(editPath);
	}

	public static Edit Deserialize(string editPath)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		Edit edit = new Edit();
		using FileStream fileStream = File.OpenRead(editPath);
		byte[] array = new byte[32];
		fileStream.Read(array, 0, array.Length);
		fileStream.Seek(0L, SeekOrigin.Begin);
		int num = BitConverter.ToInt32(array, 20);
		bool flag = fileStream.Length == num + 16;
		return (Edit)new BinarySerializer
		{
			Endianness = (Endianness)(flag ? 1 : 2)
		}.Deserialize((Stream)fileStream, typeof(Edit), (object)null);
	}

	public static Edit Deserialize(string editPath, Endianness endianness)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Expected O, but got Unknown
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		Edit edit = new Edit();
		BinarySerializer val = new BinarySerializer();
		val.Endianness = endianness;
		FileStream fileStream = new FileStream(editPath, FileMode.Open);
		Edit result = (Edit)val.Deserialize((Stream)fileStream, typeof(Edit), (object)null);
		fileStream.Dispose();
		return result;
	}

	public void UpdateCounts()
	{
		BpmChangesCount = BPMChanges.Count;
		TimeSigChangesCount = TimeSigChanges.Count;
		MarkersCount = Markers.Count;
		TupletAreasCount = TupletAreas.Count;
		ShowModulePlayer1sCount = ShowModulePlayer1s.Count;
		ShowModulePlayer2sCount = ShowModulePlayer2s.Count;
		ShowModulePlayer3sCount = ShowModulePlayer3s.Count;
		ShowMiscPlayer1sCount = ShowMiscPlayer1s.Count;
		ShowMiscPlayer2sCount = ShowMiscPlayer2s.Count;
		ShowMiscPlayer3sCount = ShowMiscPlayer3s.Count;
		ShowShadowPlayer1sCount = ShowShadowPlayer1s.Count;
		ShowShadowPlayer2sCount = ShowShadowPlayer2s.Count;
		ShowShadowPlayer3sCount = ShowShadowPlayer3s.Count;
		PlayerPositionPlayer1sCount = PlayerPositionPlayer1s.Count;
		PlayerPositionPlayer2sCount = PlayerPositionPlayer2s.Count;
		PlayerPositionPlayer3sCount = PlayerPositionPlayer3s.Count;
		PlayerMotionPlayer1sCount = PlayerMotionPlayer1s.Count;
		PlayerMotionPlayer2sCount = PlayerMotionPlayer2s.Count;
		PlayerMotionPlayer3sCount = PlayerMotionPlayer3s.Count;
		PlayerExpressionPlayer1sCount = PlayerExpressionPlayer1s.Count;
		PlayerExpressionPlayer2sCount = PlayerExpressionPlayer2s.Count;
		PlayerExpressionPlayer3sCount = PlayerExpressionPlayer3s.Count;
		PlayerLeftHandPlayer1sCount = PlayerLeftHandPlayer1s.Count;
		PlayerLeftHandPlayer2sCount = PlayerLeftHandPlayer2s.Count;
		PlayerLeftHandPlayer3sCount = PlayerLeftHandPlayer3s.Count;
		PlayerRightHandPlayer1sCount = PlayerRightHandPlayer1s.Count;
		PlayerRightHandPlayer2sCount = PlayerRightHandPlayer2s.Count;
		PlayerRightHandPlayer3sCount = PlayerRightHandPlayer3s.Count;
		PlayerLineOfSightPlayer1sCount = PlayerLineOfSightPlayer1s.Count;
		PlayerLineOfSightPlayer2sCount = PlayerLineOfSightPlayer2s.Count;
		PlayerLineOfSightPlayer3sCount = PlayerLineOfSightPlayer3s.Count;
		PlayerBlinkPlayer1sCount = PlayerBlinkPlayer1s.Count;
		PlayerBlinkPlayer2sCount = PlayerBlinkPlayer2s.Count;
		PlayerBlinkPlayer3sCount = PlayerBlinkPlayer3s.Count;
		PlayerFaceEffectPlayer1sCount = PlayerFaceEffectPlayer1s.Count;
		PlayerFaceEffectPlayer2sCount = PlayerFaceEffectPlayer2s.Count;
		PlayerFaceEffectPlayer3sCount = PlayerFaceEffectPlayer3s.Count;
		PlayerLipsyncPlayer1sCount = PlayerLipsyncPlayer1s.Count;
		PlayerLipsyncPlayer2sCount = PlayerLipsyncPlayer2s.Count;
		PlayerLipsyncPlayer3sCount = PlayerLipsyncPlayer3s.Count;
		PlayerItemPlayer1sCount = PlayerItemPlayer1s.Count;
		PlayerItemPlayer2sCount = PlayerItemPlayer2s.Count;
		PlayerItemPlayer3sCount = PlayerItemPlayer3s.Count;
		EditCamerasCount = EditCameras.Count;
		foreach (EditCamera editCamera in EditCameras)
		{
			editCamera.KeyPointCount = (byte)editCamera.CameraKeyPoints.Count;
		}
		EditStagesCount = EditStages.Count;
		EditLyricsCount = EditLyrics.Count;
		EditFadesCount = EditFades.Count;
		EditEffectsCount = EditEffects.Count;
		EditTargetsCount = EditTargets.Count;
		TechnicalZonesCount = TechnicalZones.Count;
		ChanceTimesCount = ChanceTimes.Count;
	}
}
