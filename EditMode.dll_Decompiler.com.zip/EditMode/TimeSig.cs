namespace EditMode;

public enum TimeSig : uint
{
	Duple = 1u,
	Triple,
	Quadruple
}
