using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerShowShadow
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Bool1 { get; set; }

	[FieldOrder(2)]
	public byte ShowShadow { get; set; }

	[FieldOrder(3)]
	public byte Bool3 { get; set; }

	[FieldOrder(4)]
	public byte Bool4 { get; set; }
}
