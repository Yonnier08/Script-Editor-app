using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class EditFade
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public ushort FadeID { get; set; } = 255;


	[FieldOrder(2)]
	public Fade FadeType { get; set; }

	[FieldOrder(3)]
	public float PlaybackSpeed { get; set; } = 1f;


	[FieldOrder(4)]
	public float StartTime { get; set; }

	[FieldOrder(5)]
	public float EffectProgress { get; set; } = 1f;


	public EditFade()
	{
	}

	public EditFade(uint time, ushort fadeType)
	{
		Time = time;
		FadeType = (Fade)fadeType;
	}

	public bool GetIsFadeIn()
	{
		switch (FadeType)
		{
		case Fade.フェードアウト_白:
		case Fade.フェードアウト_黒:
		case Fade.フェードアウト_赤:
		case Fade.フェードアウト_緑:
		case Fade.フェードアウト_青:
		case Fade.フェードアウト_黄:
		case Fade.フェードアウト_ピンク:
		case Fade.フェードアウト_水色:
		case Fade.フェードアウト_橙:
		case Fade.フェードアウト_紫:
			return false;
		case Fade.フェードイン_白:
		case Fade.フェードイン_黒:
		case Fade.フェードイン_赤:
		case Fade.フェードイン_緑:
		case Fade.フェードイン_青:
		case Fade.フェードイン_黄:
		case Fade.フェードイン_ピンク:
		case Fade.フェードイン_水色:
		case Fade.フェードイン_橙:
		case Fade.フェードイン_紫:
			return true;
		default:
			return false;
		}
	}

	public uint GetPVTime()
	{
		return Utilities.CalculatePVTime(Time);
	}
}
