using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerItem
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte LeftHand { get; set; }

	[FieldOrder(2)]
	public byte RightHand { get; set; } = byte.MaxValue;


	[FieldOrder(3)]
	public byte Unknown1 { get; set; }

	[FieldOrder(4)]
	public byte Unknown2 { get; set; }

	[FieldOrder(5)]
	public Item ItemID { get; set; } = Item.なし;


	[FieldOrder(6)]
	public int Unknown3 { get; set; } = -1;


	[FieldOrder(7)]
	public int Unknown4 { get; set; } = -1;


	[FieldOrder(8)]
	public int Unknown5 { get; set; } = -1;


	[FieldOrder(9)]
	public int Unknown6 { get; set; } = -1;


	[FieldOrder(10)]
	public int Unknown7 { get; set; } = -1;

}
