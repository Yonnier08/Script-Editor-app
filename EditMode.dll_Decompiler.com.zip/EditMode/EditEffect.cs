using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class EditEffect
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public int Unknown { get; set; } = 16777216;


	[FieldOrder(2)]
	public Effect EffectID { get; set; } = Effect.なし;


	[FieldOrder(3)]
	public float PlaybackSpeed { get; set; }

	[FieldOrder(4)]
	public float StartTime { get; set; }

	[FieldOrder(5)]
	public uint EffectID2 { get; set; }
}
