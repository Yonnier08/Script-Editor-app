using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class EditLyric
{
	[FieldOrder(4)]
	[FieldLength(42uL)]
	public byte[] lyrics = new byte[42];

	[Ignore]
	public byte[] lyricsExtended = new byte[88];

	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Selectable { get; set; } = 1;


	[FieldOrder(2)]
	public ColorID ColorID { get; set; }

	[FieldOrder(3)]
	public ushort Unknonw0 { get; set; }

	[Ignore]
	public string Lyrics
	{
		get
		{
			if (lyricsExtended != null && (lyricsExtended[42] != 0 || lyricsExtended[43] != 0))
			{
				return Utilities.GetString(lyricsExtended, Encoding.Unicode);
			}
			return Utilities.GetString(lyrics, Encoding.Unicode);
		}
		set
		{
			lyrics = Utilities.GetBytes(value, 42, Encoding.Unicode);
			if (lyricsExtended == null)
			{
				lyricsExtended = new byte[88];
			}
			lyricsExtended = Utilities.GetBytes(value, 88, Encoding.Unicode);
		}
	}

	[FieldOrder(5)]
	public ushort Unknown1 { get; set; }

	[FieldOrder(6)]
	public byte Alpha { get; set; }

	[FieldOrder(7)]
	public byte R { get; set; } = byte.MaxValue;


	[FieldOrder(8)]
	public byte G { get; set; } = byte.MaxValue;


	[FieldOrder(9)]
	public byte B { get; set; } = byte.MaxValue;


	[FieldOrder(10)]
	public uint Duration { get; set; } = 2u;


	[FieldOrder(11)]
	[FieldLength(32uL)]
	public byte[] Space { get; set; } = new byte[32];


	public override string ToString()
	{
		return Lyrics;
	}

	public EditLyric()
	{
	}

	public EditLyric(string lyrics, uint time = 0u, uint length = 2u, byte color = 0)
	{
		Lyrics = lyrics;
		Time = time;
		Duration = length;
		ColorID = (ColorID)color;
	}

	public static List<EditLyric> ReadTextFile(string inputFile, uint interval = 120u, uint length = 20u, byte color = 0)
	{
		List<EditLyric> list = new List<EditLyric>();
		string[] array = File.ReadAllLines(inputFile);
		uint num = 0u;
		string[] array2 = array;
		foreach (string text in array2)
		{
			list.Add(new EditLyric(text, num, length, color));
			num += interval;
		}
		return list;
	}

	public static void WriteLyricsToFile(List<EditLyric> editLyrics, string filePath)
	{
		StreamWriter streamWriter = new StreamWriter(new FileStream(filePath, FileMode.Create));
		int num = 0;
		int num2 = 0;
		foreach (EditLyric editLyric in editLyrics)
		{
			string.Format("pv_{2:000}.lyric.{1:000}={0}", editLyric.ToString(), num, num2);
			streamWriter.WriteLine(editLyric.ToString());
			num++;
		}
		streamWriter.Flush();
		streamWriter.BaseStream.Dispose();
	}
}
