using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class EditTarget
{
	[FieldOrder(0)]
	public ushort BarIndex { get; set; }

	[FieldOrder(1)]
	public ushort BeatIndex { get; set; }

	[FieldOrder(2)]
	public ushort Unknown { get; set; } = 256;


	[FieldOrder(3)]
	public ushort ConstUnknown { get; set; } = 256;


	[FieldOrder(4)]
	public TargetType TargetType { get; set; } = TargetType.maru;


	[FieldOrder(5)]
	public float XPosition { get; set; } = 640f;


	[FieldOrder(6)]
	public float YPosition { get; set; } = 352f;


	[FieldOrder(7)]
	public float EntryAngle { get; set; }

	[FieldOrder(8)]
	public ushort HoldEndBar { get; set; }

	[FieldOrder(9)]
	public ushort HoldEndBeat { get; set; }
}
