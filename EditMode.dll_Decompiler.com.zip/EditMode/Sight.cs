namespace EditMode;

public enum Sight : uint
{
	上,
	下,
	右,
	左,
	右上,
	左上,
	右下,
	左下,
	カメラ目線,
	上寄り,
	下寄り,
	右寄り,
	左寄り,
	右上寄り,
	左上寄り,
	右下寄り,
	左下寄り,
	前髪,
	鼻先,
	通常
}
