namespace EditMode;

public enum CameraOrbit : byte
{
	標準,
	直線,
	曲線
}
