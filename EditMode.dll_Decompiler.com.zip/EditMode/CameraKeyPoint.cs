using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class CameraKeyPoint
{
	[FieldOrder(0)]
	public Vector3 CameraStart { get; set; } = new Vector3();


	[FieldOrder(1)]
	public Vector3 FocusPointStart { get; set; } = new Vector3();


	[FieldOrder(2)]
	public Vector3 UnknowntStart { get; set; } = new Vector3();


	[FieldOrder(3)]
	public Vector3 CameraEnd { get; set; } = new Vector3();


	[FieldOrder(4)]
	public Vector3 FocusPointEnd { get; set; } = new Vector3();


	[FieldOrder(5)]
	public Vector3 UnknowntEnd { get; set; } = new Vector3();


	[FieldOrder(6)]
	public float CameraAccelerationStart { get; set; }

	[FieldOrder(7)]
	public float CameraAccelerationEnd { get; set; }

	[FieldOrder(8)]
	public byte Unknown1 { get; set; }

	[FieldOrder(9)]
	public PlayerFocus PlayerFocus { get; set; }

	[FieldOrder(10)]
	public byte Unknown2 { get; set; }

	[FieldOrder(11)]
	public uint CameraDuration { get; set; } = 2u;


	public CameraKeyPoint Clone()
	{
		return new CameraKeyPoint
		{
			CameraStart = CameraStart,
			FocusPointStart = FocusPointStart,
			UnknowntStart = UnknowntStart,
			CameraEnd = CameraEnd,
			FocusPointEnd = FocusPointEnd,
			UnknowntEnd = UnknowntEnd,
			CameraAccelerationStart = CameraAccelerationStart,
			CameraAccelerationEnd = CameraAccelerationEnd,
			Unknown1 = Unknown1,
			PlayerFocus = PlayerFocus,
			Unknown2 = Unknown2,
			CameraDuration = CameraDuration
		};
	}
}
