namespace EditMode;

public enum FaceEffect : uint
{
	涙_1 = 0u,
	頬染め_2 = 1u,
	頬染め_3 = 2u,
	頬染め_4 = 3u,
	どんより = 4u,
	涙_2 = 5u,
	頬染め_1 = 6u,
	怒り = 7u,
	汗_1 = 8u,
	汗_2 = 9u,
	キラーン_左目 = 10u,
	キラーン_右目 = 11u,
	号泣 = 12u,
	キラーン_歯 = 14u
}
