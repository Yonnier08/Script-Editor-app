using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class EditStage
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Bool1 { get; set; }

	[FieldOrder(2)]
	public byte Bool2 { get; set; }

	[FieldOrder(3)]
	public Shader StageShader { get; set; }

	[FieldOrder(4)]
	public Stage StageID1 { get; set; }

	[FieldOrder(5)]
	public int StageID2 { get; set; }

	[FieldOrder(6)]
	public Stage StageID3 { get; set; }
}
