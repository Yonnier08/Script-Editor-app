namespace EditMode;

public enum ColorID : byte
{
	白,
	黄,
	ピンク,
	緑,
	紫,
	黒,
	橙,
	赤,
	水色,
	青
}
