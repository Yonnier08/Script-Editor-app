using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class TupletArea
{
	[FieldOrder(0)]
	public ushort BarIndex { get; set; }

	[FieldOrder(1)]
	public ushort BeatIndex { get; set; }

	[FieldOrder(2)]
	public Tuplet Type { get; set; }

	[FieldOrder(3)]
	public uint ColorID { get; set; }
}
