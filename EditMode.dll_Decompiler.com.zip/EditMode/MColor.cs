namespace EditMode;

public enum MColor : uint
{
	赤 = 1u,
	青,
	黄,
	紫,
	ピンク,
	緑
}
