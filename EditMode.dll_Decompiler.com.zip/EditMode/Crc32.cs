using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using BinarySerialization;

namespace EditMode;

public sealed class Crc32 : HashAlgorithm
{
	public const uint DefaultPolynomial = 3988292384u;

	public const uint DefaultSeed = uint.MaxValue;

	private static uint[] defaultTable;

	private readonly uint seed;

	private readonly uint[] table;

	private uint hash;

	public override int HashSize => 32;

	public Crc32()
		: this(3988292384u, uint.MaxValue)
	{
	}

	public Crc32(uint polynomial, uint seed)
	{
		table = InitializeTable(polynomial);
		this.seed = (hash = seed);
	}

	public override void Initialize()
	{
		hash = seed;
	}

	protected override void HashCore(byte[] array, int ibStart, int cbSize)
	{
		hash = CalculateHash(table, hash, array, ibStart, cbSize);
	}

	protected override byte[] HashFinal()
	{
		return HashValue = UInt32ToBigEndianBytes(~hash);
	}

	public static uint Compute(byte[] buffer)
	{
		return Compute(uint.MaxValue, buffer);
	}

	public static uint Compute(uint seed, byte[] buffer)
	{
		return Compute(3988292384u, seed, buffer);
	}

	public static uint Compute(uint polynomial, uint seed, byte[] buffer)
	{
		return ~CalculateHash(InitializeTable(polynomial), seed, buffer, 0, buffer.Length);
	}

	private static uint[] InitializeTable(uint polynomial)
	{
		if (polynomial == 3988292384u && defaultTable != null)
		{
			return defaultTable;
		}
		uint[] array = new uint[256];
		for (int i = 0; i < 256; i++)
		{
			uint num = (uint)i;
			for (int j = 0; j < 8; j++)
			{
				num = (((num & 1) != 1) ? (num >> 1) : ((num >> 1) ^ polynomial));
			}
			array[i] = num;
		}
		if (polynomial == 3988292384u)
		{
			defaultTable = array;
		}
		return array;
	}

	private static uint CalculateHash(uint[] table, uint seed, IList<byte> buffer, int start, int size)
	{
		uint num = seed;
		for (int i = start; i < start + size; i++)
		{
			num = (num >> 8) ^ table[buffer[i] ^ (num & 0xFF)];
		}
		return num;
	}

	private static byte[] UInt32ToBigEndianBytes(uint uint32)
	{
		byte[] bytes = BitConverter.GetBytes(uint32);
		if (BitConverter.IsLittleEndian)
		{
			Array.Reverse((Array)bytes);
		}
		return bytes;
	}

	public static uint CalculateChecksum(string inputEdit)
	{
		FileStream fileStream = new FileStream(inputEdit, FileMode.Open);
		BinaryReader binaryReader = new BinaryReader(fileStream);
		Crc32 crc = new Crc32();
		string text = string.Empty;
		byte b = 16;
		fileStream.Seek(b, SeekOrigin.Begin);
		FileStream inputStream = fileStream;
		byte[] array = crc.ComputeHash(inputStream);
		foreach (byte b2 in array)
		{
			text += b2.ToString("x2").ToLower();
		}
		int result = (int)Convert.ToUInt32(text, 16);
		fileStream.Dispose();
		return (uint)result;
	}

	public static void WriteChecksum(string inputEdit)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		uint num = CalculateChecksum(inputEdit);
		FileStream fileStream = new FileStream(inputEdit, FileMode.Open);
		fileStream.Seek(8L, SeekOrigin.Begin);
		new BinarySerializer
		{
			Endianness = (Endianness)2
		}.Serialize((Stream)fileStream, (object)num, (object)null);
		fileStream.Dispose();
	}

	public static void WriteChecksumRange(string inputEdit)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		FileStream fileStream = new FileStream(inputEdit, FileMode.Open);
		long num = fileStream.Length - 16;
		fileStream.Seek(12L, SeekOrigin.Begin);
		new BinarySerializer
		{
			Endianness = (Endianness)2
		}.Serialize((Stream)fileStream, (object)(uint)num, (object)null);
		fileStream.Seek(20L, SeekOrigin.Begin);
		new BinarySerializer
		{
			Endianness = (Endianness)2
		}.Serialize((Stream)fileStream, (object)(uint)num, (object)null);
		fileStream.Dispose();
	}

	public static void UpdateChecksum(string inputEdit)
	{
		WriteChecksumRange(inputEdit);
		WriteChecksum(inputEdit);
	}
}
