using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerShowModule
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Bool1 { get; set; } = 1;


	[FieldOrder(2)]
	public byte ShowPlayer { get; set; } = 1;


	[FieldOrder(3)]
	public byte Bool3 { get; set; }

	[FieldOrder(4)]
	public byte Bool4 { get; set; }
}
