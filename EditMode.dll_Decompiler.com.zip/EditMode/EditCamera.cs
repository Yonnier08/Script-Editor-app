using System;
using System.Collections.Generic;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class EditCamera
{
	[FieldOrder(5)]
	[FieldCount("KeyPointCount")]
	public List<CameraKeyPoint> CameraKeyPoints = new List<CameraKeyPoint>();

	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte ColorId { get; set; }

	[FieldOrder(2)]
	public CameraOrbit OrbitMode { get; set; }

	[FieldOrder(3)]
	public byte KeyPointCount { get; set; }

	[FieldOrder(4)]
	public byte UnknownBool { get; set; }

	public static List<EditCamera> SliceCamera(List<EditCamera> cameras)
	{
		List<EditCamera> list = new List<EditCamera>();
		foreach (EditCamera camera in cameras)
		{
			uint num = camera.Time;
			foreach (CameraKeyPoint cameraKeyPoint2 in camera.CameraKeyPoints)
			{
				EditCamera editCamera = new EditCamera
				{
					Time = num,
					ColorId = camera.ColorId,
					OrbitMode = camera.OrbitMode,
					KeyPointCount = 1,
					UnknownBool = camera.UnknownBool
				};
				CameraKeyPoint cameraKeyPoint = cameraKeyPoint2;
				CameraKeyPoint item = new CameraKeyPoint
				{
					CameraStart = new Vector3(cameraKeyPoint.CameraStart.X, cameraKeyPoint.CameraStart.Y, cameraKeyPoint.CameraStart.Z),
					FocusPointStart = new Vector3(cameraKeyPoint.FocusPointStart.X, cameraKeyPoint.FocusPointStart.Y, cameraKeyPoint.FocusPointStart.Z),
					UnknowntStart = new Vector3(cameraKeyPoint.UnknowntStart.X, cameraKeyPoint.UnknowntStart.Y, cameraKeyPoint.UnknowntStart.Z),
					CameraEnd = new Vector3(cameraKeyPoint.CameraEnd.X, cameraKeyPoint.CameraEnd.Y, cameraKeyPoint.CameraEnd.Z),
					FocusPointEnd = new Vector3(cameraKeyPoint.FocusPointEnd.X, cameraKeyPoint.FocusPointEnd.Y, cameraKeyPoint.FocusPointEnd.Z),
					UnknowntEnd = new Vector3(cameraKeyPoint.UnknowntEnd.X, cameraKeyPoint.UnknowntEnd.Y, cameraKeyPoint.UnknowntEnd.Z),
					CameraAccelerationStart = cameraKeyPoint.CameraAccelerationStart,
					CameraAccelerationEnd = cameraKeyPoint.CameraAccelerationEnd,
					Unknown1 = cameraKeyPoint.Unknown1,
					PlayerFocus = cameraKeyPoint.PlayerFocus,
					Unknown2 = cameraKeyPoint.Unknown2,
					CameraDuration = cameraKeyPoint.CameraDuration
				};
				editCamera.CameraKeyPoints.Add(item);
				list.Add(editCamera);
				num += cameraKeyPoint.CameraDuration;
			}
		}
		return list;
	}
}
