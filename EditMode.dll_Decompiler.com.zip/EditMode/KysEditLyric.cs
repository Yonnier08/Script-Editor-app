using System.Text;
using BinarySerialization;

namespace EditMode;

public class KysEditLyric
{
	[FieldOrder(9)]
	[FieldLength(88uL)]
	public byte[] lyrics = new byte[88];

	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Selectable { get; set; } = 1;


	[FieldOrder(2)]
	public ColorID ColorID { get; set; }

	[FieldOrder(3)]
	public ushort Unknown { get; set; }

	[FieldOrder(4)]
	public byte Alpha { get; set; }

	[FieldOrder(5)]
	public byte R { get; set; } = byte.MaxValue;


	[FieldOrder(6)]
	public byte G { get; set; } = byte.MaxValue;


	[FieldOrder(7)]
	public byte B { get; set; } = byte.MaxValue;


	[FieldOrder(8)]
	public uint Duration { get; set; } = 2u;


	[Ignore]
	public string Lyrics
	{
		get
		{
			return Utilities.GetString(lyrics, Encoding.Unicode);
		}
		set
		{
			lyrics = Utilities.GetBytes(value, 42, Encoding.Unicode);
		}
	}

	[FieldOrder(10)]
	[FieldLength(32uL)]
	public byte[] Space { get; set; } = new byte[32];


	public KysEditLyric()
	{
	}

	public KysEditLyric(EditLyric editLyric)
	{
		Time = editLyric.Time;
		Selectable = editLyric.Selectable;
		ColorID = editLyric.ColorID;
		Unknown = editLyric.Unknonw0;
		Alpha = editLyric.Alpha;
		R = editLyric.R;
		G = editLyric.G;
		B = editLyric.B;
		Duration = editLyric.Duration;
		Lyrics = editLyric.Lyrics;
	}

	public EditLyric GetEditLyric()
	{
		return new EditLyric
		{
			Time = Time,
			Selectable = Selectable,
			ColorID = ColorID,
			Unknonw0 = Unknown,
			Lyrics = Lyrics,
			Alpha = Alpha,
			R = R,
			G = G,
			B = B,
			Duration = Duration
		};
	}
}
