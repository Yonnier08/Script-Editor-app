using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class BpmChange
{
	[FieldOrder(0)]
	public uint BarIndex { get; set; }

	[Ignore]
	public uint BeatIndex { get; set; }

	[FieldOrder(1)]
	public float BPM { get; set; }
}
