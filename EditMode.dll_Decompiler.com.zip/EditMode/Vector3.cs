using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class Vector3
{
	[FieldOrder(0)]
	public float X { get; set; }

	[FieldOrder(1)]
	public float Y { get; set; }

	[FieldOrder(2)]
	public float Z { get; set; }

	public Vector3()
	{
	}

	public Vector3(float x, float y, float z)
	{
		X = x;
		Y = y;
		Z = z;
	}
}
