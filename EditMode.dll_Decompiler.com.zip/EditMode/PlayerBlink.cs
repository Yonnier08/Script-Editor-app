using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerBlink
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Bool1 { get; set; }

	[FieldOrder(2)]
	public byte Bool2 { get; set; }

	[FieldOrder(3)]
	public byte BlinkLevel { get; set; }

	[FieldOrder(4)]
	public byte Bool4 { get; set; }

	[FieldOrder(5)]
	public uint BlinkID { get; set; }

	[FieldOrder(6)]
	public uint Interpolation { get; set; }
}
