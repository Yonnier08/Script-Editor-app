namespace EditMode;

public enum RegionValue : uint
{
	JPN = 319952133u,
	KYS = 335947284u
}
