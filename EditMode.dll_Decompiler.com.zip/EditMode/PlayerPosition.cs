using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerPosition
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Unknown1 { get; set; }

	[FieldOrder(2)]
	public byte Unknown2 { get; set; }

	[FieldOrder(3)]
	public byte Unknown3 { get; set; }

	[FieldOrder(4)]
	public byte Unknown4 { get; set; }

	[FieldOrder(5)]
	public uint Duration { get; set; }

	[FieldOrder(6)]
	public Vector3 Start { get; set; } = new Vector3();


	[FieldOrder(7)]
	public Vector3 End { get; set; } = new Vector3();


	[FieldOrder(8)]
	public int StartRoation { get; set; }

	[FieldOrder(9)]
	public int EndRoation { get; set; }

	[FieldOrder(10)]
	public int Disabled { get; set; } = -1;

}
