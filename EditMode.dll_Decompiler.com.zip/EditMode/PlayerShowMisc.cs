using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerShowMisc
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Head { get; set; }

	[FieldOrder(2)]
	public byte Face { get; set; }

	[FieldOrder(3)]
	public byte Chest { get; set; }

	[FieldOrder(4)]
	public byte Back { get; set; }

	[FieldOrder(5)]
	public uint Empty { get; set; }
}
