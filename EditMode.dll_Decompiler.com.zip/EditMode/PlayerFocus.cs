namespace EditMode;

public enum PlayerFocus : ushort
{
	P1_顔 = 5,
	P1_顔_Camera = 7,
	P2_顔_0 = 21,
	P2_顔_1 = 23,
	P3_顔 = 37,
	P3_顔_Camera = 39,
	P1_胸 = 133,
	P1_胸_Camera = 135,
	P2_胸 = 149,
	P2_胸_Camera = 151,
	P3_胸 = 165,
	P3_胸_Camera = 167,
	なし = 256,
	P1_腰 = 261,
	P1_腰_Camera = 263,
	P2_腰 = 277,
	P2_腰_Camera = 279,
	P3_腰 = 293,
	P3_腰_Camera = 295,
	P1_Unknown = 1029
}
