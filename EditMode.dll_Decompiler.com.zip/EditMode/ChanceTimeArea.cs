using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class ChanceTimeArea
{
	[FieldOrder(0)]
	public ushort StartBar { get; set; }

	[FieldOrder(1)]
	public ushort StartBeat { get; set; }

	[FieldOrder(2)]
	public ushort EndBar { get; set; }

	[FieldOrder(3)]
	public ushort EndBeat { get; set; }

	[FieldOrder(4)]
	public uint Color { get; set; }
}
