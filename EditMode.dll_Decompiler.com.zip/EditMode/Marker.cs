using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class Marker
{
	[FieldOrder(0)]
	public uint BarIndex { get; set; }

	[FieldOrder(1)]
	public MColor ColorID { get; set; }
}
