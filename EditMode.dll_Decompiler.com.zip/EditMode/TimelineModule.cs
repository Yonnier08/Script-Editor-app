using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class TimelineModule
{
	[FieldOrder(0)]
	public byte AllOptions { get; set; }

	[FieldOrder(1)]
	public byte ShowModel { get; set; }

	[FieldOrder(2)]
	public byte ShowCustomization { get; set; }

	[FieldOrder(3)]
	public byte ShowShadow { get; set; }

	[FieldOrder(4)]
	public byte CharPosition { get; set; }

	[FieldOrder(5)]
	public byte Animation { get; set; }

	[FieldOrder(6)]
	public byte Items { get; set; }

	[FieldOrder(7)]
	public byte Expression { get; set; }

	[FieldOrder(8)]
	public byte FacialEffect { get; set; }

	[FieldOrder(9)]
	public byte LineOfSight { get; set; }

	[FieldOrder(10)]
	public byte Blink { get; set; }

	[FieldOrder(11)]
	public byte LeftHand { get; set; }

	[FieldOrder(12)]
	public byte RightHand { get; set; }

	[FieldOrder(13)]
	public byte LipMovement { get; set; }
}
