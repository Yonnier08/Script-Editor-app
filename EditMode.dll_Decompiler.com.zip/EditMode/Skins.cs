namespace EditMode;

public enum Skins : uint
{
	DEFAULT_SKIN = 0u,
	GOLD_SKIN = 1u,
	PLATINUM_SKIN = 2u,
	MIKU_Concept = 3u,
	RIN_Concept = 4u,
	LEN_Concept = 5u,
	LUKA_Concept = 6u,
	KAITO_Concept = 7u,
	MEIKO_Concept = 8u,
	ALL_STARS_Rainbow_Music = 9u,
	ミクダヨーがいっぱい = 10u,
	ミクナノー_Flower = 11u,
	Main_Visual_A = 12u,
	Main_Visual_B = 13u,
	サマーメモリー_Brown = 17u,
	ねこねこケープ_Stripe = 20u,
	MIKU_NEKO = 23u,
	RIN_Red_Black = 26u,
	LEN_Rainbow = 30u,
	RIN_鶴の構え = 33u,
	LEN_虎の構え = 34u,
	イノセント_アムール_Rose = 36u,
	LUKA_Flower = 39u,
	ALL_STARS_Music = 41u,
	レクイエム_Red_Rose = 42u,
	MEIKO_Speaker = 44u,
	ピエレッタ_Circus = 47u
}
