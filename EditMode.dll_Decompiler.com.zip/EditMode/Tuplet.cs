namespace EditMode;

public enum Tuplet : uint
{
	Triplet = 1u,
	Sextuplet
}
