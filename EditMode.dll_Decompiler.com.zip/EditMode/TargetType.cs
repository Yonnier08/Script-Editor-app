namespace EditMode;

public enum TargetType : uint
{
	sankaku = 0u,
	maru = 1u,
	batsu = 2u,
	shikaku = 3u,
	sankaku_w = 4u,
	maru_w = 5u,
	batsu_w = 6u,
	shikaku_w = 7u,
	sankaku_long = 8u,
	maru_long = 9u,
	batsu_long = 10u,
	shikaku_long = 11u,
	touch = 12u,
	touch_w = 14u,
	touch_ch0 = 15u,
	touch_ch = 16u,
	touch_rush = 17u,
	sankaku_touch = 18u,
	maru_touch = 19u,
	batsu_touch = 20u,
	shikaku_touch = 21u,
	touch_link = 22u,
	touch_link_end = 23u,
	sankaku_rush = 25u,
	maru_rush = 26u,
	batsu_rush = 27u,
	shikaku_rush = 28u
}
