namespace EditMode;

public enum Shader : short
{
	標準,
	古写真,
	インスタント,
	ソフト,
	あざやか,
	コントラスト,
	うす暗い,
	うす明るい,
	シネマ_赤,
	シネマ_青,
	モノクロ,
	セピア,
	赤い空
}
