using System;
using BinarySerialization;

namespace EditMode;

[Serializable]
public class PlayerMotion
{
	[FieldOrder(0)]
	public uint Time { get; set; }

	[FieldOrder(1)]
	public byte Unknown1 { get; set; }

	[FieldOrder(2)]
	public byte Unknown2 { get; set; }

	[FieldOrder(3)]
	public byte Unknown3 { get; set; }

	[FieldOrder(4)]
	public byte Unknown4 { get; set; }

	[FieldOrder(5)]
	public float PlaybackSpeed { get; set; } = 1f;


	[FieldOrder(6)]
	public uint Empty1 { get; set; }

	[FieldOrder(7)]
	public Motion MotionID1 { get; set; } = Motion.CMN_EDT_VITA01_IDLE;


	[FieldOrder(8)]
	public float PlaybackStartTime { get; set; }

	[FieldOrder(9)]
	public int Interpolation { get; set; }

	[FieldOrder(10)]
	public int Unknown5 { get; set; } = -1;


	[FieldOrder(11)]
	public int Unknown6 { get; set; } = -1;


	[FieldOrder(12)]
	public int Empty2 { get; set; }

	[FieldOrder(13)]
	public uint MotionID2 { get; set; } = 1830730858u;

}
