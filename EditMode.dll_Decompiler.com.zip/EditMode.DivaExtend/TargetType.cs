namespace EditMode.DivaExtend;

public enum TargetType
{
	sankaku,
	maru,
	batsu,
	shikaku,
	sankaku_w,
	maru_w,
	batsu_w,
	shikaku_w,
	sankaku_long,
	maru_long,
	batsu_long,
	shikaku_long
}
