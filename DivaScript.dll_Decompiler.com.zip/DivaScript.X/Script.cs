using System;
using System.Collections.Generic;
using System.IO;
using MiscUtil.Conversion;
using MiscUtil.IO;

namespace DivaScript.X;

public class Script
{
	public static int GetParameterCount(Opcode opcode)
	{
		return opcode switch
		{
			Opcode.END => 0, 
			Opcode.TIME => 1, 
			Opcode.MIKU_MOVE => 4, 
			Opcode.MIKU_ROT => 2, 
			Opcode.MIKU_DISP => 2, 
			Opcode.MIKU_SHADOW => 2, 
			Opcode.TARGET => 12, 
			Opcode.SET_MOTION => 4, 
			Opcode.SET_PLAYDATA => 2, 
			Opcode.EFFECT => 6, 
			Opcode.FADEIN_FIELD => 2, 
			Opcode.EFFECT_OFF => 1, 
			Opcode.SET_CAMERA => 6, 
			Opcode.DATA_CAMERA => 2, 
			Opcode.CHANGE_FIELD => 2, 
			Opcode.HIDE_FIELD => 1, 
			Opcode.MOVE_FIELD => 3, 
			Opcode.FADEOUT_FIELD => 2, 
			Opcode.EYE_ANIM => 3, 
			Opcode.MOUTH_ANIM => 5, 
			Opcode.HAND_ANIM => 5, 
			Opcode.LOOK_ANIM => 4, 
			Opcode.EXPRESSION => 4, 
			Opcode.LOOK_CAMERA => 5, 
			Opcode.LYRIC => 2, 
			Opcode.MUSIC_PLAY => 0, 
			Opcode.MODE_SELECT => 2, 
			Opcode.EDIT_MOTION => 4, 
			Opcode.BAR_TIME_SET => 2, 
			Opcode.SHADOWHEIGHT => 2, 
			Opcode.EDIT_FACE => 1, 
			Opcode.DUMMY => 21, 
			Opcode.PV_END => 0, 
			Opcode.SHADOWPOS => 3, 
			Opcode.EDIT_LYRIC => 2, 
			Opcode.EDIT_TARGET => 5, 
			Opcode.EDIT_MOUTH => 1, 
			Opcode.SET_CHARA => 1, 
			Opcode.EDIT_MOVE => 7, 
			Opcode.EDIT_SHADOW => 1, 
			Opcode.EDIT_EYELID => 1, 
			Opcode.EDIT_EYE => 2, 
			Opcode.EDIT_ITEM => 1, 
			Opcode.EDIT_EFFECT => 2, 
			Opcode.EDIT_DISP => 1, 
			Opcode.EDIT_HAND_ANIM => 2, 
			Opcode.AIM => 3, 
			Opcode.HAND_ITEM => 3, 
			Opcode.EDIT_BLUSH => 1, 
			Opcode.NEAR_CLIP => 2, 
			Opcode.CLOTH_WET => 2, 
			Opcode.LIGHT_ROT => 3, 
			Opcode.SCENE_FADE => 6, 
			Opcode.TONE_TRANS => 6, 
			Opcode.SATURATE => 1, 
			Opcode.FADE_MODE => 1, 
			Opcode.AUTO_BLINK => 2, 
			Opcode.PARTS_DISP => 3, 
			Opcode.TARGET_FLYING_TIME => 1, 
			Opcode.CHARA_SIZE => 2, 
			Opcode.CHARA_HEIGHT_ADJUST => 2, 
			Opcode.ITEM_ANIM => 4, 
			Opcode.CHARA_POS_ADJUST => 4, 
			Opcode.SCENE_ROT => 1, 
			Opcode.EDIT_MOT_SMOOTH_LEN => 2, 
			Opcode.PV_BRANCH_MODE => 1, 
			Opcode.DATA_CAMERA_START => 2, 
			Opcode.MOVIE_PLAY => 1, 
			Opcode.MOVIE_DISP => 1, 
			Opcode.WIND => 3, 
			Opcode.OSAGE_STEP => 3, 
			Opcode.OSAGE_MV_CCL => 3, 
			Opcode.CHARA_COLOR => 2, 
			Opcode.SE_EFFECT => 1, 
			Opcode.CHARA_SHADOW_QUALITY => 2, 
			Opcode.STAGE_SHADOW_QUALITY => 2, 
			Opcode.COMMON_LIGHT => 2, 
			Opcode.TONE_MAP => 2, 
			Opcode.IBL_COLOR => 2, 
			Opcode.REFLECTION => 2, 
			Opcode.CHROMATIC_ABERRATION => 3, 
			Opcode.STAGE_SHADOW => 2, 
			Opcode.REFLECTION_QUALITY => 2, 
			Opcode.PV_END_FADEOUT => 2, 
			Opcode.CREDIT_TITLE => 1, 
			Opcode.BAR_POINT => 1, 
			Opcode.BEAT_POINT => 1, 
			Opcode.RESERVE => 9, 
			Opcode.PV_AUTH_LIGHT_PRIORITY => 2, 
			Opcode.PV_CHARA_LIGHT => 3, 
			Opcode.PV_STAGE_LIGHT => 3, 
			Opcode.TARGET_EFFECT => 11, 
			Opcode.FOG => 3, 
			Opcode.BLOOM => 2, 
			Opcode.COLOR_CORRECTION => 3, 
			Opcode.DOF => 3, 
			Opcode.CHARA_ALPHA => 4, 
			Opcode.AUTO_CAPTURE_BEGIN => 1, 
			Opcode.MANUAL_CAPTURE => 1, 
			Opcode.TOON_EDGE => 3, 
			Opcode.SHIMMER => 3, 
			Opcode.ITEM_ALPHA => 4, 
			Opcode.MOVIE_CUT => 1, 
			Opcode.EDIT_CAMERA_BOX => 112, 
			Opcode.EDIT_STAGE_PARAM => 1, 
			Opcode.EDIT_CHANGE_FIELD => 1, 
			Opcode.MIKUDAYO_ADJUST => 7, 
			Opcode.LYRIC_2 => 2, 
			Opcode.LYRIC_READ => 2, 
			Opcode.LYRIC_READ_2 => 2, 
			Opcode.ANNOTATION => 5, 
			Opcode.STAGE_EFFECT => 2, 
			Opcode.SONG_EFFECT => 3, 
			Opcode.SONG_EFFECT_ATTACH => 3, 
			Opcode.LIGHT_AUTH => 2, 
			Opcode.FADE => 2, 
			Opcode.SET_STAGE_EFFECT_ENV => 2, 
			Opcode.COMMON_EFFECT_AET_FRONT => 2, 
			Opcode.COMMON_EFFECT_AET_FRONT_LOW => 2, 
			Opcode.COMMON_EFFECT_PARTICLE => 2, 
			Opcode.SONG_EFFECT_ALPHA_SORT => 3, 
			Opcode.LOOK_CAMERA_FACE_LIMIT => 5, 
			Opcode.ITEM_LIGHT => 3, 
			Opcode.CHARA_EFFECT => 3, 
			Opcode.MARKER => 2, 
			Opcode.CHARA_EFFECT_CHARA_LIGHT => 3, 
			Opcode.ENABLE_COMMON_LIGHT_TO_CHARA => 2, 
			Opcode.ENABLE_FXAA => 2, 
			Opcode.ENABLE_TEMPORAL_AA => 2, 
			Opcode.ENABLE_REFLECTION => 2, 
			Opcode.BANK_BRANCH => 2, 
			Opcode.BANK_END => 2, 
			Opcode.VR_LIVE_MOVIE => 2, 
			Opcode.VR_CHEER => 2, 
			Opcode.VR_CHARA_PSMOVE => 2, 
			Opcode.VR_MOVE_PATH => 2, 
			Opcode.VR_SET_BASE => 2, 
			Opcode.VR_TECH_DEMO_EFFECT => 2, 
			Opcode.VR_TRANSFORM => 2, 
			Opcode.GAZE => 2, 
			Opcode.TECH_DEMO_GESUTRE => 2, 
			Opcode.VR_CHEMICAL_LIGHT_COLOR => 2, 
			Opcode.VR_LIVE_MOB => 5, 
			Opcode.VR_LIVE_HAIR_OSAGE => 9, 
			Opcode.VR_LIVE_LOOK_CAMERA => 9, 
			Opcode.VR_LIVE_CHEER => 5, 
			Opcode.VR_LIVE_GESTURE => 3, 
			Opcode.VR_LIVE_CLONE => 7, 
			Opcode.VR_LOOP_EFFECT => 7, 
			Opcode.VR_LIVE_ONESHOT_EFFECT => 6, 
			Opcode.VR_LIVE_PRESENT => 9, 
			Opcode.VR_LIVE_TRANSFORM => 5, 
			Opcode.VR_LIVE_FLY => 5, 
			Opcode.VR_LIVE_CHARA_VOICE => 2, 
			_ => -1, 
		};
	}

	internal static List<PvCommand> ParseFile(string filePath, bool isBigEndian)
	{
		if (!File.Exists(filePath))
		{
			throw new FileNotFoundException();
		}
		List<PvCommand> list = new List<PvCommand>();
		FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read)
		{
			Position = 72L
		};
		using (EndianBinaryReader endianBinaryReader = (isBigEndian ? new EndianBinaryReader(EndianBitConverter.Big, fileStream) : new EndianBinaryReader(EndianBitConverter.Little, fileStream)))
		{
			int num = 0;
			do
			{
				List<int> list2 = new List<int>();
				Opcode opcode = (Opcode)endianBinaryReader.ReadUInt32();
				if (!Enum.IsDefined(typeof(Opcode), opcode))
				{
					break;
				}
				for (int i = 0; i < GetParameterCount(opcode); i++)
				{
					list2.Add(endianBinaryReader.ReadInt32());
				}
				num = ((opcode == Opcode.TIME) ? list2[0] : num);
				list.Add(new PvCommand(num, opcode.ToString(), list2));
			}
			while (fileStream.Position < fileStream.Length);
		}
		return list;
	}

	internal static void WriteToFile(string outputPath, List<PvCommand> commands, bool isBigEndian)
	{
		FileStream fileStream = new FileStream(outputPath, FileMode.Create);
		using (EndianBinaryWriter endianBinaryWriter = (isBigEndian ? new EndianBinaryWriter(EndianBitConverter.Big, fileStream) : new EndianBinaryWriter(EndianBitConverter.Little, fileStream)))
		{
			char[] array = new char[4] { 'P', 'V', 'S', 'C' };
			for (byte b = 0; b < array.Length; b++)
			{
				endianBinaryWriter.Write((byte)array[b]);
			}
			for (byte b2 = 0; b2 < 17; b2++)
			{
				endianBinaryWriter.Write(0);
			}
			foreach (PvCommand command in commands)
			{
				if (!Enum.TryParse<Opcode>(command.Opcode, out var result))
				{
					continue;
				}
				endianBinaryWriter.Write((int)result);
				for (int i = 0; i < GetParameterCount(result); i++)
				{
					if (i < command.Parameters.Count)
					{
						endianBinaryWriter.Write(command.Parameters[i]);
					}
					else
					{
						endianBinaryWriter.Write(0);
					}
				}
			}
			char[] array2 = new char[4] { 'E', 'O', 'F', 'C' };
			for (byte b3 = 0; b3 < array2.Length; b3++)
			{
				endianBinaryWriter.Write((byte)array2[b3]);
			}
			for (byte b4 = 0; b4 < 6; b4++)
			{
				endianBinaryWriter.Write(0);
			}
		}
		fileStream.Dispose();
	}
}
