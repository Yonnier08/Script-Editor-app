using System;
using System.IO;
using MiscUtil.Conversion;

namespace MiscUtil.IO;

public class EndianBinaryReader : BinaryReader
{
	public EndianBitConverter Endian { get; }

	public EndianBinaryReader(EndianBitConverter endian, Stream input)
		: base(input)
	{
		Endian = endian;
	}

	public new int ReadInt32()
	{
		byte[] array = base.ReadBytes(4);
		if (Endian.IsBigEndian)
		{
			Array.Reverse((Array)array);
		}
		return BitConverter.ToInt32(array, 0);
	}

	public new uint ReadUInt32()
	{
		byte[] array = base.ReadBytes(4);
		if (Endian.IsBigEndian)
		{
			Array.Reverse((Array)array);
		}
		return BitConverter.ToUInt32(array, 0);
	}
}
