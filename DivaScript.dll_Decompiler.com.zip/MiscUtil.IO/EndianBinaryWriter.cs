using System;
using System.IO;
using MiscUtil.Conversion;

namespace MiscUtil.IO;

public class EndianBinaryWriter : BinaryWriter
{
	public EndianBitConverter Endian { get; }

	public EndianBinaryWriter(EndianBitConverter endian, Stream output)
		: base(output)
	{
		Endian = endian;
	}

	public new void Write(int value)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		if (Endian.IsBigEndian)
		{
			Array.Reverse((Array)bytes);
		}
		base.Write(bytes);
	}

	public new void Write(byte value)
	{
		base.Write(value);
	}

	public void Seek(long offset, SeekOrigin origin)
	{
		BaseStream.Seek(offset, origin);
	}
}
