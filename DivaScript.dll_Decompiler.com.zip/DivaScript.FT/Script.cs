using System;
using System.Collections.Generic;
using System.IO;
using MiscUtil.Conversion;
using MiscUtil.IO;

namespace DivaScript.FT;

public class Script
{
	public static int GetParameterCount(Opcode opcode)
	{
		return opcode switch
		{
			Opcode.END => 0, 
			Opcode.TIME => 1, 
			Opcode.MIKU_MOVE => 4, 
			Opcode.MIKU_ROT => 2, 
			Opcode.MIKU_DISP => 2, 
			Opcode.MIKU_SHADOW => 2, 
			Opcode.TARGET => 7, 
			Opcode.SET_MOTION => 4, 
			Opcode.SET_PLAYDATA => 2, 
			Opcode.EFFECT => 6, 
			Opcode.FADEIN_FIELD => 2, 
			Opcode.EFFECT_OFF => 1, 
			Opcode.SET_CAMERA => 6, 
			Opcode.DATA_CAMERA => 2, 
			Opcode.CHANGE_FIELD => 1, 
			Opcode.HIDE_FIELD => 1, 
			Opcode.MOVE_FIELD => 3, 
			Opcode.FADEOUT_FIELD => 2, 
			Opcode.EYE_ANIM => 3, 
			Opcode.MOUTH_ANIM => 5, 
			Opcode.HAND_ANIM => 5, 
			Opcode.LOOK_ANIM => 4, 
			Opcode.EXPRESSION => 4, 
			Opcode.LOOK_CAMERA => 5, 
			Opcode.LYRIC => 2, 
			Opcode.MUSIC_PLAY => 0, 
			Opcode.MODE_SELECT => 2, 
			Opcode.EDIT_MOTION => 4, 
			Opcode.BAR_TIME_SET => 2, 
			Opcode.SHADOWHEIGHT => 2, 
			Opcode.EDIT_FACE => 1, 
			Opcode.MOVE_CAMERA => 21, 
			Opcode.PV_END => 0, 
			Opcode.SHADOWPOS => 3, 
			Opcode.EDIT_LYRIC => 2, 
			Opcode.EDIT_TARGET => 5, 
			Opcode.EDIT_MOUTH => 1, 
			Opcode.SET_CHARA => 1, 
			Opcode.EDIT_MOVE => 7, 
			Opcode.EDIT_SHADOW => 1, 
			Opcode.EDIT_EYELID => 1, 
			Opcode.EDIT_EYE => 2, 
			Opcode.EDIT_ITEM => 1, 
			Opcode.EDIT_EFFECT => 2, 
			Opcode.EDIT_DISP => 1, 
			Opcode.EDIT_HAND_ANIM => 2, 
			Opcode.AIM => 3, 
			Opcode.HAND_ITEM => 3, 
			Opcode.EDIT_BLUSH => 1, 
			Opcode.NEAR_CLIP => 2, 
			Opcode.CLOTH_WET => 2, 
			Opcode.LIGHT_ROT => 3, 
			Opcode.SCENE_FADE => 6, 
			Opcode.TONE_TRANS => 6, 
			Opcode.SATURATE => 1, 
			Opcode.FADE_MODE => 1, 
			Opcode.AUTO_BLINK => 2, 
			Opcode.PARTS_DISP => 3, 
			Opcode.TARGET_FLYING_TIME => 1, 
			Opcode.CHARA_SIZE => 2, 
			Opcode.CHARA_HEIGHT_ADJUST => 2, 
			Opcode.ITEM_ANIM => 4, 
			Opcode.CHARA_POS_ADJUST => 4, 
			Opcode.SCENE_ROT => 1, 
			Opcode.MOT_SMOOTH => 2, 
			Opcode.PV_BRANCH_MODE => 1, 
			Opcode.DATA_CAMERA_START => 2, 
			Opcode.MOVIE_PLAY => 1, 
			Opcode.MOVIE_DISP => 1, 
			Opcode.WIND => 3, 
			Opcode.OSAGE_STEP => 3, 
			Opcode.OSAGE_MV_CCL => 3, 
			Opcode.CHARA_COLOR => 2, 
			Opcode.SE_EFFECT => 1, 
			Opcode.EDIT_MOVE_XYZ => 9, 
			Opcode.EDIT_EYELID_ANIM => 3, 
			Opcode.EDIT_INSTRUMENT_ITEM => 2, 
			Opcode.EDIT_MOTION_LOOP => 4, 
			Opcode.EDIT_EXPRESSION => 2, 
			Opcode.EDIT_EYE_ANIM => 3, 
			Opcode.EDIT_MOUTH_ANIM => 2, 
			Opcode.EDIT_CAMERA => 24, 
			Opcode.EDIT_MODE_SELECT => 1, 
			Opcode.PV_END_FADEOUT => 2, 
			Opcode.TARGET_FLAG => 1, 
			Opcode.ITEM_ANIM_ATTACH => 3, 
			Opcode.SHADOW_RANGE => 1, 
			Opcode.HAND_SCALE => 3, 
			Opcode.LIGHT_POS => 4, 
			Opcode.FACE_TYPE => 1, 
			Opcode.SHADOW_CAST => 2, 
			Opcode.EDIT_MOTION_F => 6, 
			Opcode.FOG => 3, 
			Opcode.BLOOM => 2, 
			Opcode.COLOR_COLLE => 3, 
			Opcode.DOF => 3, 
			Opcode.CHARA_ALPHA => 4, 
			Opcode.AOTO_CAP => 1, 
			Opcode.MAN_CAP => 1, 
			Opcode.TOON => 3, 
			Opcode.SHIMMER => 3, 
			Opcode.ITEM_ALPHA => 4, 
			Opcode.MOVIE_CUT_CHG => 2, 
			Opcode.CHARA_LIGHT => 3, 
			Opcode.STAGE_LIGHT => 3, 
			Opcode.AGEAGE_CTRL => 8, 
			Opcode.PSE => 2, 
			_ => -1, 
		};
	}

	internal static List<PvCommand> ParseFile(string filePath, bool isBigEndian)
	{
		if (!File.Exists(filePath))
		{
			throw new FileNotFoundException();
		}
		List<PvCommand> list = new List<PvCommand>();
		FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read)
		{
			Position = 4L
		};
		using (EndianBinaryReader endianBinaryReader = (isBigEndian ? new EndianBinaryReader(EndianBitConverter.Big, fileStream) : new EndianBinaryReader(EndianBitConverter.Little, fileStream)))
		{
			int num = 0;
			do
			{
				List<int> list2 = new List<int>();
				Opcode opcode = (Opcode)endianBinaryReader.ReadUInt32();
				if (!Enum.IsDefined(typeof(Opcode), opcode))
				{
					Console.WriteLine($"Breaking loop at position 0x{fileStream.Position:X2}, undefined opcode: 0x{(uint)opcode:X2}");
					Console.WriteLine("[ERROR] " + fileStream.Name);
					Console.WriteLine($"[ERROR] {fileStream.Position}/{fileStream.Length} bytes parsed");
					break;
				}
				int parameterCount = GetParameterCount(opcode);
				if (parameterCount < 0)
				{
					Console.WriteLine($"Breaking loop at position 0x{fileStream.Position:X2}, invalid parameter count for opcode: 0x{(uint)opcode:X2} - {opcode}");
					Console.WriteLine("[ERROR] " + fileStream.Name);
					Console.WriteLine($"[ERROR] {fileStream.Position}/{fileStream.Length} bytes parsed");
					break;
				}
				for (int i = 0; i < parameterCount; i++)
				{
					list2.Add(endianBinaryReader.ReadInt32());
				}
				num = ((opcode == Opcode.TIME) ? list2[0] : num);
				list.Add(new PvCommand(num, opcode.ToString(), list2));
			}
			while (fileStream.Position < fileStream.Length);
		}
		return list;
	}

	internal static void WriteToFile(string outputPath, List<PvCommand> commands, bool isBigEndian)
	{
		FileStream fileStream = new FileStream(outputPath, FileMode.Create);
		using (EndianBinaryWriter endianBinaryWriter = (isBigEndian ? new EndianBinaryWriter(EndianBitConverter.Big, fileStream) : new EndianBinaryWriter(EndianBitConverter.Little, fileStream)))
		{
			endianBinaryWriter.Write(335874337);
			foreach (PvCommand command in commands)
			{
				Opcode opcode;
				try
				{
					opcode = (Opcode)Enum.Parse(typeof(Opcode), command.Opcode);
				}
				catch (Exception)
				{
					continue;
				}
				if (!Enum.IsDefined(typeof(Opcode), opcode))
				{
					continue;
				}
				endianBinaryWriter.Write((int)opcode);
				for (int i = 0; i < GetParameterCount(opcode); i++)
				{
					if (i < command.Parameters.Count)
					{
						endianBinaryWriter.Write(command.Parameters[i]);
					}
					else
					{
						endianBinaryWriter.Write(0);
					}
				}
			}
		}
		fileStream.Dispose();
	}
}
