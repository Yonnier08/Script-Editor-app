namespace DivaScript;

public enum Format : byte
{
	DivaScript,
	F,
	F2,
	DT,
	FT,
	X,
	MGF,
	Mirai,
	Edit
}
