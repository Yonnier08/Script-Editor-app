using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DivaScript.F;
using DivaScript.F2;
using DivaScript.FT;
using DivaScript.MGF;
using DivaScript.Mirai;
using DivaScript.X;

namespace DivaScript;

public class PvScript
{
	private enum BranchMode
	{
		NULL = -1,
		DEFAULT,
		FAIL,
		SUCCESS
	}

	private class PvCommandBlock
	{
		public int Time { get; set; }

		public List<PvCommand> Commands { get; set; }

		public BranchMode BranchMode { get; set; }

		public PvCommandBlock(int time, BranchMode branchMode, params PvCommand[] commands)
		{
			Time = time;
			BranchMode = branchMode;
			Commands = new List<PvCommand>(commands);
		}
	}

	public delegate List<PvCommand> ParseFileDel(string path, bool isBigEndian);

	public delegate void WriteFileDel(string outputPath, List<PvCommand> commands, bool isBigEndian);

	public static string CommandsToString(List<PvCommand> commands)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (PvCommand command in commands)
		{
			stringBuilder.AppendLine(command.ToString());
		}
		return stringBuilder.ToString();
	}

	public static void WriteTextScript(string outputPath, List<PvCommand> commands)
	{
		StreamWriter streamWriter = File.CreateText(outputPath);
		streamWriter.Write(CommandsToString(commands));
		streamWriter.Dispose();
	}

	public static List<PvCommand> ParseTextFiles(string[] filePaths)
	{
		List<PvCommand> list = new List<PvCommand>();
		foreach (string path in filePaths)
		{
			List<PvCommand> list2 = ParseCommandStrings(File.ReadAllLines(path));
			foreach (PvCommand item in list2)
			{
				list.Add(item);
			}
		}
		return (filePaths.Length > 1) ? OrderListByTime(list) : list;
	}

	public static List<PvCommand> ParseCommandStrings(string[] commandStrings)
	{
		Regex regex = new Regex("[a-z_A-Z]+\\([^\\)]*\\)(\\.[^\\)]*\\))?");
		Regex regex2 = new Regex("[\\w\\s$]*\\(");
		Regex regex3 = new Regex("-?\\d+,? ?");
		List<PvCommand> list = new List<PvCommand>();
		int timeStamp = 0;
		foreach (string input in commandStrings)
		{
			foreach (object item in regex.Matches(input))
			{
				string text = regex2.Match(item.ToString()).ToString().Replace("(", "");
				List<int> list2 = new List<int>();
				foreach (object item2 in regex3.Matches(item.ToString()))
				{
					list2.Add(Convert.ToInt32(item2.ToString().Replace(",", "")));
				}
				if (text.ToUpper() == "TIME")
				{
					timeStamp = list2[0];
				}
				list.Add(new PvCommand(timeStamp, text, list2));
			}
		}
		return list;
	}

	public static void WriteBinaryScript(string outputPath, List<PvCommand> commands, Format format, bool isBigEndian = false)
	{
		WriteFileDel writeFileDel = DivaScript.F2.Script.WriteToFile;
		switch (format)
		{
		case Format.F:
			writeFileDel = DivaScript.F.Script.WriteToFile;
			break;
		case Format.F2:
			writeFileDel = DivaScript.F2.Script.WriteToFile;
			break;
		case Format.DT:
			throw new NotImplementedException();
		case Format.FT:
			writeFileDel = DivaScript.FT.Script.WriteToFile;
			break;
		case Format.X:
			writeFileDel = DivaScript.X.Script.WriteToFile;
			break;
		case Format.MGF:
			writeFileDel = DivaScript.MGF.Script.WriteToFile;
			break;
		case Format.Mirai:
			writeFileDel = DivaScript.Mirai.Script.WriteToFile;
			break;
		}
		writeFileDel(outputPath, commands, isBigEndian);
	}

	public static List<PvCommand> ParseBinaryScripts(string[] filePaths, Format format, bool isBigEndian = false)
	{
		ParseFileDel parseFileDel = DivaScript.F2.Script.ParseFile;
		switch (format)
		{
		case Format.F:
			parseFileDel = DivaScript.F.Script.ParseFile;
			break;
		case Format.F2:
			parseFileDel = DivaScript.F2.Script.ParseFile;
			break;
		case Format.DT:
			throw new NotImplementedException();
		case Format.FT:
			parseFileDel = DivaScript.FT.Script.ParseFile;
			break;
		case Format.X:
			parseFileDel = DivaScript.X.Script.ParseFile;
			break;
		case Format.MGF:
			parseFileDel = DivaScript.MGF.Script.ParseFile;
			break;
		case Format.Mirai:
			parseFileDel = DivaScript.Mirai.Script.ParseFile;
			break;
		}
		if (filePaths.Length > 1)
		{
			filePaths = filePaths.OrderByDescending((string p) => Path.GetFileName(p)).ToArray();
		}
		List<PvCommand>[] array = new List<PvCommand>[filePaths.Length];
		for (int i = 0; i < filePaths.Length; i++)
		{
			array[i] = parseFileDel(filePaths[i], isBigEndian);
		}
		return (filePaths.Length == 1) ? array[0] : MergeCommands(array, DetermineBarchModes(filePaths));
	}

	private static BranchMode[] DetermineBarchModes(string[] filePaths)
	{
		int num = filePaths.Length;
		string[] array = new string[num];
		bool[] array2 = new bool[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = Path.GetFileNameWithoutExtension(filePaths[i]);
			array2[i] = containsSuccess(array[i]);
		}
		BranchMode[] array3 = new BranchMode[array2.Length];
		if (array2.Any((bool c) => c))
		{
			for (int j = 0; j < num; j++)
			{
				array3[j] = (array2[j] ? BranchMode.SUCCESS : ((!ContainsDifficulty(array[j])) ? BranchMode.FAIL : BranchMode.DEFAULT));
			}
		}
		return array3;
		static bool ContainsDifficulty(string fileName)
		{
			return fileName.Contains("easy") || fileName.Contains("normal") || fileName.Contains("hard") || fileName.Contains("extreme");
		}
		static bool containsSuccess(string fileName)
		{
			return fileName.Contains("success");
		}
	}

	private static List<PvCommand> MergeCommands(List<PvCommand>[] unsortedCommandsLists, BranchMode[] branchModes)
	{
		bool flag = branchModes.Any((BranchMode m) => m != BranchMode.DEFAULT);
		List<PvCommandBlock>[] array = new List<PvCommandBlock>[unsortedCommandsLists.Length];
		for (int i = 0; i < unsortedCommandsLists.Length; i++)
		{
			List<PvCommand> list = unsortedCommandsLists[i];
			List<PvCommandBlock> list2 = (array[i] = new List<PvCommandBlock>(list.Count));
			BranchMode branchMode = branchModes[i];
			int num = 0;
			for (int j = 0; j < list.Count; j++)
			{
				PvCommand pvCommand = list[j];
				int timeStamp = pvCommand.TimeStamp;
				if (flag && pvCommand.Opcode == "PV_BRANCH_MODE" && pvCommand.Parameters.Count >= 1)
				{
					branchMode = (BranchMode)pvCommand.Parameters[0];
				}
				if (j == 0 || num != timeStamp)
				{
					list2.Add(new PvCommandBlock(timeStamp, branchMode, pvCommand));
				}
				else
				{
					list2[list2.Count - 1].Commands.Add(pvCommand);
				}
				num = timeStamp;
			}
		}
		int capacity = unsortedCommandsLists.Sum((List<PvCommand> c) => c.Count);
		List<PvCommand> list3 = new List<PvCommand>(capacity);
		BranchMode branchMode2 = BranchMode.NULL;
		bool flag2 = false;
		foreach (PvCommandBlock item in from b in array.SelectMany((List<PvCommandBlock> b) => b)
			orderby b.Time
			select b)
		{
			for (int k = 0; k < item.Commands.Count; k++)
			{
				PvCommand pvCommand2 = item.Commands[k];
				if (flag && k == 1)
				{
					if (item.BranchMode == BranchMode.SUCCESS)
					{
						flag2 = true;
					}
					if (!flag2 && item.BranchMode == BranchMode.FAIL)
					{
						item.BranchMode = BranchMode.DEFAULT;
					}
					if (branchMode2 != item.BranchMode)
					{
						list3.Add(new PvCommand(item.Time, "PV_BRANCH_MODE", (int)item.BranchMode));
					}
					branchMode2 = item.BranchMode;
				}
				if (pvCommand2.Opcode != "END" && (!flag || pvCommand2.Opcode != "PV_BRANCH_MODE"))
				{
					list3.Add(pvCommand2);
				}
			}
		}
		list3.Add(new PvCommand((list3.LastOrDefault()?.TimeStamp).GetValueOrDefault(), "END"));
		return list3;
	}

	public static List<PvCommand> OrderListByTime(List<PvCommand> commands)
	{
		return commands.OrderBy((PvCommand t) => t.TimeStamp).ThenBy((PvCommand o) => o.GenericCommand).ToList();
	}

	public static List<PvCommand> AddTimeCommands(List<PvCommand> commands)
	{
		commands = OrderListByTime(commands);
		List<PvCommand> list = new List<PvCommand>();
		int num = int.MinValue;
		foreach (PvCommand command in commands)
		{
			if (command.Opcode.ToUpper() != "TIME")
			{
				if (command.TimeStamp != num)
				{
					list.Add(new PvCommand(command.TimeStamp, "TIME", new List<int> { command.TimeStamp }));
				}
				num = command.TimeStamp;
			}
		}
		commands.AddRange(list);
		return commands;
	}
}
