using System;
using System.Collections.Generic;
using System.Linq;

namespace DivaScript;

public class PvCommand
{
	private string opcode;

	public string Opcode
	{
		get
		{
			return opcode;
		}
		set
		{
			opcode = value;
		}
	}

	internal Command GenericCommand
	{
		get
		{
			Command result = Command.UNKNOWN_COMMAND;
			Enum.TryParse<Command>(Opcode, out result);
			return result;
		}
	}

	public int TimeStamp { get; set; }

	public TimeSpan TimeSpan => TimeSpan.FromMilliseconds((double)TimeStamp / 100.0);

	public List<int> Parameters { get; set; }

	public PvCommand(int timeStamp, string opcode, List<int> param)
	{
		Opcode = opcode;
		TimeStamp = timeStamp;
		Parameters = param;
	}

	public PvCommand(int timeStamp, string opcode, params int[] param)
	{
		Opcode = opcode;
		TimeStamp = timeStamp;
		Parameters = param.ToList();
	}

	public override string ToString()
	{
		string text = Opcode + "(";
		for (int i = 0; i < Parameters.Count; i++)
		{
			text += string.Format("{0}{1}", Parameters[i], (i < Parameters.Count - 1) ? ", " : "");
		}
		text += ");";
		return text.ToUpper();
	}
}
