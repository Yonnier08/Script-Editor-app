namespace MiscUtil.Conversion;

public class EndianBitConverter
{
	public static EndianBitConverter Big { get; } = new EndianBitConverter(isBig: true);


	public static EndianBitConverter Little { get; } = new EndianBitConverter(isBig: false);


	public bool IsBigEndian { get; }

	public EndianBitConverter(bool isBig)
	{
		IsBigEndian = isBig;
	}
}
