using System;
using System.Collections.Generic;
using System.IO;
using MiscUtil.Conversion;
using MiscUtil.IO;

namespace DivaScript.F2;

public class Script
{
	public static int GetParameterCount(Opcode opcode)
	{
		return opcode switch
		{
			Opcode.END => 0, 
			Opcode.TIME => 1, 
			Opcode.MIKU_MOVE => 4, 
			Opcode.MIKU_ROT => 2, 
			Opcode.MIKU_DISP => 2, 
			Opcode.MIKU_SHADOW => 2, 
			Opcode.TARGET => 12, 
			Opcode.SET_MOTION => 4, 
			Opcode.SET_PLAYDATA => 2, 
			Opcode.EFFECT => 6, 
			Opcode.FADEIN_FIELD => 2, 
			Opcode.EFFECT_OFF => 1, 
			Opcode.SET_CAMERA => 6, 
			Opcode.DATA_CAMERA => 2, 
			Opcode.CHANGE_FIELD => 2, 
			Opcode.HIDE_FIELD => 1, 
			Opcode.MOVE_FIELD => 3, 
			Opcode.FADEOUT_FIELD => 2, 
			Opcode.EYE_ANIM => 3, 
			Opcode.MOUTH_ANIM => 5, 
			Opcode.HAND_ANIM => 5, 
			Opcode.LOOK_ANIM => 4, 
			Opcode.EXPRESSION => 4, 
			Opcode.LOOK_CAMERA => 5, 
			Opcode.LYRIC => 2, 
			Opcode.MUSIC_PLAY => 0, 
			Opcode.MODE_SELECT => 2, 
			Opcode.EDIT_MOTION => 4, 
			Opcode.BAR_TIME_SET => 2, 
			Opcode.SHADOWHEIGHT => 2, 
			Opcode.EDIT_FACE => 1, 
			Opcode.MOVE_CAMERA => 21, 
			Opcode.PV_END => 0, 
			Opcode.SHADOWPOS => 3, 
			Opcode.EDIT_LYRIC => 2, 
			Opcode.EDIT_TARGET => 5, 
			Opcode.EDIT_MOUTH => 1, 
			Opcode.SET_CHARA => 1, 
			Opcode.EDIT_MOVE => 7, 
			Opcode.EDIT_SHADOW => 1, 
			Opcode.EDIT_EYELID => 1, 
			Opcode.EDIT_EYE => 2, 
			Opcode.EDIT_ITEM => 1, 
			Opcode.EDIT_EFFECT => 2, 
			Opcode.EDIT_DISP => 1, 
			Opcode.EDIT_HAND_ANIM => 2, 
			Opcode.AIM => 3, 
			Opcode.HAND_ITEM => 3, 
			Opcode.EDIT_BLUSH => 1, 
			Opcode.NEAR_CLIP => 2, 
			Opcode.CLOTH_WET => 2, 
			Opcode.LIGHT_ROT => 3, 
			Opcode.SCENE_FADE => 6, 
			Opcode.TONE_TRANS => 6, 
			Opcode.SATURATE => 1, 
			Opcode.FADE_MODE => 1, 
			Opcode.AUTO_BLINK => 2, 
			Opcode.PARTS_DISP => 3, 
			Opcode.TARGET_FLYING_TIME => 1, 
			Opcode.CHARA_SIZE => 2, 
			Opcode.CHARA_HEIGHT_ADJUST => 2, 
			Opcode.ITEM_ANIM => 4, 
			Opcode.CHARA_POS_ADJUST => 4, 
			Opcode.SCENE_ROT => 1, 
			Opcode.EDIT_MOT_SMOOTH_LEN => 2, 
			Opcode.PV_BRANCH_MODE => 1, 
			Opcode.DATA_CAMERA_START => 2, 
			Opcode.MOVIE_PLAY => 1, 
			Opcode.MOVIE_DISP => 1, 
			Opcode.WIND => 3, 
			Opcode.OSAGE_STEP => 3, 
			Opcode.OSAGE_MV_CCL => 3, 
			Opcode.CHARA_COLOR => 2, 
			Opcode.SE_EFFECT => 1, 
			Opcode.EDIT_MOVE_XYZ => 9, 
			Opcode.EDIT_EYELID_ANIM => 3, 
			Opcode.EDIT_INSTRUMENT_ITEM => 2, 
			Opcode.EDIT_MOTION_LOOP => 4, 
			Opcode.EDIT_EXPRESSION => 2, 
			Opcode.EDIT_EYE_ANIM => 3, 
			Opcode.EDIT_MOUTH_ANIM => 2, 
			Opcode.EDIT_CAMERA => 22, 
			Opcode.EDIT_MODE_SELECT => 1, 
			Opcode.PV_END_FADEOUT => 2, 
			Opcode.RESERVE0 => 1, 
			Opcode.RESERVE1 => 6, 
			Opcode.RESERVE2 => 1, 
			Opcode.RESERVE3 => 9, 
			Opcode.PV_AUTH_LIGHT_PRIORITY => 2, 
			Opcode.PV_CHARA_LIGHT => 3, 
			Opcode.PV_STAGE_LIGHT => 3, 
			Opcode.TARGET_EFFECT => 11, 
			Opcode.FOG => 3, 
			Opcode.BLOOM => 2, 
			Opcode.COLOR_CORRECTION => 3, 
			Opcode.DOF => 3, 
			Opcode.CHARA_ALPHA => 4, 
			Opcode.AUTO_CAPTURE_BEGIN => 1, 
			Opcode.MANUAL_CAPTURE => 1, 
			Opcode.TOON_EDGE => 3, 
			Opcode.SHIMMER => 3, 
			Opcode.ITEM_ALPHA => 4, 
			Opcode.MOVIE_CUT => 1, 
			Opcode.EDIT_CAMERA_BOX => 112, 
			Opcode.EDIT_STAGE_PARAM => 1, 
			Opcode.EDIT_CHANGE_FIELD => 1, 
			_ => -1, 
		};
	}

	internal static List<PvCommand> ParseFile(string filePath, bool isBigEndian)
	{
		if (!File.Exists(filePath))
		{
			throw new FileNotFoundException();
		}
		List<PvCommand> list = new List<PvCommand>();
		FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read)
		{
			Position = 72L
		};
		using (EndianBinaryReader endianBinaryReader = (isBigEndian ? new EndianBinaryReader(EndianBitConverter.Big, fileStream) : new EndianBinaryReader(EndianBitConverter.Little, fileStream)))
		{
			int num = 0;
			do
			{
				List<int> list2 = new List<int>();
				Opcode opcode = (Opcode)endianBinaryReader.ReadUInt32();
				if (!Enum.IsDefined(typeof(Opcode), opcode))
				{
					break;
				}
				for (int i = 0; i < GetParameterCount(opcode); i++)
				{
					list2.Add(endianBinaryReader.ReadInt32());
				}
				num = ((opcode == Opcode.TIME) ? list2[0] : num);
				list.Add(new PvCommand(num, opcode.ToString(), list2));
			}
			while (fileStream.Position < fileStream.Length);
		}
		return list;
	}

	internal static void WriteToFile(string outputPath, List<PvCommand> commands, bool isBigEndian)
	{
		FileStream output = new FileStream(outputPath, FileMode.Create);
		using (EndianBinaryWriter endianBinaryWriter = (isBigEndian ? new EndianBinaryWriter(EndianBitConverter.Big, output) : new EndianBinaryWriter(EndianBitConverter.Little, output)))
		{
			char[] array = new char[4] { 'P', 'V', 'S', 'C' };
			for (byte b = 0; b < array.Length; b++)
			{
				endianBinaryWriter.Write((byte)array[b]);
			}
			for (byte b2 = 0; b2 < 17; b2++)
			{
				endianBinaryWriter.Write(0);
			}
			foreach (PvCommand command in commands)
			{
				if (!Enum.TryParse<Opcode>(command.Opcode, out var result))
				{
					continue;
				}
				endianBinaryWriter.Write((int)result);
				for (int i = 0; i < GetParameterCount(result); i++)
				{
					if (i < command.Parameters.Count)
					{
						endianBinaryWriter.Write(command.Parameters[i]);
					}
					else
					{
						endianBinaryWriter.Write(0);
					}
				}
			}
			char[] array2 = new char[4] { 'E', 'O', 'F', 'C' };
			for (byte b3 = 0; b3 < array2.Length; b3++)
			{
				endianBinaryWriter.Write((byte)array2[b3]);
			}
			for (byte b4 = 0; b4 < 6; b4++)
			{
				endianBinaryWriter.Write(0);
			}
		}
		output = new FileStream(outputPath, FileMode.Open);
		using (EndianBinaryWriter endianBinaryWriter2 = new EndianBinaryWriter(EndianBitConverter.Little, output))
		{
			int num = (int)(output.Length - 72 - 24);
			int value = num;
			endianBinaryWriter2.Seek(4L, SeekOrigin.Begin);
			endianBinaryWriter2.Write(num);
			endianBinaryWriter2.Seek(20L, SeekOrigin.Begin);
			endianBinaryWriter2.Write(value);
		}
		output.Dispose();
	}
}
