using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class ObjectValueNode : ValueNode
{
	private object _cachedValue;

	private Type _valueType;

	public override object BoundValue => GetValue((ValueNode child) => child.BoundValue);

	public override object Value
	{
		get
		{
			if (_cachedValue != null)
			{
				return _cachedValue;
			}
			return GetValue((ValueNode child) => child.Value);
		}
		set
		{
			if (value == null)
			{
				return;
			}
			ObjectTypeNode obj = (ObjectTypeNode)base.TypeNode;
			Type type = value.GetType();
			ObjectTypeNode subTypeNode = obj.GetSubTypeNode(type);
			base.Children = subTypeNode.Children.Select((TypeNode child) => child.CreateSerializer(this)).ToList();
			foreach (ValueNode child in base.Children)
			{
				try
				{
					child.Value = child.TypeNode.ValueGetter?.Invoke(value);
				}
				catch (Exception)
				{
					if (!child.TypeNode.IsIgnored)
					{
						throw;
					}
				}
			}
			_valueType = value.GetType();
			_cachedValue = value;
		}
	}

	public ObjectValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		ThrowIfUnordered();
		ObjectSerializeOverride(stream, eventShuttle);
	}

	internal override Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		ThrowIfUnordered();
		return ObjectSerializeOverrideAsync(stream, eventShuttle, cancellationToken);
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		ThrowIfUnordered();
		ResolveValueType();
		if ((object)_valueType != null)
		{
			GenerateChildren();
			try
			{
				ObjectDeserializeOverride(stream, eventShuttle);
			}
			catch (EndOfStreamException)
			{
				_valueType = null;
			}
		}
		SkipPadding(stream);
	}

	internal override async Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		ResolveValueType();
		if ((object)_valueType != null)
		{
			GenerateChildren();
			try
			{
				await ObjectDeserializeOverrideAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			}
			catch (EndOfStreamException)
			{
				_valueType = null;
			}
		}
		await SkipPaddingAsync(stream, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	protected virtual void ObjectSerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		if (IsCustomNode(out var customValueNode))
		{
			customValueNode.Value = _cachedValue;
			customValueNode.SerializeOverride(stream, eventShuttle);
			return;
		}
		IEnumerable<ValueNode> serializableChildren = GetSerializableChildren();
		LazyBinarySerializationContext lazyContext = CreateLazySerializationContext();
		foreach (ValueNode item in serializableChildren)
		{
			EmitBeginSerialization(stream, item, lazyContext, eventShuttle);
			item.Serialize(stream, eventShuttle);
			EmitEndSerialization(stream, item, lazyContext, eventShuttle);
		}
	}

	protected virtual async Task ObjectSerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		if (IsCustomNode(out var customValueNode))
		{
			customValueNode.Value = _cachedValue;
			await customValueNode.SerializeOverrideAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			return;
		}
		IEnumerable<ValueNode> serializableChildren = GetSerializableChildren();
		LazyBinarySerializationContext lazyContext = CreateLazySerializationContext();
		foreach (ValueNode child in serializableChildren)
		{
			EmitBeginSerialization(stream, child, lazyContext, eventShuttle);
			await child.SerializeAsync(stream, eventShuttle, align: true, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			EmitEndSerialization(stream, child, lazyContext, eventShuttle);
		}
	}

	protected virtual void ObjectDeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		if (IsCustomNode(out var customValueNode))
		{
			customValueNode.DeserializeOverride(stream, eventShuttle);
			_cachedValue = customValueNode.Value;
			return;
		}
		LazyBinarySerializationContext lazyContext = CreateLazySerializationContext();
		foreach (ValueNode serializableChild in GetSerializableChildren())
		{
			EmitBeginDeserialization(stream, serializableChild, lazyContext, eventShuttle);
			serializableChild.Deserialize(stream, eventShuttle);
			EmitEndDeserialization(stream, serializableChild, lazyContext, eventShuttle);
		}
	}

	protected virtual async Task ObjectDeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		if (IsCustomNode(out var customValueNode))
		{
			await customValueNode.DeserializeOverrideAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			_cachedValue = customValueNode.Value;
			return;
		}
		LazyBinarySerializationContext lazyContext = CreateLazySerializationContext();
		foreach (ValueNode child in GetSerializableChildren())
		{
			EmitBeginDeserialization(stream, child, lazyContext, eventShuttle);
			await child.DeserializeAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			EmitEndDeserialization(stream, child, lazyContext, eventShuttle);
		}
	}

	protected override Type GetValueTypeOverride()
	{
		return _valueType;
	}

	private object GetValue(Func<ValueNode, object> childValueSelector)
	{
		if ((object)_valueType == null)
		{
			return null;
		}
		if (_valueType.GetTypeInfo().IsAbstract)
		{
			return null;
		}
		ObjectTypeNode objectTypeNode = (ObjectTypeNode)base.TypeNode;
		if (objectTypeNode.IsIgnored)
		{
			return _cachedValue;
		}
		ObjectTypeNode subTypeNode = objectTypeNode.GetSubTypeNode(_valueType);
		if ((object)subTypeNode.Constructor == null)
		{
			throw new InvalidOperationException("No public constructors.");
		}
		object obj;
		IEnumerable<ValueNode> enumerable;
		if (subTypeNode.ConstructorParameterNames.Length == 0)
		{
			obj = subTypeNode.CompiledConstructor();
			enumerable = base.Children.ToList();
		}
		else
		{
			IEnumerable<ValueNode> serializableChildren = GetSerializableChildren();
			List<ValueNode> list = (from parameter in subTypeNode.ConstructorParameterNames
				join serializableChild in serializableChildren on parameter.ToLower() equals serializableChild.Name.ToLower()
				select serializableChild).ToList();
			object[] parameters = list.Select(childValueSelector).ToArray();
			obj = subTypeNode.Constructor.Invoke(parameters);
			enumerable = base.Children.Except(list).ToList();
		}
		foreach (ValueNode item in enumerable)
		{
			Action<object, object> valueSetter = item.TypeNode.ValueSetter;
			if (valueSetter == null && !item.TypeNode.IsIgnored)
			{
				throw new InvalidOperationException("No public setter.");
			}
			valueSetter?.Invoke(obj, childValueSelector(item));
		}
		return obj;
	}

	private bool IsCustomNode(out ValueNode customValueNode)
	{
		TypeNode parent = base.TypeNode.Parent;
		if ((object)_valueType != null && (base.TypeNode.SubtypeBindings != null || parent.ItemSubtypeBindings != null || base.TypeNode.SubtypeFactoryBinding != null || parent.ItemSubtypeFactoryBinding != null))
		{
			ObjectTypeNode subTypeNode = ((ObjectTypeNode)base.TypeNode).GetSubTypeNode(_valueType);
			if (subTypeNode is CustomTypeNode)
			{
				customValueNode = subTypeNode.CreateSerializer(base.Parent);
				return true;
			}
		}
		customValueNode = null;
		return false;
	}

	private void EmitEndSerialization(BoundedStream stream, ValueNode child, LazyBinarySerializationContext lazyContext, EventShuttle eventShuttle)
	{
		if (eventShuttle != null && eventShuttle.HasSerializationSubscribers)
		{
			eventShuttle.OnMemberSerialized(this, child.Name, child.BoundValue, lazyContext, stream.GlobalPosition, stream.RelativePosition);
		}
	}

	private void EmitBeginSerialization(BoundedStream stream, ValueNode child, LazyBinarySerializationContext lazyContext, EventShuttle eventShuttle)
	{
		if (eventShuttle != null && eventShuttle.HasSerializationSubscribers)
		{
			eventShuttle.OnMemberSerializing(this, child.Name, lazyContext, stream.GlobalPosition, stream.RelativePosition);
		}
	}

	private void GenerateChildren()
	{
		ObjectTypeNode subTypeNode = ((ObjectTypeNode)base.TypeNode).GetSubTypeNode(_valueType);
		base.Children = new List<ValueNode>(subTypeNode.Children.Select((TypeNode child) => child.CreateSerializer(this)));
	}

	private void SkipPadding(BoundedStream stream)
	{
		FieldLength fieldLength = GetFieldLength();
		if (fieldLength != null && fieldLength > stream.RelativePosition)
		{
			FieldLength fieldLength2 = fieldLength - stream.RelativePosition;
			byte[] buffer = new byte[(int)fieldLength2.TotalByteCount];
			stream.Read(buffer, fieldLength2);
		}
	}

	private Task SkipPaddingAsync(BoundedStream stream, CancellationToken cancellationToken)
	{
		FieldLength fieldLength = GetFieldLength();
		if (fieldLength != null && fieldLength > stream.RelativePosition)
		{
			FieldLength fieldLength2 = fieldLength - stream.RelativePosition;
			byte[] buffer = new byte[(int)fieldLength2.TotalByteCount];
			return stream.ReadAsync(buffer, fieldLength2, cancellationToken);
		}
		return Task.CompletedTask;
	}

	private void ResolveValueType()
	{
		TypeNode parent = base.TypeNode.Parent;
		if (base.TypeNode.SubtypeBindings != null || base.TypeNode.SubtypeFactoryBinding != null || base.TypeNode.SubtypeDefaultAttribute != null)
		{
			SetValueType(base.TypeNode.SubtypeBindings, this, base.TypeNode.SubtypeAttributes, base.TypeNode.SubtypeFactoryBinding, base.TypeNode.SubtypeFactory, base.TypeNode.SubtypeDefaultAttribute);
		}
		if ((object)_valueType == null && (parent.ItemSubtypeBindings != null || parent.ItemSubtypeFactoryBinding != null || parent.ItemSubtypeDefaultAttribute != null))
		{
			SetValueType(parent.ItemSubtypeBindings, base.Parent, parent.ItemSubtypeAttributes, parent.ItemSubtypeFactoryBinding, parent.ItemSubtypeFactory, parent.ItemSubtypeDefaultAttribute);
		}
		if ((object)_valueType == null)
		{
			_valueType = base.TypeNode.Type;
		}
	}

	private void SetValueType(BindingCollection bindings, ValueNode bindingTarget, ReadOnlyCollection<SubtypeBaseAttribute> attributes, Binding subtypeFactoryBinding, ISubtypeFactory subtypeFactory, SubtypeDefaultBaseAttribute defaultAttribute)
	{
		if (bindings != null)
		{
			object subTypeValue = bindings.GetValue(bindingTarget);
			_valueType = attributes.Where((SubtypeBaseAttribute attribute) => attribute.BindingMode != BindingMode.OneWayToSource).SingleOrDefault((SubtypeBaseAttribute attribute) => subTypeValue.Equals(Convert.ChangeType(attribute.Value, subTypeValue.GetType(), null)))?.Subtype;
		}
		if ((object)_valueType == null && subtypeFactoryBinding != null)
		{
			object value = subtypeFactoryBinding.GetValue(bindingTarget);
			if (subtypeFactory.TryGetType(value, out var type))
			{
				_valueType = type;
			}
		}
		if ((object)_valueType == null && defaultAttribute != null)
		{
			_valueType = defaultAttribute.Subtype;
		}
	}

	private void EmitEndDeserialization(BoundedStream stream, ValueNode child, LazyBinarySerializationContext lazyContext, EventShuttle eventShuttle)
	{
		if (eventShuttle != null && eventShuttle.HasDeserializationSubscribers)
		{
			eventShuttle.OnMemberDeserialized(this, child.Name, child.Value, lazyContext, stream.GlobalPosition, stream.RelativePosition);
		}
	}

	private void EmitBeginDeserialization(BoundedStream stream, ValueNode child, LazyBinarySerializationContext lazyContext, EventShuttle eventShuttle)
	{
		if (eventShuttle != null && eventShuttle.HasDeserializationSubscribers)
		{
			eventShuttle.OnMemberDeserializing(this, child.Name, lazyContext, stream.GlobalPosition, stream.RelativePosition);
		}
	}

	private void ThrowIfUnordered()
	{
		TypeNode typeNode = ((ObjectTypeNode)base.TypeNode).UnorderedChildren?.FirstOrDefault();
		if (typeNode != null)
		{
			throw new InvalidOperationException($"'{typeNode.Name}' does not have a FieldOrder attribute.  " + "All serializable fields or properties in a class with more than one member must specify a FieldOrder attribute.");
		}
	}
}
