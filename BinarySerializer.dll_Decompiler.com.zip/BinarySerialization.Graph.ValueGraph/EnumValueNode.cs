using System;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class EnumValueNode : ValueValueNode
{
	public EnumValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		EnumInfo enumInfo = GetEnumInfo();
		object enumValue = GetEnumValue(enumInfo);
		SerializedType serializedType = enumInfo.SerializedType;
		int? enumValueLength = enumInfo.EnumValueLength;
		Serialize(stream, enumValue, serializedType, enumValueLength.HasValue ? ((FieldLength)enumValueLength.GetValueOrDefault()) : null);
	}

	private object GetEnumValue(EnumInfo enumInfo)
	{
		if (enumInfo.EnumValues == null)
		{
			return BoundValue;
		}
		return enumInfo.EnumValues[(Enum)BoundValue];
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		EnumInfo enumInfo = GetEnumInfo();
		SerializedType serializedType = enumInfo.SerializedType;
		int? enumValueLength = enumInfo.EnumValueLength;
		Deserialize(stream, serializedType, enumValueLength.HasValue ? ((FieldLength)enumValueLength.GetValueOrDefault()) : null);
		SetValueFromEnum();
	}

	internal override Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		EnumInfo enumInfo = GetEnumInfo();
		object enumValue = GetEnumValue(enumInfo);
		SerializedType serializedType = enumInfo.SerializedType;
		int? enumValueLength = enumInfo.EnumValueLength;
		return SerializeAsync(stream, enumValue, serializedType, enumValueLength.HasValue ? ((FieldLength)enumValueLength.GetValueOrDefault()) : null, cancellationToken);
	}

	internal override async Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		EnumInfo enumInfo = GetEnumInfo();
		EnumValueNode enumValueNode = this;
		SerializedType serializedType = enumInfo.SerializedType;
		int? enumValueLength = enumInfo.EnumValueLength;
		await enumValueNode.DeserializeAsync(stream, serializedType, enumValueLength.HasValue ? ((FieldLength)enumValueLength.GetValueOrDefault()) : null, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		SetValueFromEnum();
	}

	private EnumInfo GetEnumInfo()
	{
		return ((EnumTypeNode)base.TypeNode).EnumInfo;
	}

	private void SetValueFromEnum()
	{
		EnumInfo enumInfo = GetEnumInfo();
		object obj = GetValue(enumInfo.SerializedType);
		if (enumInfo.ValueEnums != null)
		{
			obj = enumInfo.ValueEnums[(string)obj];
		}
		object value = obj.ConvertTo(enumInfo.UnderlyingType);
		Value = Enum.ToObject(base.TypeNode.BaseSerializedType, value);
	}
}
