using System;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class CustomValueNode : ObjectValueNode
{
	public CustomValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	protected override void ObjectSerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		LazyBinarySerializationContext serializationContext = CreateLazySerializationContext();
		object boundValue = BoundValue;
		if (boundValue != null)
		{
			((boundValue as IBinarySerializable) ?? throw new InvalidOperationException("Must implement IBinarySerializable")).Serialize(stream, GetFieldEndianness(), serializationContext);
		}
	}

	protected override void ObjectDeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		LazyBinarySerializationContext serializationContext = CreateLazySerializationContext();
		IBinarySerializable binarySerializable = CreateBinarySerializable();
		binarySerializable.Deserialize(stream, GetFieldEndianness(), serializationContext);
		Value = binarySerializable;
	}

	protected override Task ObjectDeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		ObjectDeserializeOverride(stream, eventShuttle);
		return Task.CompletedTask;
	}

	protected override Task ObjectSerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		ObjectSerializeOverride(stream, eventShuttle);
		return Task.CompletedTask;
	}

	private IBinarySerializable CreateBinarySerializable()
	{
		return (IBinarySerializable)Activator.CreateInstance(base.TypeNode.Type);
	}
}
