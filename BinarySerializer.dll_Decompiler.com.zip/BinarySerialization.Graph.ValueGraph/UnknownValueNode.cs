using System;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class UnknownValueNode : ValueNode
{
	private object _cachedValue;

	public override object Value
	{
		get
		{
			return _cachedValue;
		}
		set
		{
			if (value != null)
			{
				Type type = value.GetType();
				if ((object)type == typeof(object))
				{
					throw new InvalidOperationException("Unable to serialize object.");
				}
				RootValueNode rootValueNode = (RootValueNode)new RootTypeNode(base.TypeNode.Parent, type).CreateSerializer(base.Parent);
				rootValueNode.EndiannessCallback = GetFieldEndianness;
				rootValueNode.EncodingCallback = GetFieldEncoding;
				rootValueNode.Value = value;
				base.Children.Add(rootValueNode.Child);
				_cachedValue = value;
			}
		}
	}

	public UnknownValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		foreach (ValueNode child in base.Children)
		{
			child.Serialize(stream, eventShuttle);
		}
	}

	internal override async Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		foreach (ValueNode child in base.Children)
		{
			await child.SerializeAsync(stream, eventShuttle, align: true, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		throw new InvalidOperationException("Deserializing object fields not supported.");
	}

	internal override Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		DeserializeOverride(stream, eventShuttle);
		return Task.CompletedTask;
	}
}
