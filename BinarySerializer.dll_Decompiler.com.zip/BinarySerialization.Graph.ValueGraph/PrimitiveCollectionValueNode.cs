using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal abstract class PrimitiveCollectionValueNode : CollectionValueNodeBase
{
	public override object Value { get; set; }

	public override object BoundValue
	{
		get
		{
			if (base.Bindings.Count > 0)
			{
				object obj = base.Bindings[0]();
				IEnumerable enumerableValue;
				if ((enumerableValue = obj as IEnumerable) == null)
				{
					throw new InvalidOperationException("Complex types cannot be binding sources for scalar values.");
				}
				if (base.Bindings.Count != 1)
				{
					List<IEnumerable> source = base.Bindings.Select((Func<object> binding) => binding() as IEnumerable).ToList();
					if (source.Any((IEnumerable o) => o == null))
					{
						throw new InvalidOperationException("Complex types cannot be binding sources for scalar values.");
					}
					if (source.Select((IEnumerable enumerable) => enumerable.Cast<object>()).Any((IEnumerable<object> enumerable) => !enumerable.SequenceEqual(enumerableValue.Cast<object>())))
					{
						throw new BindingException("Multiple bindings to a single source must have equivalent target values.");
					}
				}
				return CreateCollection(enumerableValue);
			}
			return Value;
		}
	}

	protected PrimitiveCollectionValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		ValueValueNode valueValueNode = (ValueValueNode)CreateChildSerializer();
		SerializedType serializedType = valueValueNode.TypeNode.GetSerializedType();
		FieldLength constFieldItemLength = GetConstFieldItemLength();
		object boundValue = BoundValue;
		long? constFieldCount = GetConstFieldCount();
		if (boundValue == null)
		{
			if (constFieldCount.HasValue)
			{
				object defaultValue = TypeNode.GetDefaultValue(serializedType);
				for (int i = 0; i < constFieldCount.Value; i++)
				{
					valueValueNode.Serialize(stream, defaultValue, serializedType, constFieldItemLength);
				}
			}
		}
		else
		{
			PrimitiveCollectionSerializeOverride(stream, boundValue, valueValueNode, serializedType, constFieldItemLength, constFieldCount);
			SerializeTermination(stream, eventShuttle);
		}
	}

	internal override async Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		ValueValueNode childSerializer = (ValueValueNode)CreateChildSerializer();
		SerializedType childSerializedType = childSerializer.TypeNode.GetSerializedType();
		FieldLength itemLength = GetConstFieldItemLength();
		object boundValue = BoundValue;
		long? count = GetConstFieldCount();
		if (boundValue == null)
		{
			if (count.HasValue)
			{
				object defaultValue = TypeNode.GetDefaultValue(childSerializedType);
				for (int i = 0; i < count.Value; i++)
				{
					await childSerializer.SerializeAsync(stream, defaultValue, childSerializedType, itemLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				}
			}
		}
		else
		{
			PrimitiveCollectionSerializeOverride(stream, boundValue, childSerializer, childSerializedType, itemLength, count);
			SerializeTermination(stream, eventShuttle);
		}
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		List<object> items = DeserializeCollection(stream, eventShuttle).ToList();
		CreateFinalCollection(items);
	}

	internal override async Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		CreateFinalCollection(await DeserializeCollectionAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false));
	}

	protected abstract void PrimitiveCollectionSerializeOverride(BoundedStream stream, object boundValue, ValueValueNode childSerializer, SerializedType childSerializedType, FieldLength itemLength, long? itemCount);

	protected abstract Task PrimitiveCollectionSerializeOverrideAsync(BoundedStream stream, object boundValue, ValueValueNode childSerializer, SerializedType childSerializedType, FieldLength itemLength, long? itemCount, CancellationToken cancellationToken);

	protected abstract object CreateCollection(long size);

	protected abstract object CreateCollection(IEnumerable enumerable);

	protected abstract void SetCollectionValue(object item, long index);

	protected override object GetLastItemValueOverride()
	{
		throw new InvalidOperationException("Not supported on primitive collections.  Use SerializeUntil attribute.");
	}

	private void CreateFinalCollection(List<object> items)
	{
		int count = items.Count;
		Value = CreateCollection(count);
		for (int i = 0; i < count; i++)
		{
			SetCollectionValue(items[i], i);
		}
	}

	private IEnumerable<object> DeserializeCollection(BoundedStream stream, EventShuttle eventShuttle)
	{
		ValueValueNode childSerializer = (ValueValueNode)CreateChildSerializer();
		SerializedType childSerializedType = childSerializer.TypeNode.GetSerializedType();
		object terminationValue = GetTerminationValue();
		ValueNode terminationChild = GetTerminationChild();
		long? itemLength = GetFieldItemLength();
		BinaryReader reader = new BinaryReader(stream);
		long count = GetFieldCount() ?? long.MaxValue;
		for (long i = 0L; i < count; i++)
		{
			if (ValueNode.EndOfStream(stream))
			{
				break;
			}
			if (CollectionValueNodeBase.IsTerminated(stream, terminationChild, terminationValue, eventShuttle))
			{
				break;
			}
			long? num = itemLength;
			childSerializer.Deserialize(reader, childSerializedType, num.HasValue ? ((FieldLength)num.GetValueOrDefault()) : null);
			yield return childSerializer.GetValue(childSerializedType);
		}
	}

	private async Task<List<object>> DeserializeCollectionAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		List<object> list = new List<object>();
		ValueValueNode childSerializer = (ValueValueNode)CreateChildSerializer();
		SerializedType childSerializedType = childSerializer.TypeNode.GetSerializedType();
		object terminationValue = GetTerminationValue();
		ValueNode terminationChild = GetTerminationChild();
		long? itemLength = GetFieldItemLength();
		AsyncBinaryReader reader = new AsyncBinaryReader(stream, GetFieldEncoding());
		long count = GetFieldCount() ?? long.MaxValue;
		for (long i = 0L; i < count; i++)
		{
			if (ValueNode.EndOfStream(stream))
			{
				break;
			}
			if (CollectionValueNodeBase.IsTerminated(stream, terminationChild, terminationValue, eventShuttle))
			{
				break;
			}
			long? num = itemLength;
			await childSerializer.DeserializeAsync(reader, childSerializedType, num.HasValue ? ((FieldLength)num.GetValueOrDefault()) : null, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			object value = childSerializer.GetValue(childSerializedType);
			list.Add(value);
		}
		return list;
	}
}
