using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal abstract class CollectionValueNodeBase : ValueNode
{
	protected CollectionValueNodeBase(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	protected ValueNode CreateChildSerializer()
	{
		return ((CollectionTypeNode)base.TypeNode).Child.CreateSerializer(this);
	}

	protected object GetTerminationValue()
	{
		return ((CollectionTypeNode)base.TypeNode).TerminationValue;
	}

	protected static bool IsTerminated(BoundedStream stream, ValueNode terminationChild, object terminationValue, EventShuttle eventShuttle)
	{
		if (terminationChild != null)
		{
			using StreamResetter streamResetter = new StreamResetter(stream);
			terminationChild.Deserialize(stream, eventShuttle);
			if (terminationChild.Value.Equals(terminationValue))
			{
				streamResetter.CancelReset();
				return true;
			}
		}
		return false;
	}

	protected void SerializeTermination(BoundedStream stream, EventShuttle eventShuttle)
	{
		CollectionTypeNode collectionTypeNode = (CollectionTypeNode)base.TypeNode;
		if (collectionTypeNode.TerminationChild != null)
		{
			ValueNode valueNode = collectionTypeNode.TerminationChild.CreateSerializer(this);
			valueNode.Value = collectionTypeNode.TerminationValue;
			valueNode.Serialize(stream, eventShuttle);
		}
	}

	protected async Task SerializeTerminationAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		CollectionTypeNode collectionTypeNode = (CollectionTypeNode)base.TypeNode;
		if (collectionTypeNode.TerminationChild != null)
		{
			ValueNode valueNode = collectionTypeNode.TerminationChild.CreateSerializer(this);
			valueNode.Value = collectionTypeNode.TerminationValue;
			await valueNode.SerializeAsync(stream, eventShuttle, align: true, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	protected ValueNode GetTerminationChild()
	{
		return ((CollectionTypeNode)base.TypeNode).TerminationChild?.CreateSerializer(this);
	}
}
