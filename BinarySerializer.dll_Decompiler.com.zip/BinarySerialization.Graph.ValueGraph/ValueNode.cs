using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal abstract class ValueNode : Node<ValueNode>
{
	public static readonly object UnsetValue = new object();

	private bool _visited;

	private readonly Dictionary<FieldValueAttributeBase, FieldValueAdapterStream> _fieldValueAttributeTaps;

	private readonly Dictionary<FieldValueAttributeBase, object> _fieldValueAttributeFinalValue;

	public TypeNode TypeNode { get; set; }

	public List<Func<object>> Bindings { get; set; }

	public abstract object Value { get; set; }

	public virtual object BoundValue => Value;

	public virtual bool Visited
	{
		get
		{
			return _visited;
		}
		set
		{
			foreach (ValueNode child in base.Children)
			{
				child.Visited = value;
			}
			_visited = value;
		}
	}

	protected ValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent)
	{
		base.Name = name;
		TypeNode = typeNode;
		base.Children = new List<ValueNode>();
		Bindings = new List<Func<object>>();
		_fieldValueAttributeTaps = typeNode.FieldValueAttributes?.ToDictionary((FieldValueAttributeBase attribute) => attribute, (FieldValueAttributeBase attribute) => (FieldValueAdapterStream)null);
		_fieldValueAttributeFinalValue = new Dictionary<FieldValueAttributeBase, object>();
	}

	private bool ShouldSerialize(Func<Binding, object> bindingValueSelector)
	{
		if (TypeNode.SerializeWhenBindings != null && !TypeNode.SerializeWhenBindings.Any((ConditionalBinding binding) => binding.IsSatisfiedBy(bindingValueSelector(binding))))
		{
			return false;
		}
		if (TypeNode.SerializeWhenNotBindings != null)
		{
			return !TypeNode.SerializeWhenNotBindings.All((ConditionalBinding binding) => binding.IsSatisfiedBy(bindingValueSelector(binding)));
		}
		return true;
	}

	public virtual void Bind()
	{
		TypeNode typeNode = TypeNode;
		typeNode.FieldLengthBindings?.Bind(this, () => MeasureOverride().ByteCount);
		typeNode.ItemLengthBindings?.Bind(this, () => from item in MeasureItemsOverride()
			select item.ByteCount);
		typeNode.FieldCountBindings?.Bind(this, () => CountOverride());
		typeNode.SubtypeBindings?.Bind(this, () => SubtypeBindingCallback(typeNode));
		if (typeNode.SubtypeFactoryBinding != null && typeNode.SubtypeFactoryBinding.BindingMode != BindingMode.OneWay)
		{
			typeNode.SubtypeFactoryBinding.Bind(this, () => SubtypeBindingCallback(typeNode));
		}
		TypeNode parent = typeNode.Parent;
		parent.ItemSubtypeBindings?.Bind(base.Parent, () => ItemSubtypeBindingCallback(typeNode));
		if (parent.ItemSubtypeFactoryBinding != null && parent.ItemSubtypeFactoryBinding.BindingMode != BindingMode.OneWay)
		{
			parent.ItemSubtypeFactoryBinding.Bind(base.Parent, () => ItemSubtypeBindingCallback(typeNode));
		}
		if (typeNode.ItemSerializeUntilBinding != null && typeNode.ItemSerializeUntilBinding.BindingMode != BindingMode.OneWay)
		{
			typeNode.ItemSerializeUntilBinding.Bind(this, GetLastItemValueOverride);
		}
		if (typeNode.FieldValueBindings != null)
		{
			for (int i = 0; i < typeNode.FieldValueBindings.Count; i++)
			{
				Binding fieldValueBinding = typeNode.FieldValueBindings[i];
				if (fieldValueBinding.BindingMode == BindingMode.OneWay)
				{
					continue;
				}
				FieldValueAttributeBase fieldValueAttribute = typeNode.FieldValueAttributes[i];
				fieldValueBinding.Bind(this, delegate
				{
					if (!Visited)
					{
						throw new InvalidOperationException("Reverse binding not allowed on FieldValue attributes.  Consider swapping source and target.");
					}
					ValueNode source = fieldValueBinding.GetSource(this);
					if (!source._fieldValueAttributeFinalValue.TryGetValue(fieldValueAttribute, out var value))
					{
						FieldValueAdapterStream fieldValueAdapterStream = source._fieldValueAttributeTaps[fieldValueAttribute];
						value = fieldValueAttribute.GetFinalValueInternal(fieldValueAdapterStream.State);
						source._fieldValueAttributeFinalValue.Add(fieldValueAttribute, value);
					}
					return value;
				});
			}
		}
		foreach (ValueNode child in base.Children)
		{
			child.Bind();
		}
	}

	public virtual void BindChecks()
	{
		TypeNode typeNode = TypeNode;
		if (typeNode.FieldValueBindings != null)
		{
			for (int i = 0; i < typeNode.FieldValueBindings.Count; i++)
			{
				Binding fieldValueBinding = typeNode.FieldValueBindings[i];
				if (fieldValueBinding.BindingMode == BindingMode.OneWayToSource)
				{
					continue;
				}
				FieldValueAttributeBase fieldValueAttribute = typeNode.FieldValueAttributes[i];
				fieldValueBinding.Bind(this, delegate
				{
					if (!Visited)
					{
						throw new InvalidOperationException("Reverse binding not allowed on FieldValue attributes.  Consider swapping source and target.");
					}
					ValueNode source = fieldValueBinding.GetSource(this);
					if (!source._fieldValueAttributeFinalValue.TryGetValue(fieldValueAttribute, out var value))
					{
						FieldValueAdapterStream fieldValueAdapterStream = source._fieldValueAttributeTaps[fieldValueAttribute];
						value = fieldValueAttribute.GetFinalValueInternal(fieldValueAdapterStream.State);
						source._fieldValueAttributeFinalValue.Add(fieldValueAttribute, value);
					}
					return value;
				});
			}
		}
		foreach (ValueNode child in base.Children)
		{
			child.BindChecks();
		}
	}

	internal void Serialize(BoundedStream stream, EventShuttle eventShuttle, bool align = true)
	{
		try
		{
			if (!ShouldSerialize((Binding binding) => binding.GetBoundValue(this)))
			{
				return;
			}
			if (align)
			{
				AlignLeft(stream, pad: true);
			}
			long? fieldOffset = GetFieldOffset();
			if (fieldOffset.HasValue)
			{
				using (new StreamResetter(stream))
				{
					stream.Position = fieldOffset.Value;
					SerializeInternal(stream, GetConstFieldLength, eventShuttle);
				}
			}
			else
			{
				SerializeInternal(stream, GetConstFieldLength, eventShuttle);
			}
			if (align)
			{
				AlignRight(stream, pad: true);
			}
		}
		catch (IOException)
		{
			throw;
		}
		catch (TimeoutException)
		{
			throw;
		}
		catch (Exception e)
		{
			ThrowSerializationException(e);
		}
		finally
		{
			Visited = true;
		}
	}

	internal async Task SerializeAsync(BoundedStream stream, EventShuttle eventShuttle, bool align, CancellationToken cancellationToken)
	{
		_ = 1;
		try
		{
			if (!ShouldSerialize((Binding binding) => binding.GetBoundValue(this)))
			{
				return;
			}
			if (align)
			{
				AlignLeft(stream, pad: true);
			}
			long? fieldOffset = GetFieldOffset();
			if (!fieldOffset.HasValue)
			{
				await SerializeInternalAsync(stream, GetConstFieldLength, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			}
			else
			{
				using (new StreamResetter(stream))
				{
					stream.Position = fieldOffset.Value;
					await SerializeInternalAsync(stream, GetConstFieldLength, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				}
			}
			if (align)
			{
				AlignRight(stream, pad: true);
			}
		}
		catch (IOException)
		{
			throw;
		}
		catch (TimeoutException)
		{
			throw;
		}
		catch (Exception e)
		{
			ThrowSerializationException(e);
		}
		finally
		{
			Visited = true;
		}
	}

	private void ThrowSerializationException(Exception e)
	{
		string arg = ((base.Name == null) ? $"type '{TypeNode.Type}'" : $"member '{base.Name}'");
		throw new InvalidOperationException($"Error serializing {arg}.  See inner exception for detail.", e);
	}

	internal void Deserialize(BoundedStream stream, EventShuttle eventShuttle)
	{
		try
		{
			if (!ShouldSerialize((Binding binding) => binding.GetValue(this)))
			{
				return;
			}
			AlignLeft(stream);
			long? fieldOffset = GetFieldOffset();
			if (fieldOffset.HasValue)
			{
				using (new StreamResetter(stream))
				{
					stream.Position = fieldOffset.Value;
					DeserializeInternal(stream, GetFieldLength, eventShuttle);
				}
			}
			else
			{
				DeserializeInternal(stream, GetFieldLength, eventShuttle);
			}
			AlignRight(stream);
		}
		catch (IOException)
		{
			throw;
		}
		catch (TimeoutException)
		{
			throw;
		}
		catch (Exception e)
		{
			ThrowDeserializationException(e);
		}
		finally
		{
			Visited = true;
		}
		BindChecks();
	}

	internal async Task DeserializeAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		_ = 1;
		try
		{
			if (!ShouldSerialize((Binding binding) => binding.GetValue(this)))
			{
				return;
			}
			AlignLeft(stream);
			long? fieldOffset = GetFieldOffset();
			if (!fieldOffset.HasValue)
			{
				await DeserializeInternalAsync(stream, GetFieldLength, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			}
			else
			{
				using (new StreamResetter(stream))
				{
					stream.Position = fieldOffset.Value;
					await DeserializeInternalAsync(stream, GetFieldLength, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				}
			}
			AlignRight(stream);
		}
		catch (IOException)
		{
			throw;
		}
		catch (Exception e)
		{
			ThrowDeserializationException(e);
		}
		finally
		{
			Visited = true;
		}
		BindChecks();
	}

	private void ThrowDeserializationException(Exception e)
	{
		string arg = ((base.Name == null) ? $"type '{TypeNode.Type}'" : $"member '{base.Name}'");
		throw new InvalidOperationException($"Error deserializing '{arg}'.  See inner exception for detail.", e);
	}

	internal LazyBinarySerializationContext CreateLazySerializationContext()
	{
		return new LazyBinarySerializationContext(new Lazy<BinarySerializationContext>(CreateSerializationContext));
	}

	internal abstract void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle);

	internal abstract Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken);

	internal abstract void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle);

	internal abstract Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken);

	protected IEnumerable<ValueNode> GetSerializableChildren()
	{
		return base.Children.Where((ValueNode child) => !child.TypeNode.IsIgnored);
	}

	protected FieldLength GetFieldLength()
	{
		long? numericValue = GetNumericValue(TypeNode.FieldLengthBindings);
		if (numericValue.HasValue)
		{
			return numericValue.Value;
		}
		FieldBitLengthAttribute fieldBitLengthAttribute = TypeNode.FieldBitLengthAttribute;
		if (fieldBitLengthAttribute != null)
		{
			return FieldLength.FromBitCount((int)fieldBitLengthAttribute.ConstLength);
		}
		ValueNode parent = base.Parent;
		if (parent?.TypeNode.ItemLengthBindings != null)
		{
			object value = parent.TypeNode.ItemLengthBindings.GetValue(parent);
			if (value.GetType().GetTypeInfo().IsPrimitive)
			{
				return Convert.ToInt64(value);
			}
		}
		return null;
	}

	protected FieldLength GetConstFieldLength()
	{
		long? constNumericValue = GetConstNumericValue(TypeNode.FieldLengthBindings);
		if (constNumericValue.HasValue)
		{
			long? num = constNumericValue;
			if (!num.HasValue)
			{
				return null;
			}
			return num.GetValueOrDefault();
		}
		FieldBitLengthAttribute fieldBitLengthAttribute = TypeNode.FieldBitLengthAttribute;
		if (fieldBitLengthAttribute != null)
		{
			return FieldLength.FromBitCount((int)fieldBitLengthAttribute.ConstLength);
		}
		return base.Parent?.GetConstFieldItemLength();
	}

	protected long? GetLeftFieldAlignment()
	{
		object obj = TypeNode.LeftFieldAlignmentBindings?.GetBoundValue(this);
		if (obj == null)
		{
			return null;
		}
		return Convert.ToInt64(obj);
	}

	protected long? GetRightFieldAlignment()
	{
		object obj = TypeNode.RightFieldAlignmentBindings?.GetBoundValue(this);
		if (obj == null)
		{
			return null;
		}
		return Convert.ToInt64(obj);
	}

	protected long? GetFieldCount()
	{
		return GetNumericValue(TypeNode.FieldCountBindings);
	}

	protected long? GetConstFieldCount()
	{
		return GetConstNumericValue(TypeNode.FieldCountBindings);
	}

	protected long? GetFieldItemLength()
	{
		return GetNumericValue(TypeNode.ItemLengthBindings);
	}

	protected FieldLength GetConstFieldItemLength()
	{
		long? constNumericValue = GetConstNumericValue(TypeNode.ItemLengthBindings);
		if (!constNumericValue.HasValue)
		{
			return null;
		}
		return constNumericValue.GetValueOrDefault();
	}

	protected long? GetFieldOffset()
	{
		return GetNumericValue(TypeNode.FieldOffsetBindings);
	}

	protected long? GetConstFieldOffset()
	{
		return GetConstNumericValue(TypeNode.FieldOffsetBindings);
	}

	protected virtual Endianness GetFieldEndianness()
	{
		Endianness endianness = Endianness.Inherit;
		object obj = TypeNode.FieldEndiannessBindings?.GetBoundValue(this);
		if (obj != null)
		{
			if (!(obj is Endianness))
			{
				throw new InvalidOperationException("FieldEndianness converters must return a valid Endianness.");
			}
			endianness = (Endianness)Enum.ToObject(typeof(Endianness), obj);
		}
		if (endianness == Endianness.Inherit && base.Parent != null)
		{
			endianness = base.Parent.GetFieldEndianness();
		}
		return endianness;
	}

	protected virtual Encoding GetFieldEncoding()
	{
		Encoding encoding = null;
		object obj = TypeNode.FieldEncodingBindings?.GetBoundValue(this);
		if (obj != null)
		{
			if (!(obj is Encoding))
			{
				throw new InvalidOperationException("FieldEncoding converters must return a valid Encoding.");
			}
			encoding = obj as Encoding;
		}
		if (encoding == null && base.Parent != null)
		{
			encoding = base.Parent.GetFieldEncoding();
		}
		return encoding;
	}

	protected virtual FieldLength MeasureOverride()
	{
		BoundedStream boundedStream = new BoundedStream(new NullStream(), base.Name);
		Serialize(boundedStream, null, align: false);
		return boundedStream.RelativePosition;
	}

	protected virtual IEnumerable<FieldLength> MeasureItemsOverride()
	{
		throw new InvalidOperationException("Not a collection field.");
	}

	protected virtual long CountOverride()
	{
		throw new InvalidOperationException("Not a collection field.");
	}

	protected virtual Type GetValueTypeOverride()
	{
		throw new InvalidOperationException("Can't set subtypes on this field.");
	}

	protected virtual object GetLastItemValueOverride()
	{
		throw new InvalidOperationException("Not a collection field.");
	}

	protected static bool EndOfStream(BoundedStream stream)
	{
		if (!stream.IsAtLimit)
		{
			return stream.AvailableForReading == FieldLength.Zero;
		}
		return true;
	}

	private object SubtypeBindingCallback(TypeNode typeNode)
	{
		Type valueTypeOverride = GetValueTypeOverride();
		if ((object)valueTypeOverride == null)
		{
			throw new InvalidOperationException("Binding targets must not be null.");
		}
		ObjectTypeNode objectTypeNode = (ObjectTypeNode)typeNode;
		if (typeNode.SubtypeBindings != null && objectTypeNode.SubTypeKeys.TryGetValue(valueTypeOverride, out var value))
		{
			return value;
		}
		if (typeNode.SubtypeFactory != null && typeNode.SubtypeFactory.TryGetKey(valueTypeOverride, out value))
		{
			return value;
		}
		if (typeNode.SubtypeDefaultAttribute != null && (object)valueTypeOverride == typeNode.SubtypeDefaultAttribute.Subtype)
		{
			return UnsetValue;
		}
		throw new InvalidOperationException($"No subtype specified for ${valueTypeOverride}");
	}

	private object ItemSubtypeBindingCallback(TypeNode typeNode)
	{
		Type valueTypeOverride = GetValueTypeOverride();
		if ((object)valueTypeOverride == null)
		{
			throw new InvalidOperationException("Binding targets must not be null.");
		}
		TypeNode parent = typeNode.Parent;
		ObjectTypeNode objectTypeNode = (ObjectTypeNode)typeNode;
		if (parent.ItemSubtypeBindings != null && objectTypeNode.SubTypeKeys.TryGetValue(valueTypeOverride, out var value))
		{
			return value;
		}
		if (parent.ItemSubtypeFactory != null && parent.ItemSubtypeFactory.TryGetKey(valueTypeOverride, out value))
		{
			return value;
		}
		if (parent.ItemSubtypeDefaultAttribute != null && (object)valueTypeOverride == parent.ItemSubtypeDefaultAttribute.Subtype)
		{
			return UnsetValue;
		}
		throw new InvalidOperationException($"No subtype specified for ${valueTypeOverride}");
	}

	private void SerializeInternal(BoundedStream stream, Func<FieldLength> maxLengthDelegate, EventShuttle eventShuttle)
	{
		stream = PrepareStream(stream, maxLengthDelegate);
		SerializeOverride(stream, eventShuttle);
		WritePadding(stream);
		FlushStream(stream);
	}

	private async Task SerializeInternalAsync(BoundedStream stream, Func<FieldLength> maxLengthDelegate, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		stream = PrepareStream(stream, maxLengthDelegate);
		await SerializeOverrideAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await WritePaddingAsync(stream, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await FlushStreamAsync(stream, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	private BoundedStream PrepareStream(BoundedStream stream, Func<FieldLength> maxLengthDelegate)
	{
		stream = new BoundedStream(stream, base.Name, maxLengthDelegate);
		if (TypeNode.FieldValueAttributes != null && TypeNode.FieldValueAttributes.Count > 0)
		{
			LazyBinarySerializationContext context = CreateLazySerializationContext();
			for (int i = 0; i < TypeNode.FieldValueAttributes.Count; i++)
			{
				FieldValueAttributeBase fieldValueAttributeBase = TypeNode.FieldValueAttributes[i];
				ValueNode source = TypeNode.FieldValueBindings[i].GetSource(this);
				if (!source._fieldValueAttributeTaps.TryGetValue(fieldValueAttributeBase, out var value) || fieldValueAttributeBase == value.Attribute)
				{
					object initialStateInternal = fieldValueAttributeBase.GetInitialStateInternal(context);
					value = new FieldValueAdapterStream(fieldValueAttributeBase, initialStateInternal);
					source._fieldValueAttributeTaps[fieldValueAttributeBase] = value;
				}
				stream = new TapStream(stream, value, base.Name);
			}
		}
		return stream;
	}

	private void FlushStream(BoundedStream stream)
	{
		if (TypeNode.FieldValueAttributes != null && TypeNode.FieldValueAttributes.Any())
		{
			stream.Flush();
		}
	}

	private async Task FlushStreamAsync(BoundedStream stream, CancellationToken cancellationToken)
	{
		if (TypeNode.FieldValueAttributes != null && TypeNode.FieldValueAttributes.Any())
		{
			await stream.FlushAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	private void AlignRight(BoundedStream stream, bool pad = false)
	{
		long? rightFieldAlignment = GetRightFieldAlignment();
		if (rightFieldAlignment.HasValue)
		{
			long? num = rightFieldAlignment;
			Align(stream, num.HasValue ? ((FieldLength)num.GetValueOrDefault()) : null, pad);
		}
	}

	private void AlignLeft(BoundedStream stream, bool pad = false)
	{
		long? leftFieldAlignment = GetLeftFieldAlignment();
		if (leftFieldAlignment.HasValue)
		{
			long? num = leftFieldAlignment;
			Align(stream, num.HasValue ? ((FieldLength)num.GetValueOrDefault()) : null, pad);
		}
	}

	private void Align(BoundedStream stream, FieldLength alignment, bool pad = false)
	{
		if (alignment == null)
		{
			throw new ArgumentNullException("alignment");
		}
		FieldLength relativePosition = stream.RelativePosition;
		FieldLength fieldLength = (alignment - relativePosition % alignment) % alignment;
		if (fieldLength == FieldLength.Zero)
		{
			return;
		}
		if (pad)
		{
			byte[] buffer = new byte[fieldLength.TotalByteCount];
			stream.Write(buffer, fieldLength);
			return;
		}
		for (int i = 0; i < (int)fieldLength.ByteCount; i++)
		{
			if (stream.ReadByte() < 0)
			{
				break;
			}
		}
	}

	private void DeserializeInternal(BoundedStream stream, Func<FieldLength> maxLengthDelegate, EventShuttle eventShuttle)
	{
		stream = PrepareStream(stream, maxLengthDelegate);
		DeserializeOverride(stream, eventShuttle);
		SkipPadding(stream);
		FlushStream(stream);
	}

	private async Task DeserializeInternalAsync(BoundedStream stream, Func<FieldLength> maxLengthDelegate, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		stream = PrepareStream(stream, maxLengthDelegate);
		await DeserializeOverrideAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await SkipPaddingAsync(stream, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await FlushStreamAsync(stream, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	private void WritePadding(BoundedStream stream)
	{
		ProcessPadding(stream, delegate(BoundedStream s, byte[] bytes, FieldLength length)
		{
			s.Write(bytes, length);
		});
	}

	private Task WritePaddingAsync(BoundedStream stream, CancellationToken cancellationToken)
	{
		return ProcessPaddingAsync(stream, async delegate(BoundedStream s, byte[] bytes, FieldLength length)
		{
			await s.WriteAsync(bytes, length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		});
	}

	private void SkipPadding(BoundedStream stream)
	{
		ProcessPadding(stream, delegate(BoundedStream s, byte[] bytes, FieldLength length)
		{
			s.Read(bytes, 0, (int)length.ByteCount);
		});
	}

	private Task SkipPaddingAsync(BoundedStream stream, CancellationToken cancellationToken)
	{
		return ProcessPaddingAsync(stream, async delegate(BoundedStream s, byte[] bytes, FieldLength length)
		{
			await s.ReadAsync(bytes, 0, (int)length.ByteCount, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		});
	}

	private void ProcessPadding(BoundedStream stream, Action<BoundedStream, byte[], FieldLength> streamOperation)
	{
		FieldLength constFieldLength = GetConstFieldLength();
		if (!(constFieldLength == null) && constFieldLength > stream.RelativePosition)
		{
			FieldLength fieldLength = constFieldLength - stream.RelativePosition;
			byte[] arg = new byte[(int)fieldLength.TotalByteCount];
			streamOperation(stream, arg, fieldLength);
		}
	}

	private async Task ProcessPaddingAsync(BoundedStream stream, Func<BoundedStream, byte[], FieldLength, Task> streamOperationAsync)
	{
		FieldLength constFieldLength = GetConstFieldLength();
		if (!(constFieldLength == null) && constFieldLength > stream.RelativePosition)
		{
			FieldLength fieldLength = constFieldLength - stream.RelativePosition;
			byte[] arg = new byte[(int)fieldLength.TotalByteCount];
			await streamOperationAsync(stream, arg, fieldLength).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	private long? GetNumericValue(IBinding binding)
	{
		object obj = binding?.GetValue(this);
		if (obj == null)
		{
			return null;
		}
		return Convert.ToInt64(obj);
	}

	private long? GetConstNumericValue(IBinding binding)
	{
		if (binding == null)
		{
			return null;
		}
		if (!binding.IsConst)
		{
			return null;
		}
		return Convert.ToInt64(binding.ConstValue);
	}

	private BinarySerializationContext CreateSerializationContext()
	{
		ValueNode parent = base.Parent;
		return new BinarySerializationContext(Value, parent?.Value, parent?.TypeNode.Type, parent?.CreateSerializationContext(), TypeNode.MemberInfo);
	}
}
