using System;
using System.Collections;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class PrimitiveListValueNode : PrimitiveCollectionValueNode
{
	public PrimitiveListValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	protected override void PrimitiveCollectionSerializeOverride(BoundedStream stream, object boundValue, ValueValueNode childSerializer, SerializedType childSerializedType, FieldLength itemLength, long? itemCount)
	{
		IList list = (IList)boundValue;
		PadList(ref list, itemCount);
		foreach (object item in list)
		{
			if (stream.IsAtLimit)
			{
				break;
			}
			childSerializer.Serialize(stream, item, childSerializedType, itemLength);
		}
	}

	protected override async Task PrimitiveCollectionSerializeOverrideAsync(BoundedStream stream, object boundValue, ValueValueNode childSerializer, SerializedType childSerializedType, FieldLength itemLength, long? itemCount, CancellationToken cancellationToken)
	{
		IList list = (IList)boundValue;
		PadList(ref list, itemCount);
		foreach (object item in list)
		{
			if (stream.IsAtLimit)
			{
				break;
			}
			await childSerializer.SerializeAsync(stream, item, childSerializedType, itemLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	protected override object CreateCollection(long size)
	{
		ListTypeNode obj = (ListTypeNode)base.TypeNode;
		Array array = Array.CreateInstance(obj.ChildType, (int)size);
		return Activator.CreateInstance(obj.Type, array);
	}

	protected override object CreateCollection(IEnumerable enumerable)
	{
		ListTypeNode typeNode = (ListTypeNode)base.TypeNode;
		return (from object item in enumerable
			select item.ConvertTo(typeNode.ChildType)).ToList();
	}

	protected override void SetCollectionValue(object item, long index)
	{
		IList obj = (IList)Value;
		ListTypeNode listTypeNode = (ListTypeNode)base.TypeNode;
		obj[(int)index] = item.ConvertTo(listTypeNode.ChildType);
	}

	protected override long CountOverride()
	{
		IList list = (IList)Value;
		if (list == null)
		{
			return 0L;
		}
		return list.Count;
	}

	private void PadList(ref IList list, long? itemCount)
	{
		if (itemCount.HasValue && list.Count != itemCount)
		{
			IList list2 = list;
			list = (IList)CreateCollection(itemCount.Value);
			for (int i = 0; i < Math.Min(list2.Count, list.Count); i++)
			{
				list[i] = list2[i];
			}
		}
	}
}
