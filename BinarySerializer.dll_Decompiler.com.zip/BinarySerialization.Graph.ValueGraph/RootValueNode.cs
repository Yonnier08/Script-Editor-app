using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class RootValueNode : ValueNode
{
	private static readonly Dictionary<Type, RootTypeNode> ContextCache = new Dictionary<Type, RootTypeNode>();

	private static readonly object ContextCacheLock = new object();

	public ValueNode Child { get; private set; }

	public override object Value
	{
		get
		{
			return Child?.Value;
		}
		set
		{
			Child = ((RootTypeNode)base.TypeNode).Child.CreateSerializer(this);
			Child.Value = value;
		}
	}

	public override object BoundValue => Child.BoundValue;

	public object Context
	{
		set
		{
			if (value != null)
			{
				RootValueNode rootValueNode = (RootValueNode)GetContextGraph(value.GetType()).CreateSerializer(this);
				rootValueNode.EncodingCallback = EncodingCallback;
				rootValueNode.EndiannessCallback = EndiannessCallback;
				rootValueNode.Value = value;
				rootValueNode.Child.Visited = true;
				base.Children.AddRange(rootValueNode.Child.Children);
			}
		}
	}

	public Func<Endianness> EndiannessCallback { get; set; }

	public Func<Encoding> EncodingCallback { get; set; }

	public RootValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	public override void Bind()
	{
		Child.Bind();
	}

	public override void BindChecks()
	{
		Child.BindChecks();
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		Child.Serialize(stream, eventShuttle);
	}

	internal override Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		return Child.SerializeAsync(stream, eventShuttle, align: true, cancellationToken);
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		Child = ((RootTypeNode)base.TypeNode).Child.CreateSerializer(this);
		Child.Deserialize(stream, eventShuttle);
	}

	internal override Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		Child = ((RootTypeNode)base.TypeNode).Child.CreateSerializer(this);
		return Child.DeserializeAsync(stream, eventShuttle, cancellationToken);
	}

	protected override Endianness GetFieldEndianness()
	{
		return EndiannessCallback();
	}

	protected override Encoding GetFieldEncoding()
	{
		return EncodingCallback();
	}

	private static RootTypeNode GetContextGraph(Type valueType)
	{
		lock (ContextCacheLock)
		{
			if (ContextCache.TryGetValue(valueType, out var value))
			{
				return value;
			}
			value = new RootTypeNode(valueType);
			ContextCache.Add(valueType, value);
			return value;
		}
	}
}
