using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal abstract class CollectionValueNode : CollectionValueNodeBase
{
	protected CollectionValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		List<ValueNode> list = GetSerializableChildren().ToList();
		SetTerminationValue(list);
		foreach (ValueNode item in list)
		{
			if (stream.IsAtLimit)
			{
				break;
			}
			BoundedStream stream2 = new BoundedStream(stream, base.Name, base.GetConstFieldItemLength);
			item.Serialize(stream2, eventShuttle);
		}
		SerializeTermination(stream, eventShuttle);
	}

	internal override async Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		List<ValueNode> list = GetSerializableChildren().ToList();
		SetTerminationValue(list);
		foreach (ValueNode item in list)
		{
			if (!stream.IsAtLimit)
			{
				BoundedStream stream2 = new BoundedStream(stream, base.Name, base.GetConstFieldItemLength);
				await item.SerializeAsync(stream2, eventShuttle, align: true, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				continue;
			}
			break;
		}
		await SerializeTerminationAsync(stream, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		object terminationValue = GetTerminationValue();
		ValueNode terminationChild = GetTerminationChild();
		object itemTerminationValue = GetItemTerminationValue();
		using IEnumerator<long> enumerator = GetItemLengths()?.GetEnumerator();
		long num = GetFieldCount() ?? long.MaxValue;
		for (long num2 = 0L; num2 < num; num2++)
		{
			if (ValueNode.EndOfStream(stream))
			{
				break;
			}
			if (CollectionValueNodeBase.IsTerminated(stream, terminationChild, terminationValue, eventShuttle))
			{
				break;
			}
			enumerator?.MoveNext();
			long? itemLength = enumerator?.Current;
			BoundedStream stream2 = ((!itemLength.HasValue) ? new BoundedStream(stream, base.Name) : new BoundedStream(stream, base.Name, delegate
			{
				long? num3 = itemLength;
				return (!num3.HasValue) ? null : ((FieldLength)num3.GetValueOrDefault());
			}));
			ValueNode valueNode = CreateChildSerializer();
			using (StreamResetter streamResetter = new StreamResetter(stream2))
			{
				valueNode.Deserialize(stream2, eventShuttle);
				if (IsTerminated(valueNode, itemTerminationValue))
				{
					ProcessLastItem(streamResetter, valueNode);
					break;
				}
				streamResetter.CancelReset();
			}
			base.Children.Add(valueNode);
		}
	}

	internal override async Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		object terminationValue = GetTerminationValue();
		ValueNode terminationChild = GetTerminationChild();
		object itemTerminationValue = GetItemTerminationValue();
		using IEnumerator<long> itemLengthEnumerator = GetItemLengths()?.GetEnumerator();
		long count = GetFieldCount() ?? long.MaxValue;
		for (long i = 0L; i < count; i++)
		{
			if (ValueNode.EndOfStream(stream))
			{
				break;
			}
			if (CollectionValueNodeBase.IsTerminated(stream, terminationChild, terminationValue, eventShuttle))
			{
				break;
			}
			itemLengthEnumerator?.MoveNext();
			long? itemLength = itemLengthEnumerator?.Current;
			BoundedStream stream2 = ((!itemLength.HasValue) ? new BoundedStream(stream, base.Name) : new BoundedStream(stream, base.Name, delegate
			{
				long? num = itemLength;
				return (!num.HasValue) ? null : ((FieldLength)num.GetValueOrDefault());
			}));
			ValueNode child = CreateChildSerializer();
			using (StreamResetter streamResetter = new StreamResetter(stream2))
			{
				await child.DeserializeAsync(stream2, eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				if (IsTerminated(child, itemTerminationValue))
				{
					ProcessLastItem(streamResetter, child);
					break;
				}
				streamResetter.CancelReset();
			}
			base.Children.Add(child);
		}
	}

	protected override long CountOverride()
	{
		return base.Children.Count;
	}

	protected override IEnumerable<FieldLength> MeasureItemsOverride()
	{
		NullStream source = new NullStream();
		BoundedStream boundedStream = new BoundedStream(source, base.Name);
		return GetSerializableChildren().Select(delegate(ValueNode child)
		{
			boundedStream.RelativePosition = FieldLength.Zero;
			child.Serialize(boundedStream, null);
			return boundedStream.RelativePosition;
		});
	}

	protected override object GetLastItemValueOverride()
	{
		return ((ValueValueNode)(base.Children.LastOrDefault() ?? throw new InvalidOperationException("Unable to determine last item value because collection is empty.")).GetChild(base.TypeNode.ItemSerializeUntilAttribute.ItemValuePath)).BoundValue;
	}

	private void SetTerminationValue(List<ValueNode> serializableChildren)
	{
		CollectionTypeNode collectionTypeNode = (CollectionTypeNode)base.TypeNode;
		if (collectionTypeNode.ItemSerializeUntilAttribute != null && collectionTypeNode.ItemSerializeUntilAttribute.LastItemMode == LastItemMode.Include)
		{
			ValueNode valueNode = serializableChildren.LastOrDefault();
			if (valueNode != null)
			{
				object boundValue = base.TypeNode.ItemSerializeUntilBinding.GetBoundValue(this);
				ValueNode child = valueNode.GetChild(collectionTypeNode.ItemSerializeUntilAttribute.ItemValuePath);
				object value = boundValue.ConvertTo(child.TypeNode.Type);
				child.Value = value;
			}
		}
	}

	private object GetItemTerminationValue()
	{
		object result = null;
		if (base.TypeNode.ItemSerializeUntilBinding != null)
		{
			result = base.TypeNode.ItemSerializeUntilBinding.GetValue(this);
		}
		return result;
	}

	private void ProcessLastItem(StreamResetter streamResetter, ValueNode child)
	{
		switch (base.TypeNode.ItemSerializeUntilAttribute.LastItemMode)
		{
		case LastItemMode.Include:
			streamResetter.CancelReset();
			base.Children.Add(child);
			break;
		case LastItemMode.Discard:
			streamResetter.CancelReset();
			break;
		case LastItemMode.Defer:
			break;
		}
	}

	private IEnumerable<long> GetItemLengths()
	{
		IEnumerable<long> result = null;
		if (base.TypeNode.ItemLengthBindings != null)
		{
			object value = base.TypeNode.ItemLengthBindings.GetValue(this);
			result = (value as IEnumerable)?.Cast<object>().Select(Convert.ToInt64) ?? GetInfiniteSequence(Convert.ToInt64(value));
		}
		return result;
	}

	private bool IsTerminated(ValueNode child, object itemTerminationValue)
	{
		if (base.TypeNode.ItemSerializeUntilBinding == null)
		{
			return false;
		}
		ValueNode child2 = child.GetChild(base.TypeNode.ItemSerializeUntilAttribute.ItemValuePath);
		object obj = itemTerminationValue.ConvertTo(child2.TypeNode.Type);
		if (child2.Value != null)
		{
			return child2.Value.Equals(obj);
		}
		return true;
	}

	private static IEnumerable<long> GetInfiniteSequence(long value)
	{
		while (true)
		{
			yield return value;
		}
	}
}
