using System;
using System.Collections;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class PrimitveArrayValueNode : PrimitiveCollectionValueNode
{
	public PrimitveArrayValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	protected override void PrimitiveCollectionSerializeOverride(BoundedStream stream, object boundValue, ValueValueNode childSerializer, SerializedType childSerializedType, FieldLength itemLength, long? itemCount)
	{
		Array array = (Array)BoundValue;
		PadArray(ref array, itemCount);
		for (int i = 0; i < array.Length; i++)
		{
			if (stream.IsAtLimit)
			{
				break;
			}
			object value = array.GetValue(i);
			childSerializer.Serialize(stream, value, childSerializedType, itemLength);
		}
	}

	protected override async Task PrimitiveCollectionSerializeOverrideAsync(BoundedStream stream, object boundValue, ValueValueNode childSerializer, SerializedType childSerializedType, FieldLength itemLength, long? itemCount, CancellationToken cancellationToken)
	{
		Array array = (Array)BoundValue;
		PadArray(ref array, itemCount);
		for (int i = 0; i < array.Length; i++)
		{
			if (stream.IsAtLimit)
			{
				break;
			}
			object value = array.GetValue(i);
			await childSerializer.SerializeAsync(stream, value, childSerializedType, itemLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	protected override object CreateCollection(long size)
	{
		return Array.CreateInstance(((ArrayTypeNode)base.TypeNode).ChildType, (int)size);
	}

	protected override object CreateCollection(IEnumerable enumerable)
	{
		ArrayTypeNode typeNode = (ArrayTypeNode)base.TypeNode;
		return (from object item in enumerable
			select item.ConvertTo(typeNode.ChildType)).ToArray();
	}

	protected override void SetCollectionValue(object item, long index)
	{
		Array obj = (Array)BoundValue;
		ArrayTypeNode arrayTypeNode = (ArrayTypeNode)base.TypeNode;
		obj.SetValue(item.ConvertTo(arrayTypeNode.ChildType), (int)index);
	}

	protected override long CountOverride()
	{
		Array array = (Array)BoundValue;
		if (array == null)
		{
			return 0L;
		}
		return array.Length;
	}

	private void PadArray(ref Array array, long? itemCount)
	{
		if (itemCount.HasValue && array.Length != itemCount)
		{
			Array array2 = array;
			array = (Array)CreateCollection(itemCount.Value);
			Array.Copy(array2, array, Math.Min(array2.Length, array.Length));
		}
	}
}
