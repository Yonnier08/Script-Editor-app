using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class ListValueNode : CollectionValueNode
{
	private object _cachedValue;

	public override object Value
	{
		get
		{
			if (_cachedValue != null)
			{
				return _cachedValue;
			}
			IList list = (IList)((ListTypeNode)base.TypeNode).CompiledConstructor();
			foreach (ValueNode child in base.Children)
			{
				list.Add(child.Value);
			}
			return list;
		}
		set
		{
			if (value == null)
			{
				return;
			}
			IList list = (IList)value;
			ListTypeNode typeNode = (ListTypeNode)base.TypeNode;
			long? constFieldCount = GetConstFieldCount();
			if (constFieldCount.HasValue)
			{
				while (list.Count < constFieldCount)
				{
					object value2 = (((object)typeNode.ChildType == typeof(string)) ? string.Empty : typeNode.CompiledChildConstructor());
					list.Add(value2);
				}
			}
			IEnumerable<ValueNode> collection = list.Cast<object>().Select(delegate(object childValue)
			{
				ValueNode valueNode = typeNode.Child.CreateSerializer(this);
				valueNode.Value = childValue;
				return valueNode;
			});
			base.Children.AddRange(collection);
			_cachedValue = value;
		}
	}

	public override object BoundValue
	{
		get
		{
			IList list = (IList)((ListTypeNode)base.TypeNode).CompiledConstructor();
			foreach (ValueNode child in base.Children)
			{
				list.Add(child.BoundValue);
			}
			return list;
		}
	}

	public ListValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}
}
