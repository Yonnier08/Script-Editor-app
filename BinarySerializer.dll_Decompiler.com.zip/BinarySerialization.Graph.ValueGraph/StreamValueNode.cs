using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class StreamValueNode : ValueNode
{
	private const int CopyToBufferSize = 81920;

	public override object Value { get; set; }

	public StreamValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		Stream stream2 = (Stream)Value;
		FieldLength constFieldLength = GetConstFieldLength();
		if (constFieldLength != null)
		{
			new Streamlet(stream2, stream2.Position, constFieldLength.ByteCount).CopyTo(stream);
		}
		else
		{
			stream2.CopyTo(stream);
		}
	}

	internal override async Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		Stream valueStream = (Stream)Value;
		FieldLength constFieldLength = GetConstFieldLength();
		if (constFieldLength != null)
		{
			await new Streamlet(valueStream, valueStream.Position, constFieldLength.ByteCount).CopyToAsync(stream, 81920, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		else
		{
			await valueStream.CopyToAsync(stream, 81920, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		Stream rootStream = GetRootStream(stream);
		FieldLength fieldLength = GetFieldLength();
		Value = ((fieldLength != null) ? new Streamlet(rootStream, rootStream.Position, fieldLength.ByteCount) : new Streamlet(rootStream, rootStream.Position));
		if (fieldLength != null)
		{
			NullStream output = new NullStream();
			stream.CopyTo(output, (int)fieldLength.ByteCount, 81920);
		}
		else
		{
			stream.Seek(0L, SeekOrigin.End);
		}
	}

	internal override async Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		Stream rootStream = GetRootStream(stream);
		FieldLength fieldLength = GetFieldLength();
		Value = ((fieldLength != null) ? new Streamlet(rootStream, rootStream.Position, fieldLength.ByteCount) : new Streamlet(rootStream, rootStream.Position));
		if (fieldLength != null)
		{
			NullStream output = new NullStream();
			await stream.CopyToAsync(output, (int)fieldLength.ByteCount, 81920, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		else
		{
			stream.Seek(0L, SeekOrigin.End);
		}
	}

	protected override FieldLength MeasureOverride()
	{
		Stream stream = (Stream)Value;
		FieldLength constFieldLength = GetConstFieldLength();
		if (constFieldLength != null)
		{
			return constFieldLength;
		}
		if (stream.CanSeek)
		{
			return stream.Length;
		}
		throw new InvalidOperationException("Cannot bind non-seekable stream.");
	}

	private static Stream GetRootStream(BoundedStream stream)
	{
		Stream stream2 = stream;
		while (stream2 is BoundedStream)
		{
			stream2 = (stream2 as BoundedStream).Source;
		}
		return stream2;
	}
}
