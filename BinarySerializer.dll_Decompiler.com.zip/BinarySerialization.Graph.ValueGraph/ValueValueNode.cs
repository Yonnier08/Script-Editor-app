using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class ValueValueNode : ValueNode
{
	private object _cachedValue;

	private object _value;

	private const string LengthPrefixedStringsCannotHaveConstLengthMessage = "Length-prefixed strings cannot have a const length.";

	public override object Value
	{
		get
		{
			return GetValue(base.TypeNode.GetSerializedType());
		}
		set
		{
			_cachedValue = value;
		}
	}

	public override object BoundValue
	{
		get
		{
			object value;
			if (base.Bindings.Count == 0)
			{
				value = Value;
			}
			else
			{
				value = base.Bindings[0]();
				if (value == ValueNode.UnsetValue)
				{
					value = Value;
				}
				if (base.Bindings.Count != 1 && base.Bindings.Select(delegate(Func<object> binding)
				{
					object obj = binding();
					return (obj != ValueNode.UnsetValue) ? obj : Value;
				}).ToArray().Any((object v) => !object.Equals(value, v)))
				{
					throw new BindingException("Multiple bindings to a single source must have equivalent target values.");
				}
				if (value is IEnumerable enumerable)
				{
					if ((object)base.TypeNode.Type == typeof(byte[]) || (object)base.TypeNode.Type == typeof(string))
					{
						byte[] array = enumerable.Cast<object>().Select(Convert.ToByte).ToArray();
						if ((object)base.TypeNode.Type == typeof(byte[]))
						{
							value = array;
						}
						else if ((object)base.TypeNode.Type == typeof(string))
						{
							value = GetFieldEncoding().GetString(array, 0, array.Length);
						}
					}
					else
					{
						value = GetScalar(enumerable);
					}
				}
			}
			return ConvertToFieldType(value);
		}
	}

	public ValueValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}

	public object GetValue(SerializedType serializedType)
	{
		if (_cachedValue != null)
		{
			return _cachedValue;
		}
		object value = GetValue(_value, serializedType);
		return UnscaleValue(value);
	}

	public void Serialize(BoundedStream stream, object value, SerializedType serializedType, FieldLength length = null)
	{
		AsyncBinaryWriter writer = new AsyncBinaryWriter(stream, GetFieldEncoding());
		Serialize(writer, value, serializedType, length);
	}

	public void Serialize(AsyncBinaryWriter writer, object value, SerializedType serializedType, FieldLength length = null)
	{
		FieldLength constLength = GetConstLength(length);
		if (value == null)
		{
			if (serializedType != SerializedType.SizedString)
			{
				if (!(constLength == null) && (serializedType == SerializedType.ByteArray || serializedType == SerializedType.TerminatedString))
				{
					byte[] array = new byte[constLength.TotalByteCount];
					if (serializedType == SerializedType.TerminatedString && array.Length != 0)
					{
						array[0] = base.TypeNode.StringTerminator;
					}
					writer.Write(array, constLength);
				}
				return;
			}
			value = string.Empty;
		}
		FieldLength maxLength = GetMaxLength(writer.OutputStream, serializedType);
		object value2 = ScaleValue(value);
		object value3 = GetValue(value2, serializedType);
		switch (serializedType)
		{
		case SerializedType.Int1:
			writer.Write(Convert.ToSByte(value3), constLength);
			break;
		case SerializedType.UInt1:
			writer.Write(Convert.ToByte(value3), constLength);
			break;
		case SerializedType.Int2:
			writer.Write(Convert.ToInt16(value3), constLength);
			break;
		case SerializedType.UInt2:
			writer.Write(Convert.ToUInt16(value3), constLength);
			break;
		case SerializedType.Int4:
			writer.Write(Convert.ToInt32(value3), constLength);
			break;
		case SerializedType.UInt4:
			writer.Write(Convert.ToUInt32(value3), constLength);
			break;
		case SerializedType.Int8:
			writer.Write(Convert.ToInt64(value3), constLength);
			break;
		case SerializedType.UInt8:
			writer.Write(Convert.ToUInt64(value3), constLength);
			break;
		case SerializedType.Float4:
			writer.Write(Convert.ToSingle(value3), constLength);
			break;
		case SerializedType.Float8:
			writer.Write(Convert.ToDouble(value3), constLength);
			break;
		case SerializedType.ByteArray:
		{
			byte[] data = (byte[])value;
			FieldLength arrayLength2 = GetArrayLength(data, constLength, maxLength);
			writer.Write(data, arrayLength2);
			break;
		}
		case SerializedType.TerminatedString:
		{
			byte[] bytes2 = GetFieldEncoding().GetBytes(value.ToString());
			FieldLength nullTerminatedArrayLength = GetNullTerminatedArrayLength(bytes2, constLength, maxLength);
			writer.Write(bytes2, nullTerminatedArrayLength);
			byte[] array2 = new byte[1] { base.TypeNode.StringTerminator };
			writer.Write(array2, array2.Length);
			break;
		}
		case SerializedType.SizedString:
		{
			byte[] bytes = GetFieldEncoding().GetBytes(value.ToString());
			FieldLength arrayLength = GetArrayLength(bytes, constLength, maxLength);
			writer.Write(bytes, arrayLength);
			break;
		}
		case SerializedType.LengthPrefixedString:
			if (constLength != null)
			{
				throw new NotSupportedException("Length-prefixed strings cannot have a const length.");
			}
			writer.Write(value.ToString());
			break;
		default:
			throw new NotSupportedException();
		}
	}

	public Task SerializeAsync(BoundedStream stream, object value, SerializedType serializedType, FieldLength length = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		AsyncBinaryWriter writer = new AsyncBinaryWriter(stream, GetFieldEncoding());
		return SerializeAsync(writer, value, serializedType, length, cancellationToken);
	}

	public async Task SerializeAsync(AsyncBinaryWriter writer, object value, SerializedType serializedType, FieldLength length = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		FieldLength constLength = GetConstLength(length);
		if (value == null)
		{
			if (serializedType != SerializedType.SizedString)
			{
				if (!(constLength == null) && (serializedType == SerializedType.ByteArray || serializedType == SerializedType.TerminatedString))
				{
					byte[] array = new byte[constLength.TotalByteCount];
					if (serializedType == SerializedType.TerminatedString && array.Length != 0)
					{
						array[0] = base.TypeNode.StringTerminator;
					}
					await writer.WriteAsync(array, constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				}
				return;
			}
			value = string.Empty;
		}
		BoundedStream outputStream = writer.OutputStream;
		FieldLength maxLength = GetMaxLength(outputStream, serializedType);
		object value2 = ScaleValue(value);
		object convertedValue = GetValue(value2, serializedType);
		switch (serializedType)
		{
		case SerializedType.Int1:
			await writer.WriteAsync(Convert.ToSByte(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt1:
			await writer.WriteAsync(Convert.ToByte(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Int2:
			await writer.WriteAsync(Convert.ToInt16(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt2:
			await writer.WriteAsync(Convert.ToUInt16(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Int4:
			await writer.WriteAsync(Convert.ToInt32(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt4:
			await writer.WriteAsync(Convert.ToUInt32(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Int8:
			await writer.WriteAsync(Convert.ToInt64(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt8:
			await writer.WriteAsync(Convert.ToUInt64(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Float4:
			await writer.WriteAsync(Convert.ToSingle(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Float8:
			await writer.WriteAsync(Convert.ToDouble(convertedValue), constLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.ByteArray:
		{
			byte[] data = (byte[])value;
			FieldLength arrayLength2 = GetArrayLength(data, constLength, maxLength);
			await writer.WriteAsync(data, arrayLength2, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		}
		case SerializedType.TerminatedString:
		{
			byte[] bytes2 = GetFieldEncoding().GetBytes(value.ToString());
			FieldLength nullTerminatedArrayLength = GetNullTerminatedArrayLength(bytes2, constLength, maxLength);
			await writer.WriteAsync(bytes2, nullTerminatedArrayLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			byte[] array2 = new byte[1] { base.TypeNode.StringTerminator };
			await writer.WriteAsync(array2, array2.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		}
		case SerializedType.SizedString:
		{
			byte[] bytes = GetFieldEncoding().GetBytes(value.ToString());
			FieldLength arrayLength = GetArrayLength(bytes, constLength, maxLength);
			await writer.WriteAsync(bytes, arrayLength, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		}
		case SerializedType.LengthPrefixedString:
			if (constLength != null)
			{
				throw new NotSupportedException("Length-prefixed strings cannot have a const length.");
			}
			writer.Write(value.ToString());
			break;
		default:
			throw new NotSupportedException();
		}
	}

	public void Deserialize(BoundedStream stream, SerializedType serializedType, FieldLength length = null)
	{
		AsyncBinaryReader reader = new AsyncBinaryReader(stream, GetFieldEncoding());
		Deserialize(reader, serializedType, length);
	}

	public Task DeserializeAsync(BoundedStream stream, SerializedType serializedType, FieldLength length, CancellationToken cancellationToken)
	{
		AsyncBinaryReader reader = new AsyncBinaryReader(stream, GetFieldEncoding());
		return DeserializeAsync(reader, serializedType, length, cancellationToken);
	}

	public void Deserialize(BinaryReader reader, SerializedType serializedType, FieldLength length = null)
	{
		FieldLength effectiveLengthValue = GetEffectiveLengthValue(reader, serializedType, length);
		object value;
		switch (serializedType)
		{
		case SerializedType.Int1:
			value = reader.ReadSByte();
			break;
		case SerializedType.UInt1:
			value = reader.ReadByte();
			break;
		case SerializedType.Int2:
			value = reader.ReadInt16();
			break;
		case SerializedType.UInt2:
			value = reader.ReadUInt16();
			break;
		case SerializedType.Int4:
			value = reader.ReadInt32();
			break;
		case SerializedType.UInt4:
			value = reader.ReadUInt32();
			break;
		case SerializedType.Int8:
			value = reader.ReadInt64();
			break;
		case SerializedType.UInt8:
			value = reader.ReadUInt64();
			break;
		case SerializedType.Float4:
			value = reader.ReadSingle();
			break;
		case SerializedType.Float8:
			value = reader.ReadDouble();
			break;
		case SerializedType.ByteArray:
			value = reader.ReadBytes((int)effectiveLengthValue.ByteCount);
			break;
		case SerializedType.TerminatedString:
		{
			byte[] array = ReadTerminated(reader, effectiveLengthValue, base.TypeNode.StringTerminator);
			value = GetFieldEncoding().GetString(array, 0, array.Length);
			break;
		}
		case SerializedType.SizedString:
		{
			byte[] data = reader.ReadBytes((int)effectiveLengthValue.ByteCount);
			value = GetString(data);
			break;
		}
		case SerializedType.LengthPrefixedString:
			value = reader.ReadString();
			break;
		default:
			throw new NotSupportedException();
		}
		_value = ConvertToFieldType(value);
		CheckComputedValues();
	}

	public async Task DeserializeAsync(AsyncBinaryReader reader, SerializedType serializedType, FieldLength length, CancellationToken cancellationToken)
	{
		FieldLength effectiveLengthValue = GetEffectiveLengthValue(reader, serializedType, length);
		object value;
		switch (serializedType)
		{
		case SerializedType.Int1:
			value = await reader.ReadSByteAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt1:
			value = await reader.ReadByteAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Int2:
			value = await reader.ReadInt16Async(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt2:
			value = await reader.ReadUInt16Async(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Int4:
			value = await reader.ReadInt32Async(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt4:
			value = await reader.ReadUInt32Async(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Int8:
			value = await reader.ReadInt64Async(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.UInt8:
			value = await reader.ReadUInt64Async(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Float4:
			value = await reader.ReadSingleAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.Float8:
			value = await reader.ReadDoubleAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.ByteArray:
			value = await reader.ReadBytesAsync((int)effectiveLengthValue.ByteCount, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			break;
		case SerializedType.TerminatedString:
		{
			byte[] array = await ReadTerminatedAsync(reader, (int)effectiveLengthValue.ByteCount, base.TypeNode.StringTerminator, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			value = GetFieldEncoding().GetString(array, 0, array.Length);
			break;
		}
		case SerializedType.SizedString:
			value = GetString(await reader.ReadBytesAsync((int)effectiveLengthValue.ByteCount, cancellationToken).ConfigureAwait(continueOnCapturedContext: false));
			break;
		case SerializedType.LengthPrefixedString:
			value = reader.ReadString();
			break;
		default:
			throw new NotSupportedException();
		}
		_value = ConvertToFieldType(value);
		CheckComputedValues();
	}

	public override string ToString()
	{
		if (base.Name != null)
		{
			return $"{base.Name}: {Value}";
		}
		return Value?.ToString() ?? base.ToString();
	}

	internal override void SerializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		Serialize(stream, BoundValue, base.TypeNode.GetSerializedType());
	}

	internal override Task SerializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		return SerializeAsync(stream, BoundValue, base.TypeNode.GetSerializedType(), null, cancellationToken);
	}

	internal override void DeserializeOverride(BoundedStream stream, EventShuttle eventShuttle)
	{
		if (ValueNode.EndOfStream(stream))
		{
			if (!base.TypeNode.IsNullable)
			{
				throw new EndOfStreamException();
			}
		}
		else
		{
			Deserialize(stream, base.TypeNode.GetSerializedType());
		}
	}

	internal override Task DeserializeOverrideAsync(BoundedStream stream, EventShuttle eventShuttle, CancellationToken cancellationToken)
	{
		if (ValueNode.EndOfStream(stream))
		{
			if (base.TypeNode.IsNullable)
			{
				return Task.CompletedTask;
			}
			throw new EndOfStreamException();
		}
		return DeserializeAsync(stream, base.TypeNode.GetSerializedType(), null, cancellationToken);
	}

	protected override long CountOverride()
	{
		return ((long?)(BoundValue as byte[])?.Length) ?? base.CountOverride();
	}

	protected override FieldLength MeasureOverride()
	{
		int? num = (BoundValue as byte[])?.Length;
		if (!num.HasValue)
		{
			return base.MeasureOverride();
		}
		return num.GetValueOrDefault();
	}

	private object ScaleValue(object value)
	{
		if (base.TypeNode.FieldScaleBindings == null)
		{
			return value;
		}
		object value2 = base.TypeNode.FieldScaleBindings.GetValue(this);
		return Convert.ToDouble(value) * Convert.ToDouble(value2);
	}

	private object UnscaleValue(object value)
	{
		if (base.TypeNode.FieldScaleBindings == null)
		{
			return value;
		}
		object value2 = base.TypeNode.FieldScaleBindings.GetValue(this);
		return Convert.ToDouble(value) / Convert.ToDouble(value2);
	}

	private FieldLength GetConstLength(FieldLength length)
	{
		FieldLength fieldLength = length;
		if ((object)fieldLength == null)
		{
			fieldLength = GetConstFieldLength();
			if ((object)fieldLength == null)
			{
				long? constFieldCount = GetConstFieldCount();
				if (!constFieldCount.HasValue)
				{
					return null;
				}
				fieldLength = constFieldCount.GetValueOrDefault();
			}
		}
		return fieldLength;
	}

	private static FieldLength GetMaxLength(BoundedStream stream, SerializedType serializedType)
	{
		FieldLength result = null;
		if (serializedType == SerializedType.ByteArray || serializedType == SerializedType.SizedString || serializedType == SerializedType.TerminatedString)
		{
			result = stream.AvailableForWriting;
		}
		return result;
	}

	private static FieldLength GetArrayLength(byte[] data, FieldLength constLength, FieldLength maxLength)
	{
		FieldLength fieldLength = data.Length;
		if (constLength != null)
		{
			fieldLength = constLength;
		}
		if (maxLength != null && fieldLength > maxLength)
		{
			fieldLength = maxLength;
		}
		return fieldLength;
	}

	private static FieldLength GetNullTerminatedArrayLength(byte[] data, FieldLength constLength, FieldLength maxLength)
	{
		FieldLength fieldLength = data.Length;
		if (constLength != null)
		{
			fieldLength = constLength - new FieldLength(1);
		}
		if (maxLength != null && fieldLength > maxLength)
		{
			fieldLength = maxLength - new FieldLength(1);
		}
		return fieldLength;
	}

	private object GetScalar(IEnumerable enumerable)
	{
		List<object> list = enumerable.Cast<object>().Select(ConvertToFieldType).ToList();
		if (list.Count == 0)
		{
			return 0;
		}
		List<IGrouping<object, object>> list2 = (from childLength in list
			group childLength by childLength).ToList();
		if (list2.Count > 1)
		{
			throw new InvalidOperationException("Unable to update scalar binding source because not all enumerable items have equal lengths.");
		}
		return list2.Single().Key;
	}

	private object GetString(byte[] data)
	{
		string @string = GetFieldEncoding().GetString(data, 0, data.Length);
		if (base.TypeNode.AreStringsTerminated)
		{
			int num = @string.IndexOf((char)base.TypeNode.StringTerminator);
			return (num != -1) ? @string.Substring(0, num) : @string;
		}
		return @string;
	}

	private FieldLength GetEffectiveLengthValue(BinaryReader reader, SerializedType serializedType, FieldLength length)
	{
		object obj = length;
		if (obj == null)
		{
			obj = GetFieldLength();
			if (obj == null)
			{
				long? fieldCount = GetFieldCount();
				obj = (fieldCount.HasValue ? ((FieldLength)fieldCount.GetValueOrDefault()) : null);
			}
		}
		FieldLength fieldLength = (FieldLength)obj;
		if (fieldLength == null && (serializedType == SerializedType.ByteArray || serializedType == SerializedType.SizedString || serializedType == SerializedType.TerminatedString))
		{
			fieldLength = ((BoundedStream)reader.BaseStream).AvailableForReading;
		}
		return fieldLength ?? FieldLength.Zero;
	}

	private object GetValue(object value, SerializedType serializedType)
	{
		if (value == null)
		{
			return null;
		}
		if (serializedType == SerializedType.Int2 || serializedType == SerializedType.UInt2 || serializedType == SerializedType.Int4 || serializedType == SerializedType.UInt4 || serializedType == SerializedType.Int8 || serializedType == SerializedType.UInt8 || serializedType == SerializedType.Float4 || serializedType == SerializedType.Float8)
		{
			if (GetFieldEndianness() != Endianness.Big)
			{
				return value;
			}
			switch (serializedType)
			{
			case SerializedType.Int2:
				return Bytes.Reverse(Convert.ToInt16(value));
			case SerializedType.UInt2:
			{
				ushort num = Bytes.Reverse(Convert.ToUInt16(value));
				return ConvertToFieldType(num);
			}
			case SerializedType.Int4:
				return Bytes.Reverse(Convert.ToInt32(value));
			case SerializedType.UInt4:
				return Bytes.Reverse(Convert.ToUInt32(value));
			case SerializedType.Int8:
				return Bytes.Reverse(Convert.ToInt64(value));
			case SerializedType.UInt8:
				return Bytes.Reverse(Convert.ToUInt64(value));
			case SerializedType.Float4:
				return Bytes.Reverse(Convert.ToSingle(value));
			case SerializedType.Float8:
				return Bytes.Reverse(Convert.ToDouble(value));
			}
		}
		return value;
	}

	private object ConvertToFieldType(object value)
	{
		return value.ConvertTo(base.TypeNode.Type);
	}

	private void CheckComputedValues()
	{
		bool flag = true;
		string arg = null;
		string arg2 = null;
		object value = Value;
		object boundValue = BoundValue;
		if (boundValue != null && base.Bindings.Count > 0)
		{
			if (boundValue is byte[] array && value is byte[] array2)
			{
				if (!array.SequenceEqual(array2))
				{
					arg = BitConverter.ToString(array);
					arg2 = BitConverter.ToString(array2);
					flag = false;
				}
			}
			else if (!boundValue.Equals(value))
			{
				arg = boundValue.ToString();
				arg2 = value.ToString();
				flag = false;
			}
		}
		if (!flag)
		{
			throw new InvalidDataException($"Deserialized value does not match computed value.  Expected {arg} but got {arg2}.  To suppress this check, change binding mode to OneWayToSource.");
		}
	}

	private static byte[] ReadTerminated(BinaryReader reader, FieldLength maxLength, byte terminator)
	{
		MemoryStream memoryStream = new MemoryStream();
		long byteCount = maxLength.ByteCount;
		byte value;
		while (byteCount-- > 0 && (value = reader.ReadByte()) != terminator)
		{
			memoryStream.WriteByte(value);
		}
		return memoryStream.ToArray();
	}

	private static async Task<byte[]> ReadTerminatedAsync(AsyncBinaryReader reader, int maxLength, byte terminator, CancellationToken cancellationToken)
	{
		MemoryStream buffer = new MemoryStream();
		byte value = default(byte);
		while (true)
		{
			bool flag = maxLength-- > 0;
			if (flag)
			{
				byte num = await reader.ReadByteAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				value = num;
				flag = num != terminator;
			}
			if (!flag)
			{
				break;
			}
			buffer.WriteByte(value);
		}
		return buffer.ToArray();
	}
}
