using System;
using System.Collections.Generic;
using System.Linq;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph.ValueGraph;

internal class ArrayValueNode : CollectionValueNode
{
	private object _cachedValue;

	public override object Value
	{
		get
		{
			if (_cachedValue != null)
			{
				return _cachedValue;
			}
			Array array = Array.CreateInstance(((ArrayTypeNode)base.TypeNode).ChildType, base.Children.Count);
			object[] array2 = base.Children.Select((ValueNode child) => child.Value).ToArray();
			Array.Copy(array2, array, array2.Length);
			return array;
		}
		set
		{
			if (base.Children.Count > 0)
			{
				throw new InvalidOperationException("Value already set.");
			}
			if (value != null)
			{
				ArrayTypeNode arrayTypeNode = (ArrayTypeNode)base.TypeNode;
				Array array = (Array)value;
				long? constFieldCount = GetConstFieldCount();
				if (constFieldCount.HasValue)
				{
					Array array2 = Array.CreateInstance(arrayTypeNode.ChildType, (int)constFieldCount.Value);
					Array.Copy(array, array2, array.Length);
					array = array2;
				}
				IEnumerable<ValueNode> collection = array.Cast<object>().Select(delegate(object childValue)
				{
					ValueNode valueNode = CreateChildSerializer();
					valueNode.Value = childValue;
					return valueNode;
				});
				base.Children.AddRange(collection);
				_cachedValue = value;
			}
		}
	}

	public ArrayValueNode(ValueNode parent, string name, TypeNode typeNode)
		: base(parent, name, typeNode)
	{
	}
}
