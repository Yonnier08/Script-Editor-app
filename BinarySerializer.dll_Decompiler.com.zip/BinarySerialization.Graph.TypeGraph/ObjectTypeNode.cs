using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization.Graph.TypeGraph;

internal class ObjectTypeNode : ContainerTypeNode
{
	private const BindingFlags MemberBindingFlags = BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public;

	private readonly object _initializationLock = new object();

	private readonly Lazy<IDictionary<Type, ObjectTypeNode>> _subTypesLazy = new Lazy<IDictionary<Type, ObjectTypeNode>>(() => new Dictionary<Type, ObjectTypeNode>());

	private bool _isConstructed;

	public ConstructorInfo Constructor { get; private set; }

	public Func<object> CompiledConstructor { get; private set; }

	public string[] ConstructorParameterNames { get; private set; }

	public IDictionary<Type, object> SubTypeKeys { get; private set; }

	public List<TypeNode> UnorderedChildren { get; private set; }

	public ObjectTypeNode(TypeNode parent, Type type)
		: base(parent, type)
	{
		Construct();
	}

	public ObjectTypeNode(TypeNode parent, Type parentType, MemberInfo memberInfo)
		: this(parent, parentType, memberInfo, null)
	{
	}

	public ObjectTypeNode(TypeNode parent, Type parentType, MemberInfo memberInfo, Type subType)
		: base(parent, parentType, memberInfo, subType)
	{
		Construct((object)subType != null);
	}

	public ObjectTypeNode GetSubTypeNode(Type type)
	{
		if ((object)type == base.Type)
		{
			return this;
		}
		lock (_initializationLock)
		{
			GenerateSubtype(type);
			ObjectTypeNode objectTypeNode = _subTypesLazy.Value[type];
			objectTypeNode.Construct(isSubType: true);
			return objectTypeNode;
		}
	}

	internal override ValueNode CreateSerializerOverride(ValueNode parent)
	{
		return new ObjectValueNode(parent, base.Name, this);
	}

	private void Construct(bool isSubType = false)
	{
		if (_isConstructed)
		{
			return;
		}
		lock (_initializationLock)
		{
			if (!_isConstructed)
			{
				if (!isSubType)
				{
					ConstructSubtypes();
				}
				base.Children = (base.IsIgnored ? new List<TypeNode>() : GenerateChildren(base.Type).ToList());
				InitializeConstructors();
				_isConstructed = true;
			}
		}
	}

	private void GenerateSubtype(Type type)
	{
		if (!_subTypesLazy.Value.ContainsKey(type))
		{
			TypeNode parent = base.Parent;
			ObjectTypeNode value = (((object)base.MemberInfo == null) ? (System.Reflection.TypeExtensions.IsAssignableFrom(typeof(IBinarySerializable), type) ? new CustomTypeNode(parent, type, null, type) : new ObjectTypeNode(parent, type, null, type)) : (System.Reflection.TypeExtensions.IsAssignableFrom(typeof(IBinarySerializable), type) ? new CustomTypeNode(parent, parent.Type, base.MemberInfo, type) : new ObjectTypeNode(parent, parent.Type, base.MemberInfo, type)));
			_subTypesLazy.Value.Add(type, value);
		}
	}

	private void ConstructSubtypes()
	{
		TypeNode parent = base.Parent;
		if (base.SubtypeAttributes != null && base.SubtypeAttributes.Count > 0)
		{
			ConstructSubtypes(base.SubtypeAttributes);
		}
		else if (parent.ItemSubtypeAttributes != null && parent.ItemSubtypeAttributes.Count > 0)
		{
			ConstructSubtypes(parent.ItemSubtypeAttributes);
		}
	}

	private void ConstructSubtypes(ReadOnlyCollection<SubtypeBaseAttribute> attributes)
	{
		SubTypeKeys = attributes.Where((SubtypeBaseAttribute attribute) => attribute.BindingMode != BindingMode.OneWay).ToDictionary((SubtypeBaseAttribute attribute) => attribute.Subtype, (SubtypeBaseAttribute attribute) => attribute.Value);
		foreach (Type item in from attribute in attributes
			where attribute.BindingMode != BindingMode.OneWay
			select attribute.Subtype)
		{
			GenerateSubtype(item);
		}
	}

	private void InitializeConstructors()
	{
		if (base.Type.GetTypeInfo().IsAbstract)
		{
			return;
		}
		ConstructorInfo[] constructors = System.Reflection.TypeExtensions.GetConstructors(base.Type, BindingFlags.Instance | BindingFlags.Public);
		IEnumerable<TypeNode> serializableChildren = base.Children.Where((TypeNode child) => !child.IsIgnored);
		List<KeyValuePair<ConstructorInfo, IEnumerable<TypeNode>>> source = (from constructorPair in constructors.Where((ConstructorInfo constructor) => constructor.GetParameters().Length <= serializableChildren.Count()).ToDictionary((ConstructorInfo constructor) => constructor, (ConstructorInfo constructor) => (from parameter in constructor.GetParameters()
				join child in serializableChildren on new
				{
					Name = parameter.Name.ToLower(),
					Type = parameter.ParameterType
				} equals new
				{
					Name = child.Name.ToLower(),
					Type = child.Type
				} into children
				select new { parameter, children }).SelectMany(result => result.children.DefaultIfEmpty()))
			where constructorPair.Value.All((TypeNode child) => child != null)
			select constructorPair).ToList();
		if (source.Any())
		{
			KeyValuePair<ConstructorInfo, IEnumerable<TypeNode>> keyValuePair = source.OrderByDescending((KeyValuePair<ConstructorInfo, IEnumerable<TypeNode>> constructorPair) => constructorPair.Value.Count()).First();
			Constructor = keyValuePair.Key;
			ConstructorParameterNames = keyValuePair.Value.Select((TypeNode child) => child.Name).ToArray();
			if (ConstructorParameterNames.Length == 0)
			{
				CompiledConstructor = TypeNode.CreateCompiledConstructor(Constructor);
			}
		}
	}

	private IEnumerable<TypeNode> GenerateChildren(Type parentType)
	{
		PropertyInfo[] properties = System.Reflection.TypeExtensions.GetProperties(parentType, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public);
		IEnumerable<MemberInfo> fields = System.Reflection.TypeExtensions.GetFields(parentType, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public);
		List<TypeNode> list = (from memberInfo in properties.Union(fields)
			select GenerateChild(parentType, memberInfo) into child
			orderby child.Order
			select child).ToList();
		List<TypeNode> list2 = list.Where((TypeNode child) => !child.IsIgnored).ToList();
		if (list2.Count > 1)
		{
			List<TypeNode> list3 = list2.Where((TypeNode child) => child.Order.HasValue).ToList();
			if ((from child in list3
				group child by child.Order).Count() != list3.Count)
			{
				throw new InvalidOperationException("All fields must have a unique order number.");
			}
			UnorderedChildren = list2.Where((TypeNode child) => !child.Order.HasValue).ToList();
		}
		if ((object)parentType.GetTypeInfo().BaseType != null)
		{
			return GenerateChildren(parentType.GetTypeInfo().BaseType).Except(list).Concat(list);
		}
		return list;
	}
}
