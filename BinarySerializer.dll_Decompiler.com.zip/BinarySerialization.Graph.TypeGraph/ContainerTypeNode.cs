using System;
using System.Collections;
using System.IO;
using System.Reflection;

namespace BinarySerialization.Graph.TypeGraph;

internal abstract class ContainerTypeNode : TypeNode
{
	protected const BindingFlags ConstructorBindingFlags = BindingFlags.Instance | BindingFlags.Public;

	protected ContainerTypeNode(TypeNode parent, Type type)
		: base(parent, type)
	{
	}

	protected ContainerTypeNode(TypeNode parent, Type parentType, MemberInfo memberInfo, Type subType = null)
		: base(parent, parentType, memberInfo, subType)
	{
	}

	protected TypeNode GenerateChild(Type type)
	{
		try
		{
			ThrowOnBadType(type);
			return (TypeNode)Activator.CreateInstance(GetNodeType(type), this, type);
		}
		catch (Exception innerException)
		{
			throw new InvalidOperationException($"There was an error reflecting type '{type}'", innerException);
		}
	}

	protected TypeNode GenerateChild(Type parentType, MemberInfo memberInfo)
	{
		Type memberType = GetMemberType(memberInfo);
		try
		{
			ThrowOnBadType(memberType);
			return (TypeNode)Activator.CreateInstance(GetNodeType(memberType), this, parentType, memberInfo);
		}
		catch (Exception innerException)
		{
			throw new InvalidOperationException($"There was an error reflecting member '{memberInfo.Name}'", innerException);
		}
	}

	protected static Type GetMemberType(MemberInfo memberInfo)
	{
		if ((object)memberInfo != null)
		{
			if (memberInfo is PropertyInfo propertyInfo)
			{
				return propertyInfo.PropertyType;
			}
			if (memberInfo is FieldInfo fieldInfo)
			{
				return fieldInfo.FieldType;
			}
		}
		throw new NotSupportedException($"{memberInfo.GetType().Name} not supported");
	}

	private static void ThrowOnBadType(Type type)
	{
		if (System.Reflection.TypeExtensions.IsAssignableFrom(typeof(IDictionary), type))
		{
			throw new InvalidOperationException("Cannot serialize objects that implement IDictionary.");
		}
	}

	private static Type GetNodeType(Type type)
	{
		Type type2 = Nullable.GetUnderlyingType(type) ?? type;
		if (type2.GetTypeInfo().IsEnum)
		{
			return typeof(EnumTypeNode);
		}
		if (TypeNode.IsValueType(type2))
		{
			return typeof(ValueTypeNode);
		}
		if (type.IsArray)
		{
			return typeof(ArrayTypeNode);
		}
		if (System.Reflection.TypeExtensions.IsAssignableFrom(typeof(IList), type))
		{
			return typeof(ListTypeNode);
		}
		if (System.Reflection.TypeExtensions.IsAssignableFrom(typeof(Stream), type))
		{
			return typeof(StreamTypeNode);
		}
		if (System.Reflection.TypeExtensions.IsAssignableFrom(typeof(IBinarySerializable), type))
		{
			return typeof(CustomTypeNode);
		}
		if ((object)type == typeof(object))
		{
			return typeof(UnknownTypeNode);
		}
		return typeof(ObjectTypeNode);
	}
}
