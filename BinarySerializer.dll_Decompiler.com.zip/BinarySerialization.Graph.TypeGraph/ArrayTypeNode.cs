using System;
using System.Reflection;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization.Graph.TypeGraph;

internal sealed class ArrayTypeNode : CollectionTypeNode
{
	public ArrayTypeNode(TypeNode parent, Type type)
		: base(parent, type)
	{
	}

	public ArrayTypeNode(TypeNode parent, Type parentType, MemberInfo memberInfo)
		: base(parent, parentType, memberInfo)
	{
	}

	internal override ValueNode CreateSerializerOverride(ValueNode parent)
	{
		if (base.ChildType.GetTypeInfo().IsPrimitive)
		{
			return new PrimitveArrayValueNode(parent, base.Name, this);
		}
		return new ArrayValueNode(parent, base.Name, this);
	}

	protected override Type GetChildType()
	{
		return base.Type.GetElementType();
	}
}
