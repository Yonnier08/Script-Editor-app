using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization.Graph.TypeGraph;

internal class EnumTypeNode : ValueTypeNode
{
	public EnumInfo EnumInfo { get; private set; }

	public EnumTypeNode(TypeNode parent, Type type)
		: base(parent, type)
	{
		InitializeEnumValues();
	}

	public EnumTypeNode(TypeNode parent, Type parentType, MemberInfo memberInfo)
		: base(parent, parentType, memberInfo)
	{
		InitializeEnumValues();
	}

	internal override ValueNode CreateSerializerOverride(ValueNode parent)
	{
		return new EnumValueNode(parent, base.Name, this);
	}

	private void InitializeEnumValues()
	{
		SerializedType serializedType = GetSerializedType();
		Dictionary<Enum, SerializeAsEnumAttribute> source = Enum.GetValues(base.BaseSerializedType).Cast<Enum>().ToDictionary((Enum value) => value, (Enum value) => (SerializeAsEnumAttribute)CustomAttributeExtensions.GetCustomAttributes(System.Reflection.TypeExtensions.GetMember(base.BaseSerializedType, value.ToString()).Single(), typeof(SerializeAsEnumAttribute), inherit: false).FirstOrDefault());
		EnumInfo = new EnumInfo();
		if (source.Any((KeyValuePair<Enum, SerializeAsEnumAttribute> enumAttribute) => enumAttribute.Value != null) || serializedType == SerializedType.TerminatedString || serializedType == SerializedType.SizedString || serializedType == SerializedType.LengthPrefixedString)
		{
			EnumInfo.EnumValues = source.ToDictionary((KeyValuePair<Enum, SerializeAsEnumAttribute> enumAttribute) => enumAttribute.Key, (KeyValuePair<Enum, SerializeAsEnumAttribute> enumAttribute) => enumAttribute.Value?.Value ?? enumAttribute.Key.ToString());
			EnumInfo.ValueEnums = EnumInfo.EnumValues.ToDictionary((KeyValuePair<Enum, string> enumValue) => enumValue.Value, (KeyValuePair<Enum, string> enumValue) => enumValue.Key);
			List<IGrouping<int, string>> list = (from enumValue in EnumInfo.EnumValues
				where enumValue.Value != null
				select enumValue.Value into value
				group value by value.Length).ToList();
			switch (serializedType)
			{
			case SerializedType.Default:
				if (list.Count == 1)
				{
					EnumInfo.SerializedType = SerializedType.SizedString;
					EnumInfo.EnumValueLength = list[0].Key;
				}
				else
				{
					EnumInfo.SerializedType = SerializedType.TerminatedString;
				}
				break;
			case SerializedType.SizedString:
				EnumInfo.EnumValueLength = list[0].Max((string lengthGroup) => lengthGroup.Length);
				break;
			}
		}
		EnumInfo.UnderlyingType = Enum.GetUnderlyingType(base.BaseSerializedType);
		if (EnumInfo.SerializedType == SerializedType.Default)
		{
			EnumInfo.SerializedType = GetSerializedType(EnumInfo.UnderlyingType);
		}
	}
}
