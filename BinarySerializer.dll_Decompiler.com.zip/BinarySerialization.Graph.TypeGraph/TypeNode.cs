using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization.Graph.TypeGraph;

internal abstract class TypeNode : Node<TypeNode>
{
	public static readonly Dictionary<Type, SerializedType> DefaultSerializedTypes = new Dictionary<Type, SerializedType>
	{
		{
			typeof(bool),
			SerializedType.Int1
		},
		{
			typeof(sbyte),
			SerializedType.Int1
		},
		{
			typeof(byte),
			SerializedType.UInt1
		},
		{
			typeof(char),
			SerializedType.UInt2
		},
		{
			typeof(short),
			SerializedType.Int2
		},
		{
			typeof(ushort),
			SerializedType.UInt2
		},
		{
			typeof(int),
			SerializedType.Int4
		},
		{
			typeof(uint),
			SerializedType.UInt4
		},
		{
			typeof(long),
			SerializedType.Int8
		},
		{
			typeof(ulong),
			SerializedType.UInt8
		},
		{
			typeof(float),
			SerializedType.Float4
		},
		{
			typeof(double),
			SerializedType.Float8
		},
		{
			typeof(string),
			SerializedType.TerminatedString
		},
		{
			typeof(byte[]),
			SerializedType.ByteArray
		}
	};

	public static readonly Dictionary<SerializedType, object> SerializedTypeDefault = new Dictionary<SerializedType, object>
	{
		{
			SerializedType.Default,
			null
		},
		{
			SerializedType.Int1,
			(sbyte)0
		},
		{
			SerializedType.UInt1,
			(byte)0
		},
		{
			SerializedType.Int2,
			(short)0
		},
		{
			SerializedType.UInt2,
			(ushort)0
		},
		{
			SerializedType.Int4,
			0
		},
		{
			SerializedType.UInt4,
			0u
		},
		{
			SerializedType.Int8,
			0L
		},
		{
			SerializedType.UInt8,
			0uL
		},
		{
			SerializedType.Float4,
			0f
		},
		{
			SerializedType.Float8,
			0.0
		},
		{
			SerializedType.TerminatedString,
			null
		},
		{
			SerializedType.SizedString,
			null
		},
		{
			SerializedType.LengthPrefixedString,
			null
		},
		{
			SerializedType.ByteArray,
			null
		}
	};

	private readonly SerializedType? _serializedType;

	public MemberInfo MemberInfo { get; }

	public Type Type { get; }

	public Type NullableUnderlyingType { get; }

	public Type BaseSerializedType => NullableUnderlyingType ?? Type;

	public Action<object, object> ValueSetter { get; }

	public Func<object, object> ValueGetter { get; }

	public BindingCollection FieldLengthBindings { get; }

	public FieldBitLengthAttribute FieldBitLengthAttribute { get; }

	public BindingCollection ItemLengthBindings { get; }

	public BindingCollection FieldCountBindings { get; }

	public BindingCollection FieldOffsetBindings { get; }

	public BindingCollection FieldScaleBindings { get; }

	public BindingCollection LeftFieldAlignmentBindings { get; }

	public BindingCollection RightFieldAlignmentBindings { get; }

	public BindingCollection FieldEndiannessBindings { get; }

	public BindingCollection FieldEncodingBindings { get; }

	public BindingCollection FieldValueBindings { get; }

	public Binding SerializeUntilBinding { get; }

	public Binding ItemSerializeUntilBinding { get; }

	public BindingCollection SubtypeBindings { get; }

	public BindingCollection ItemSubtypeBindings { get; }

	public Binding SubtypeFactoryBinding { get; }

	public Binding ItemSubtypeFactoryBinding { get; }

	public ReadOnlyCollection<ConditionalBinding> SerializeWhenBindings { get; }

	public ReadOnlyCollection<ConditionalBinding> SerializeWhenNotBindings { get; }

	public ReadOnlyCollection<FieldValueAttributeBase> FieldValueAttributes { get; }

	public ReadOnlyCollection<SubtypeBaseAttribute> SubtypeAttributes { get; }

	public SubtypeDefaultAttribute SubtypeDefaultAttribute { get; }

	public ISubtypeFactory SubtypeFactory { get; }

	public ISubtypeFactory ItemSubtypeFactory { get; }

	public ReadOnlyCollection<SubtypeBaseAttribute> ItemSubtypeAttributes { get; }

	public ItemSubtypeDefaultAttribute ItemSubtypeDefaultAttribute { get; }

	public ReadOnlyCollection<SerializeWhenAttribute> SerializeWhenAttributes { get; }

	public ReadOnlyCollection<SerializeWhenNotAttribute> SerializeWhenNotAttributes { get; }

	public SerializeUntilAttribute SerializeUntilAttribute { get; }

	public ItemSerializeUntilAttribute ItemSerializeUntilAttribute { get; }

	public bool IsIgnored { get; }

	public int? Order { get; }

	public bool AreStringsTerminated { get; }

	public byte StringTerminator { get; }

	public bool IsNullable { get; }

	protected TypeNode(TypeNode parent)
		: base(parent)
	{
	}

	protected TypeNode(TypeNode parent, Type type)
		: this(parent)
	{
		Type = type;
		NullableUnderlyingType = Nullable.GetUnderlyingType(Type);
	}

	protected TypeNode(TypeNode parent, Type parentType, MemberInfo memberInfo, Type subType = null)
		: this(parent)
	{
		if ((object)memberInfo == null)
		{
			Type = subType;
			return;
		}
		MemberInfo = memberInfo;
		base.Name = memberInfo.Name;
		PropertyInfo propertyInfo = memberInfo as PropertyInfo;
		FieldInfo fieldInfo = memberInfo as FieldInfo;
		if ((object)propertyInfo != null)
		{
			Type = subType ?? propertyInfo.PropertyType;
			if (propertyInfo.GetIndexParameters().Length == 0)
			{
				MethodInfo getMethod = PropertyInfoExtensions.GetGetMethod(propertyInfo);
				ValueGetter = MagicMethods.MagicFunc(parentType, getMethod);
				MethodInfo setMethod = PropertyInfoExtensions.GetSetMethod(propertyInfo);
				if ((object)setMethod != null)
				{
					ValueSetter = MagicMethods.MagicAction(parentType, setMethod);
				}
			}
		}
		else
		{
			if ((object)fieldInfo == null)
			{
				throw new NotSupportedException($"{memberInfo.GetType().Name} not supported");
			}
			Type = subType ?? fieldInfo.FieldType;
			ValueGetter = fieldInfo.GetValue;
			ValueSetter = fieldInfo.SetValue;
		}
		NullableUnderlyingType = Nullable.GetUnderlyingType(Type);
		List<Attribute> list = CustomAttributeExtensions.GetCustomAttributes(memberInfo, inherit: true).ToList();
		IsIgnored = list.OfType<IgnoreAttribute>().Any();
		if (IsIgnored)
		{
			return;
		}
		FieldOrderAttribute fieldOrderAttribute = list.OfType<FieldOrderAttribute>().SingleOrDefault();
		if (fieldOrderAttribute != null)
		{
			Order = fieldOrderAttribute.Order;
		}
		SerializeAsAttribute serializeAsAttribute = list.OfType<SerializeAsAttribute>().SingleOrDefault();
		if (serializeAsAttribute != null)
		{
			_serializedType = serializeAsAttribute.SerializedType;
			if (_serializedType == SerializedType.NullTerminatedString)
			{
				_serializedType = SerializedType.TerminatedString;
			}
			if (_serializedType.Value == SerializedType.TerminatedString)
			{
				AreStringsTerminated = true;
				StringTerminator = serializeAsAttribute.StringTerminator;
			}
		}
		IsNullable = (object)NullableUnderlyingType != null;
		if (!IsNullable)
		{
			SerializedType serializedType = GetSerializedType();
			IsNullable = serializedType == SerializedType.Default || serializedType == SerializedType.ByteArray || serializedType == SerializedType.TerminatedString || serializedType == SerializedType.SizedString;
		}
		FieldLengthBindings = GetBindings<FieldLengthAttribute>(list);
		FieldBitLengthAttribute = list.OfType<FieldBitLengthAttribute>().SingleOrDefault();
		FieldCountBindings = GetBindings<FieldCountAttribute>(list);
		FieldOffsetBindings = GetBindings<FieldOffsetAttribute>(list);
		FieldScaleBindings = GetBindings<FieldScaleAttribute>(list);
		FieldEndiannessBindings = GetBindings<FieldEndiannessAttribute>(list);
		FieldEncodingBindings = GetBindings<FieldEncodingAttribute>(list);
		ILookup<FieldAlignmentMode, FieldAlignmentAttribute> lookup = list.OfType<FieldAlignmentAttribute>().ToLookup((FieldAlignmentAttribute attribute) => attribute.Mode);
		IEnumerable<FieldAlignmentAttribute> source = lookup[FieldAlignmentMode.LeftAndRight].Concat(lookup[FieldAlignmentMode.LeftOnly]);
		IEnumerable<FieldAlignmentAttribute> source2 = lookup[FieldAlignmentMode.LeftAndRight].Concat(lookup[FieldAlignmentMode.RightOnly]);
		LeftFieldAlignmentBindings = GetBindings<FieldAlignmentAttribute>(source.Cast<object>().ToArray());
		RightFieldAlignmentBindings = GetBindings<FieldAlignmentAttribute>(source2.Cast<object>().ToArray());
		FieldValueAttributeBase[] list2 = list.OfType<FieldValueAttributeBase>().ToArray();
		FieldValueAttributes = new ReadOnlyCollection<FieldValueAttributeBase>(list2);
		if (FieldValueAttributes.Count > 0)
		{
			FieldValueBindings = GetBindings<FieldValueAttributeBase>(list);
		}
		SerializeWhenAttribute[] array = list.OfType<SerializeWhenAttribute>().ToArray();
		SerializeWhenAttributes = new ReadOnlyCollection<SerializeWhenAttribute>(array);
		if (SerializeWhenAttributes.Count > 0)
		{
			SerializeWhenBindings = new ReadOnlyCollection<ConditionalBinding>(array.Select((SerializeWhenAttribute attribute) => new ConditionalBinding(attribute, GetBindingLevel(attribute.Binding))).ToList());
		}
		SerializeWhenNotAttribute[] array2 = list.OfType<SerializeWhenNotAttribute>().ToArray();
		SerializeWhenNotAttributes = new ReadOnlyCollection<SerializeWhenNotAttribute>(array2);
		if (SerializeWhenNotAttributes.Count > 0)
		{
			SerializeWhenNotBindings = new ReadOnlyCollection<ConditionalBinding>(array2.Select((SerializeWhenNotAttribute attribute) => new ConditionalBinding(attribute, GetBindingLevel(attribute.Binding))).ToList());
		}
		if ((object)subType == null)
		{
			SubtypeBaseAttribute[] array3 = list.OfType<SubtypeAttribute>().Cast<SubtypeBaseAttribute>().ToArray();
			SubtypeAttributes = new ReadOnlyCollection<SubtypeBaseAttribute>(array3);
			SubtypeBindings = GetBindings(array3, Type);
			SubtypeDefaultAttribute = list.OfType<SubtypeDefaultAttribute>().SingleOrDefault();
			if (SubtypeDefaultAttribute != null && !System.Reflection.TypeExtensions.IsAssignableFrom(Type, SubtypeDefaultAttribute.Subtype))
			{
				throw new InvalidOperationException($"{SubtypeDefaultAttribute.Subtype} is not a subtype of {Type}");
			}
			SubtypeFactoryAttribute subtypeFactoryAttribute = list.OfType<SubtypeFactoryAttribute>().SingleOrDefault();
			if (subtypeFactoryAttribute != null)
			{
				SubtypeFactoryBinding = GetBinding(subtypeFactoryAttribute);
				SubtypeFactory = (ISubtypeFactory)System.Reflection.TypeExtensions.GetConstructor(subtypeFactoryAttribute.FactoryType, new Type[0]).Invoke(null);
			}
		}
		SubtypeBaseAttribute[] array4 = list.OfType<ItemSubtypeAttribute>().Cast<SubtypeBaseAttribute>().ToArray();
		ItemSubtypeAttributes = new ReadOnlyCollection<SubtypeBaseAttribute>(array4);
		if (array4.Length != 0)
		{
			Type checkType;
			if (Type.IsArray)
			{
				checkType = Type.GetElementType();
			}
			else
			{
				if (!System.Reflection.TypeExtensions.IsAssignableFrom(typeof(IList), Type))
				{
					throw new InvalidOperationException("ItemSubtype can only be used with collections.");
				}
				Type[] genericArguments = System.Reflection.TypeExtensions.GetGenericArguments(Type);
				if (genericArguments.Length > 1)
				{
					throw new InvalidOperationException("Multiple generic arguments not supported.");
				}
				checkType = genericArguments[0];
			}
			ItemSubtypeBindings = GetBindings(array4, checkType);
		}
		ItemSubtypeFactoryAttribute itemSubtypeFactoryAttribute = list.OfType<ItemSubtypeFactoryAttribute>().SingleOrDefault();
		if (itemSubtypeFactoryAttribute != null)
		{
			ItemSubtypeFactoryBinding = GetBinding(itemSubtypeFactoryAttribute);
			ItemSubtypeFactory = (ISubtypeFactory)System.Reflection.TypeExtensions.GetConstructor(itemSubtypeFactoryAttribute.FactoryType, new Type[0]).Invoke(null);
		}
		ItemSubtypeDefaultAttribute = list.OfType<ItemSubtypeDefaultAttribute>().SingleOrDefault();
		SerializeUntilAttribute = list.OfType<SerializeUntilAttribute>().SingleOrDefault();
		if (SerializeUntilAttribute != null)
		{
			SerializeUntilBinding = GetBinding(SerializeUntilAttribute);
		}
		ItemLengthBindings = GetBindings<ItemLengthAttribute>(list);
		ItemSerializeUntilAttribute = list.OfType<ItemSerializeUntilAttribute>().SingleOrDefault();
		if (ItemSerializeUntilAttribute != null)
		{
			ItemSerializeUntilBinding = GetBinding(ItemSerializeUntilAttribute);
		}
	}

	public SerializedType GetSerializedType(Type referenceType = null)
	{
		if ((object)referenceType == null)
		{
			referenceType = BaseSerializedType;
		}
		SerializedType? serializedType = _serializedType;
		SerializedType value;
		if (serializedType.HasValue)
		{
			serializedType = _serializedType;
			if (serializedType.Value != 0)
			{
				serializedType = _serializedType;
				value = serializedType.Value;
				goto IL_004d;
			}
		}
		if (!DefaultSerializedTypes.TryGetValue(referenceType, out value))
		{
			return SerializedType.Default;
		}
		goto IL_004d;
		IL_004d:
		if (value == SerializedType.TerminatedString)
		{
			if (FieldLengthBindings != null)
			{
				value = SerializedType.SizedString;
			}
			if (base.Parent.ItemLengthBindings != null)
			{
				value = SerializedType.SizedString;
			}
		}
		return value;
	}

	public static object GetDefaultValue(SerializedType serializedType)
	{
		if (!SerializedTypeDefault.TryGetValue(serializedType, out var value))
		{
			return null;
		}
		return value;
	}

	public ValueNode CreateSerializer(ValueNode parent)
	{
		try
		{
			return CreateSerializerOverride(parent);
		}
		catch (Exception innerException)
		{
			string arg = ((base.Name == null) ? $"type '{Type}'" : $"member '{base.Name}'");
			throw new InvalidOperationException($"Error serializing {arg}.  See inner exception for detail.", innerException);
		}
	}

	internal abstract ValueNode CreateSerializerOverride(ValueNode parent);

	public int GetBindingLevel(BindingInfo binding)
	{
		int result = 0;
		switch (binding.RelativeSourceMode)
		{
		case RelativeSourceMode.Self:
			result = 1;
			break;
		case RelativeSourceMode.FindAncestor:
		case RelativeSourceMode.SerializationContext:
			result = FindAncestorLevel(binding);
			break;
		}
		return result;
	}

	public static bool IsValueType(Type type)
	{
		if (!type.GetTypeInfo().IsPrimitive && (object)type != typeof(string))
		{
			return (object)type == typeof(byte[]);
		}
		return true;
	}

	protected Func<object> CreateCompiledConstructor()
	{
		return CreateCompiledConstructor(Type);
	}

	protected static Func<object> CreateCompiledConstructor(Type type)
	{
		if ((object)type == typeof(string))
		{
			return () => string.Empty;
		}
		return CreateCompiledConstructor(System.Reflection.TypeExtensions.GetConstructor(type, new Type[0]));
	}

	protected static Func<object> CreateCompiledConstructor(ConstructorInfo constructor)
	{
		if ((object)constructor != null)
		{
			return Expression.Lambda<Func<object>>(Expression.New(constructor), Array.Empty<ParameterExpression>()).Compile();
		}
		return null;
	}

	private Binding GetBinding(FieldBindingBaseAttribute attribute)
	{
		return new Binding(attribute, GetBindingLevel(attribute.Binding));
	}

	private BindingCollection GetBindings<TAttribute>(IEnumerable<object> attributes) where TAttribute : FieldBindingBaseAttribute
	{
		List<TAttribute> source = attributes.OfType<TAttribute>().ToList();
		if (!source.Any())
		{
			return null;
		}
		return new BindingCollection(source.Select((TAttribute attribute) => new Binding(attribute, GetBindingLevel(attribute.Binding))));
	}

	private BindingCollection GetBindings(SubtypeBaseAttribute[] attributes, Type checkType)
	{
		if (attributes.Length == 0)
		{
			return null;
		}
		if ((from subtypeAttribute in attributes
			group subtypeAttribute by subtypeAttribute.Binding).Count() > 1)
		{
			throw new BindingException("Subtypes must all specify the same binding configuration.");
		}
		IEnumerable<Binding> bindings = attributes.Select((SubtypeBaseAttribute attribute) => new Binding(attribute, GetBindingLevel(attribute.Binding)));
		List<SubtypeBaseAttribute> list = attributes.Where((SubtypeBaseAttribute attribute) => attribute.BindingMode != BindingMode.OneWayToSource).ToList();
		if ((from attribute in list
			group attribute by attribute.Value).Count() < list.Count)
		{
			throw new InvalidOperationException("Subtype values must be unique.");
		}
		List<SubtypeBaseAttribute> list2 = attributes.Where((SubtypeBaseAttribute attribute) => attribute.BindingMode != BindingMode.OneWay).ToList();
		if ((from attribute in list2
			group attribute by attribute.Subtype).Count() < list2.Count)
		{
			throw new InvalidOperationException("Subtypes must be unique for two-way subtype bindings.  Set BindingMode to OneWay to disable updates to the binding source during serialization.");
		}
		SubtypeBaseAttribute subtypeBaseAttribute = attributes.FirstOrDefault((SubtypeBaseAttribute attribute) => !System.Reflection.TypeExtensions.IsAssignableFrom(checkType, attribute.Subtype));
		if (subtypeBaseAttribute != null)
		{
			throw new InvalidOperationException($"{subtypeBaseAttribute.Subtype} is not a subtype of {checkType}");
		}
		return new BindingCollection(bindings);
	}

	private int FindAncestorLevel(BindingInfo binding)
	{
		int num = 1;
		TypeNode parent = base.Parent;
		while (parent != null)
		{
			if (binding != null && binding.RelativeSourceMode == RelativeSourceMode.FindAncestor)
			{
				if (binding.AncestorLevel == num)
				{
					return num;
				}
				if ((object)binding.AncestorType != null && (object)parent.Type != null && System.Reflection.TypeExtensions.IsAssignableFrom(binding.AncestorType, parent.Type))
				{
					return num;
				}
			}
			parent = parent.Parent;
			num++;
		}
		if (binding != null && binding.RelativeSourceMode == RelativeSourceMode.SerializationContext)
		{
			return num;
		}
		throw new BindingException("No ancestor found.");
	}
}
