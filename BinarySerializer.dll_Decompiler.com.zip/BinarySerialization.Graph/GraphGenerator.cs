using System;
using System.Collections.Concurrent;
using BinarySerialization.Graph.TypeGraph;

namespace BinarySerialization.Graph;

internal class GraphGenerator
{
	private readonly ConcurrentDictionary<Type, RootTypeNode> _graphCache = new ConcurrentDictionary<Type, RootTypeNode>();

	public RootTypeNode GenerateGraph(Type valueType)
	{
		return _graphCache.GetOrAdd(valueType, (Type type) => new RootTypeNode(type));
	}
}
