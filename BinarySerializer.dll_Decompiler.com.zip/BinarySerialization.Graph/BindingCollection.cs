using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization.Graph;

internal class BindingCollection : ReadOnlyCollection<Binding>, IBinding
{
	private IEnumerable<Binding> AdditionalBindings => from binding in this.Skip(1)
		where binding.BindingMode != BindingMode.OneWayToSource
		select binding;

	public bool IsConst => base[0].IsConst;

	public object ConstValue => base[0].ConstValue;

	public BindingCollection(IEnumerable<Binding> bindings)
		: base((IList<Binding>)bindings.ToList())
	{
		if (this.Count((Binding binding) => IsConst) > 1)
		{
			throw new InvalidOperationException("A field may not specify more than one constant binding.");
		}
	}

	public object GetValue(ValueNode target)
	{
		return GetValue((Binding binding) => binding.GetValue(target));
	}

	public object GetBoundValue(ValueNode target)
	{
		return GetValue((Binding binding) => binding.GetBoundValue(target));
	}

	public void Bind(ValueNode target, Func<object> callback)
	{
		using IEnumerator<Binding> enumerator = GetEnumerator();
		while (enumerator.MoveNext())
		{
			Binding current = enumerator.Current;
			if (current.BindingMode != BindingMode.OneWay)
			{
				current.Bind(target, callback);
			}
		}
	}

	private object GetValue(Func<Binding, object> bindingFunction)
	{
		object value = bindingFunction(base[0]);
		if (base.Count > 1 && AdditionalBindings.Any(delegate(Binding binding)
		{
			object obj = bindingFunction(binding);
			if (value != null)
			{
				object obj2 = Convert.ChangeType(obj, value.GetType(), null);
				if (obj2 == null)
				{
					return false;
				}
				return !obj2.Equals(value);
			}
			return obj == null;
		}))
		{
			throw new InvalidOperationException("Multiple source fields bound to the same target must yield the same value.");
		}
		return value;
	}
}
