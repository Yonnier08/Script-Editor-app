using System;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization.Graph;

internal class Binding : IBinding
{
	private readonly object _constValue;

	public string Path { get; }

	public BindingMode BindingMode { get; }

	public IValueConverter ValueConverter { get; }

	public object ConverterParameter { get; }

	public RelativeSourceMode RelativeSourceMode { get; }

	public int Level { get; set; }

	public bool SupportsDeferredEvaluation { get; }

	public bool IsConst { get; }

	public object ConstValue
	{
		get
		{
			if (!IsConst)
			{
				throw new InvalidOperationException("Not const.");
			}
			return _constValue;
		}
	}

	public Binding(FieldBindingBaseAttribute attribute, int level)
	{
		Path = attribute.Path;
		BindingMode = attribute.BindingMode;
		if (attribute is IConstAttribute constAttribute && Path == null)
		{
			IsConst = true;
			_constValue = constAttribute.GetConstValue();
		}
		if ((object)attribute.ConverterType != null)
		{
			ValueConverter = Activator.CreateInstance(attribute.ConverterType) as IValueConverter;
			if (ValueConverter == null)
			{
				throw new InvalidOperationException($"{attribute.ConverterType} does not implement IValueConverter.");
			}
			ConverterParameter = attribute.ConverterParameter;
		}
		RelativeSourceMode = attribute.RelativeSourceMode;
		Level = level;
		SupportsDeferredEvaluation = attribute.SupportsDeferredBinding;
	}

	public object GetValue(ValueNode target)
	{
		if (IsConst)
		{
			return _constValue;
		}
		if (BindingMode == BindingMode.OneWayToSource)
		{
			return null;
		}
		ValueNode source = GetSource(target);
		CheckSource(source);
		if (ValueConverter != null)
		{
			return Convert(source.Value, target.CreateLazySerializationContext());
		}
		return source.Value;
	}

	public object GetBoundValue(ValueNode target)
	{
		if (IsConst)
		{
			return _constValue;
		}
		ValueNode source = GetSource(target);
		CheckSource(source);
		if (ValueConverter != null)
		{
			return Convert(source.BoundValue, target.CreateLazySerializationContext());
		}
		return source.BoundValue;
	}

	public void Bind(ValueNode target, Func<object> callback)
	{
		if (!IsConst)
		{
			ValueNode source = GetSource(target);
			Func<object> item = ((ValueConverter == null) ? callback : ((Func<object>)(() => ConvertBack(callback(), target.CreateLazySerializationContext()))));
			source.Bindings.Add(item);
		}
	}

	public TNode GetSource<TNode>(TNode target) where TNode : Node<TNode>
	{
		if (IsConst)
		{
			throw new InvalidOperationException("Binding is constant.");
		}
		return GetRelativeSource(target).GetChild(Path);
	}

	private TNode GetRelativeSource<TNode>(TNode target) where TNode : Node<TNode>
	{
		TNode result = null;
		switch (RelativeSourceMode)
		{
		case RelativeSourceMode.Self:
			return target.Parent;
		case RelativeSourceMode.FindAncestor:
		case RelativeSourceMode.SerializationContext:
			return FindAncestor(target);
		default:
			return result;
		}
	}

	private TNode FindAncestor<TNode>(TNode target) where TNode : Node<TNode>
	{
		int num = 1;
		TNode parent = target.Parent;
		while (parent != null)
		{
			if (num == Level)
			{
				return parent;
			}
			if (parent.Parent == null && RelativeSourceMode == RelativeSourceMode.SerializationContext)
			{
				return parent;
			}
			parent = parent.Parent;
			if (!(parent is RootValueNode))
			{
				num++;
			}
		}
		return null;
	}

	private object Convert(object value, BinarySerializationContext context)
	{
		return ValueConverter.Convert(value, ConverterParameter, context);
	}

	private object ConvertBack(object value, BinarySerializationContext context)
	{
		return ValueConverter.ConvertBack(value, ConverterParameter, context);
	}

	private void CheckSource(ValueNode source)
	{
		if (!source.Visited && !SupportsDeferredEvaluation && !source.TypeNode.IsIgnored)
		{
			throw new InvalidOperationException("This attribute does not support forward binding.  Consider specifying a BindingMode of OneWayToSource.");
		}
	}
}
