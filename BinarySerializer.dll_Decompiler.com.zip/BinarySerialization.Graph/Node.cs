using System;
using System.Collections.Generic;
using System.Linq;

namespace BinarySerialization.Graph;

public abstract class Node<TNode> : IEquatable<Node<TNode>> where TNode : Node<TNode>
{
	private const char PathSeparator = '.';

	public TNode Parent { get; }

	public string Name { get; protected set; }

	public List<TNode> Children { get; set; }

	protected Node(TNode parent)
	{
		Parent = parent;
	}

	public bool Equals(Node<TNode> other)
	{
		if (other == null)
		{
			return false;
		}
		if (this == other)
		{
			return true;
		}
		return string.Equals(Name, other.Name);
	}

	public TNode GetChild(string path)
	{
		string[] array = path.Split(new char[1] { '.' });
		if (array.Length == 0)
		{
			throw new BindingException("Path cannot be empty.");
		}
		TNode val = (TNode)this;
		string[] array2 = array;
		foreach (string name in array2)
		{
			val = val.Children.SingleOrDefault((TNode c) => c.Name == name);
			if (val == null)
			{
				throw new BindingException($"No field found at '{path}'.");
			}
		}
		return val;
	}

	public override string ToString()
	{
		return Name ?? base.ToString();
	}

	public override bool Equals(object obj)
	{
		if (obj == null)
		{
			return false;
		}
		if (this == obj)
		{
			return true;
		}
		if ((object)obj.GetType() == GetType())
		{
			return Equals((Node<TNode>)obj);
		}
		return false;
	}

	public override int GetHashCode()
	{
		if (Name == null)
		{
			return 0;
		}
		return Name.GetHashCode();
	}
}
