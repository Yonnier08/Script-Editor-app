using System;

namespace BinarySerialization.Graph;

internal class ConditionalBinding : Binding
{
	private readonly Type _conditionalValueType;

	public object ConditionalValue { get; }

	public ConditionalBinding(ConditionalAttribute attribute, int level)
		: base(attribute, level)
	{
		ConditionalValue = attribute.Value;
		if (ConditionalValue != null)
		{
			_conditionalValueType = ConditionalValue.GetType();
		}
	}

	public bool IsSatisfiedBy(object value)
	{
		if (ConditionalValue == null && value == null)
		{
			return true;
		}
		if (ConditionalValue == null || value == null)
		{
			return false;
		}
		return value.ConvertTo(_conditionalValueType).Equals(ConditionalValue);
	}
}
