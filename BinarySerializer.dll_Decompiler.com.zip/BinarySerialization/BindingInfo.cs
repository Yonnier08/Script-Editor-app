using System;

namespace BinarySerialization;

public class BindingInfo
{
	public string Path { get; set; }

	public BindingMode BindingMode { get; set; }

	public int AncestorLevel { get; set; }

	public Type AncestorType { get; set; }

	public RelativeSourceMode RelativeSourceMode { get; set; }

	public Type ConverterType { get; set; }

	public object ConverterParameter { get; set; }

	internal BindingInfo()
	{
	}

	internal BindingInfo(string path, BindingMode bindingMode, RelativeSourceMode relativeSourceMode, Type converterType = null, object converterParameter = null)
	{
		Path = path;
		BindingMode = bindingMode;
		RelativeSourceMode = relativeSourceMode;
		ConverterType = converterType;
		ConverterParameter = converterParameter;
	}

	internal BindingInfo(string path, Type converterType = null, object converterParameter = null)
		: this(path, BindingMode.TwoWay, RelativeSourceMode.Self, converterType, converterParameter)
	{
	}

	public override bool Equals(object obj)
	{
		if (obj == null)
		{
			return false;
		}
		if (this == obj)
		{
			return true;
		}
		if ((object)obj.GetType() == GetType())
		{
			return Equals((BindingInfo)obj);
		}
		return false;
	}

	public override int GetHashCode()
	{
		return 0;
	}

	protected bool Equals(BindingInfo other)
	{
		if (string.Equals(Path, other.Path) && AncestorLevel == other.AncestorLevel && (object)AncestorType == other.AncestorType && (object)ConverterType == other.ConverterType && RelativeSourceMode == other.RelativeSourceMode)
		{
			return object.Equals(ConverterParameter, other.ConverterParameter);
		}
		return false;
	}
}
