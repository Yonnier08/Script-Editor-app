namespace BinarySerialization;

public sealed class FieldValueAttribute : FieldValueAttributeBase
{
	public FieldValueAttribute(string valuePath)
		: base(valuePath)
	{
	}

	protected override object GetInitialState(BinarySerializationContext context)
	{
		return context.Value;
	}

	protected override object GetUpdatedState(object state, byte[] buffer, int offset, int count)
	{
		return state;
	}

	protected override object GetFinalValue(object state)
	{
		return state;
	}
}
