using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class ItemSubtypeDefaultAttribute : SubtypeDefaultBaseAttribute
{
	public ItemSubtypeDefaultAttribute(Type subtype)
		: base(subtype)
	{
	}
}
