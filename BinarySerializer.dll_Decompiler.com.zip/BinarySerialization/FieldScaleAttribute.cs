using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class FieldScaleAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	public double ConstScale { get; set; }

	public FieldScaleAttribute(double scale)
	{
		ConstScale = scale;
	}

	public FieldScaleAttribute(string path)
		: base(path)
	{
	}

	public object GetConstValue()
	{
		return ConstScale;
	}
}
