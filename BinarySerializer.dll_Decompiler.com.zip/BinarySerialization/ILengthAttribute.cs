namespace BinarySerialization;

internal interface ILengthAttribute : IBindableFieldAttribute
{
	ulong ConstLength { get; }
}
