using System;

namespace BinarySerialization;

public class BindingException : Exception
{
	internal BindingException(string message)
		: base(message)
	{
	}
}
