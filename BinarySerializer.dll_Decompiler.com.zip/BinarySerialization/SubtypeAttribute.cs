using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class SubtypeAttribute : SubtypeBaseAttribute
{
	public SubtypeAttribute(string valuePath, object value, Type subtype)
		: base(valuePath, value, subtype)
	{
	}
}
