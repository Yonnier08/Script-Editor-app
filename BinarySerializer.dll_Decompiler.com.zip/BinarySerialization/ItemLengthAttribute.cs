using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class ItemLengthAttribute : FieldBindingBaseAttribute, ILengthAttribute, IBindableFieldAttribute, IConstAttribute
{
	public ulong ConstLength { get; }

	public ItemLengthAttribute(ulong length)
	{
		ConstLength = length;
	}

	public ItemLengthAttribute(string lengthPath)
		: base(lengthPath)
	{
	}

	public object GetConstValue()
	{
		return ConstLength;
	}
}
