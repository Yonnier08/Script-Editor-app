using System;

namespace BinarySerialization;

internal interface IBindableFieldAttribute
{
	string Path { get; set; }

	int AncestorLevel { get; set; }

	Type AncestorType { get; set; }

	RelativeSourceMode RelativeSourceMode { get; set; }

	BindingMode BindingMode { get; set; }

	Type ConverterType { get; set; }

	object ConverterParameter { get; set; }
}
