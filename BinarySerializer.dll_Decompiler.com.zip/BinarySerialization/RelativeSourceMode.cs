namespace BinarySerialization;

public enum RelativeSourceMode
{
	Self,
	FindAncestor,
	SerializationContext
}
