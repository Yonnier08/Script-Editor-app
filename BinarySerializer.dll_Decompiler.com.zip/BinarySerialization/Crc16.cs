namespace BinarySerialization;

internal sealed class Crc16 : Crc<ushort>
{
	protected override int Width => 16;

	public Crc16(ushort polynomial, ushort initialValue)
		: base(polynomial, initialValue)
	{
	}

	protected override uint ToUInt32(ushort value)
	{
		return value;
	}

	protected override ushort FromUInt32(uint value)
	{
		return (ushort)value;
	}
}
