using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public abstract class SubtypeDefaultBaseAttribute : Attribute
{
	public Type Subtype { get; }

	protected SubtypeDefaultBaseAttribute(Type subtype)
	{
		Subtype = subtype;
	}
}
