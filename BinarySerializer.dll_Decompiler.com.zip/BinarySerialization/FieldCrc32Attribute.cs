namespace BinarySerialization;

public sealed class FieldCrc32Attribute : FieldValueAttributeBase
{
	private const uint DefaultPolynomial = 3988292384u;

	private const uint DefaultInitialValue = uint.MaxValue;

	private const uint DefaultFinalXor = uint.MaxValue;

	public uint Polynomial { get; set; } = 3988292384u;


	public uint InitialValue { get; set; } = uint.MaxValue;


	public bool IsDataReflected { get; set; } = true;


	public bool IsRemainderReflected { get; set; } = true;


	public uint FinalXor { get; set; } = uint.MaxValue;


	public FieldCrc32Attribute(string crcPath)
		: base(crcPath)
	{
	}

	protected override object GetInitialState(BinarySerializationContext context)
	{
		return new Crc32(Polynomial, InitialValue)
		{
			IsDataReflected = IsDataReflected,
			IsRemainderReflected = IsRemainderReflected,
			FinalXor = FinalXor
		};
	}

	protected override object GetUpdatedState(object state, byte[] buffer, int offset, int count)
	{
		Crc32 obj = (Crc32)state;
		obj.Compute(buffer, offset, count);
		return obj;
	}

	protected override object GetFinalValue(object state)
	{
		return ((Crc32)state).ComputeFinal();
	}
}
