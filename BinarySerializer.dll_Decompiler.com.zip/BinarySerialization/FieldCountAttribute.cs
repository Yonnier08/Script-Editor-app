using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class FieldCountAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	public ulong ConstCount { get; set; }

	public FieldCountAttribute(ulong count)
	{
		ConstCount = count;
	}

	public FieldCountAttribute(string path)
		: base(path)
	{
	}

	public object GetConstValue()
	{
		return ConstCount;
	}
}
