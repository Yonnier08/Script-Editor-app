using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

public interface IBinarySerializer
{
	Endianness Endianness { get; set; }

	Encoding Encoding { get; set; }

	event EventHandler<MemberSerializedEventArgs> MemberSerialized;

	event EventHandler<MemberSerializedEventArgs> MemberDeserialized;

	event EventHandler<MemberSerializingEventArgs> MemberSerializing;

	event EventHandler<MemberSerializingEventArgs> MemberDeserializing;

	void Serialize(Stream stream, object value, object context = null);

	long SizeOf(object value, object context = null);

	object Deserialize(Stream stream, Type type, object context = null);

	Task<object> DeserializeAsync(Stream stream, Type type, object context, CancellationToken cancellationToken);

	Task<object> DeserializeAsync(Stream stream, Type type, object context = null);

	Task<object> DeserializeAsync(Stream stream, Type type, CancellationToken cancellationToken);

	Task<T> DeserializeAsync<T>(Stream stream, object context = null);

	Task<T> DeserializeAsync<T>(Stream stream, object context, CancellationToken cancellationToken);

	Task<T> DeserializeAsync<T>(Stream stream, CancellationToken cancellationToken);

	object Deserialize(byte[] data, Type type, object context = null);

	T Deserialize<T>(Stream stream, object context = null);

	T Deserialize<T>(byte[] data, object context = null);
}
