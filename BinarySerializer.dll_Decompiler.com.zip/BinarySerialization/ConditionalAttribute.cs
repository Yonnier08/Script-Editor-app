using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public abstract class ConditionalAttribute : FieldBindingBaseAttribute
{
	public object Value { get; set; }

	protected ConditionalAttribute(string valuePath, object value)
		: base(valuePath)
	{
		Value = value;
	}
}
