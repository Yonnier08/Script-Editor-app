using System;
using System.Text;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class FieldEncodingAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	private readonly Encoding _encoding;

	public FieldEncodingAttribute(string encodingName)
	{
		_encoding = Encoding.GetEncoding(encodingName);
		base.BindingMode = BindingMode.OneWay;
	}

	public FieldEncodingAttribute(string path, Type converterType)
		: base(path)
	{
		base.ConverterType = converterType;
		base.BindingMode = BindingMode.OneWay;
	}

	public object GetConstValue()
	{
		return _encoding;
	}
}
