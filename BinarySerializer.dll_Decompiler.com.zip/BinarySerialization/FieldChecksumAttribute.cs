using System;

namespace BinarySerialization;

public class FieldChecksumAttribute : FieldValueAttributeBase
{
	public ChecksumMode Mode { get; set; }

	public FieldChecksumAttribute(string checksumPath)
		: base(checksumPath)
	{
	}

	protected override object GetInitialState(BinarySerializationContext context)
	{
		return (byte)0;
	}

	protected override object GetUpdatedState(object state, byte[] buffer, int offset, int count)
	{
		byte b = (byte)state;
		if (Mode == ChecksumMode.Xor)
		{
			for (int i = offset; i < count; i++)
			{
				b ^= buffer[i];
			}
		}
		else
		{
			for (int j = offset; j < count; j++)
			{
				b += buffer[j];
			}
		}
		return b;
	}

	protected override object GetFinalValue(object state)
	{
		byte b = (byte)state;
		return Mode switch
		{
			ChecksumMode.TwosComplement => (byte)(256 - b), 
			ChecksumMode.Modulo256 => (byte)(b % 256), 
			ChecksumMode.Xor => b, 
			_ => throw new ArgumentException(), 
		};
	}
}
