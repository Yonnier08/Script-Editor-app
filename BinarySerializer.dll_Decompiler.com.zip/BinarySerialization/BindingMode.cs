namespace BinarySerialization;

public enum BindingMode
{
	TwoWay,
	OneWay,
	OneWayToSource
}
