using System;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization;

internal class EventShuttle
{
	public bool HasSerializationSubscribers
	{
		get
		{
			if (this.MemberSerializing == null)
			{
				return this.MemberSerialized != null;
			}
			return true;
		}
	}

	public bool HasDeserializationSubscribers
	{
		get
		{
			if (this.MemberDeserializing == null)
			{
				return this.MemberDeserialized != null;
			}
			return true;
		}
	}

	public event EventHandler<MemberSerializedEventArgs> MemberSerialized;

	public event EventHandler<MemberSerializedEventArgs> MemberDeserialized;

	public event EventHandler<MemberSerializingEventArgs> MemberSerializing;

	public event EventHandler<MemberSerializingEventArgs> MemberDeserializing;

	public void OnMemberSerialized(ValueNode sender, string name, object value, BinarySerializationContext context, FieldLength offset, FieldLength localOffset)
	{
		this.MemberSerialized?.Invoke(sender, new MemberSerializedEventArgs(name, value, context, offset, localOffset));
	}

	public void OnMemberDeserialized(ValueNode sender, string name, object value, BinarySerializationContext context, FieldLength offset, FieldLength localOffset)
	{
		this.MemberDeserialized?.Invoke(sender, new MemberSerializedEventArgs(name, value, context, offset, localOffset));
	}

	public void OnMemberSerializing(ValueNode sender, string name, BinarySerializationContext context, FieldLength offset, FieldLength localOffset)
	{
		this.MemberSerializing?.Invoke(sender, new MemberSerializingEventArgs(name, context, offset, localOffset));
	}

	public void OnMemberDeserializing(ValueNode sender, string name, BinarySerializationContext context, FieldLength offset, FieldLength localOffset)
	{
		this.MemberDeserializing?.Invoke(sender, new MemberSerializingEventArgs(name, context, offset, localOffset));
	}
}
