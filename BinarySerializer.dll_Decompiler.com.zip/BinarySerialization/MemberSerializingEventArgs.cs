using System;

namespace BinarySerialization;

public class MemberSerializingEventArgs : EventArgs
{
	public string MemberName { get; }

	public BinarySerializationContext Context { get; }

	public FieldLength Offset { get; }

	public FieldLength LocalOffset { get; }

	public MemberSerializingEventArgs(string memberName, BinarySerializationContext context, FieldLength offset, FieldLength localOffset)
	{
		MemberName = memberName;
		Context = context;
		Offset = offset;
		LocalOffset = localOffset;
	}
}
