using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class SerializeAsAttribute : Attribute
{
	public SerializedType SerializedType { get; set; }

	public byte StringTerminator { get; set; }

	public SerializeAsAttribute()
	{
	}

	public SerializeAsAttribute(SerializedType serializedType)
	{
		SerializedType = serializedType;
	}
}
