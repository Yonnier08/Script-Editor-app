using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public abstract class SubtypeBaseAttribute : FieldBindingBaseAttribute
{
	public object Value { get; }

	public Type Subtype { get; }

	protected SubtypeBaseAttribute(string valuePath, object value, Type subtype)
		: base(valuePath)
	{
		Value = value;
		Subtype = subtype;
	}
}
