using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class FieldBitLengthAttribute : Attribute
{
	public ulong ConstLength { get; }

	public FieldBitLengthAttribute(ulong length)
	{
		ConstLength = length;
	}

	public object GetConstValue()
	{
		return ConstLength;
	}
}
