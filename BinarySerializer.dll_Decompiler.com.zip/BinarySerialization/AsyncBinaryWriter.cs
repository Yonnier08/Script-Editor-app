using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

internal class AsyncBinaryWriter : BinaryWriter
{
	public BoundedStream OutputStream { get; }

	public AsyncBinaryWriter(BoundedStream output, Encoding encoding)
		: base(output, encoding)
	{
		OutputStream = output;
	}

	public void Write(byte value, FieldLength fieldLength)
	{
		byte[] data = new byte[1] { value };
		Write(data, fieldLength);
	}

	public Task WriteAsync(byte value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] data = new byte[1] { value };
		return WriteAsync(data, fieldLength, cancellationToken);
	}

	public void Write(sbyte value, FieldLength fieldLength)
	{
		byte[] data = new byte[1] { (byte)value };
		Write(data, fieldLength);
	}

	public Task WriteAsync(sbyte value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] data = new byte[1] { (byte)value };
		return WriteAsync(data, fieldLength, cancellationToken);
	}

	public void Write(short value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(short value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(ushort value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(ushort value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(int value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(int value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(uint value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(uint value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(long value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(long value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(ulong value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(ulong value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(float value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(float value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public void Write(double value, FieldLength fieldLength)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Write(bytes, fieldLength);
	}

	public Task WriteAsync(double value, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		return WriteAsync(bytes, fieldLength, cancellationToken);
	}

	public Task WriteAsync(byte[] data, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		Resize(ref data, fieldLength);
		FieldLength length = fieldLength ?? ((FieldLength)data.Length);
		return OutputStream.WriteAsync(data, length, cancellationToken);
	}

	public void Write(byte[] data, FieldLength fieldLength)
	{
		Resize(ref data, fieldLength);
		FieldLength length = fieldLength ?? ((FieldLength)data.Length);
		OutputStream.Write(data, length);
	}

	private static void Resize(ref byte[] data, FieldLength length)
	{
		if (!(length == null))
		{
			int num = (int)length.TotalByteCount;
			if (data.Length != num)
			{
				Array.Resize(ref data, num);
			}
		}
	}
}
