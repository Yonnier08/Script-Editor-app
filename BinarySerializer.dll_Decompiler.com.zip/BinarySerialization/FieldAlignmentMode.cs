namespace BinarySerialization;

public enum FieldAlignmentMode
{
	LeftAndRight,
	LeftOnly,
	RightOnly
}
