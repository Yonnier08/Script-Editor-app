namespace BinarySerialization;

public class MemberSerializedEventArgs : MemberSerializingEventArgs
{
	public object Value { get; }

	public MemberSerializedEventArgs(string memberName, object value, BinarySerializationContext context, FieldLength offset, FieldLength localOffset)
		: base(memberName, context, offset, localOffset)
	{
		Value = value;
	}
}
