namespace BinarySerialization;

internal sealed class Crc32 : Crc<uint>
{
	protected override int Width => 32;

	public Crc32(uint polynomial, uint initialValue)
		: base(polynomial, initialValue)
	{
		base.IsDataReflected = true;
		base.IsRemainderReflected = true;
		base.FinalXor = uint.MaxValue;
	}

	protected override uint ToUInt32(uint value)
	{
		return value;
	}

	protected override uint FromUInt32(uint value)
	{
		return value;
	}
}
