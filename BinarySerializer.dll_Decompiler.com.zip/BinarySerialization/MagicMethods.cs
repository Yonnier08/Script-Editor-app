using System;
using System.Linq;
using System.Reflection;

namespace BinarySerialization;

internal static class MagicMethods
{
	public static Func<object, object> MagicFunc(Type targetType, MethodInfo method)
	{
		return (Func<object, object>)System.Reflection.TypeExtensions.GetMethod(typeof(MagicMethods), "MagicFuncHelper", BindingFlags.Static | BindingFlags.NonPublic).MakeGenericMethod(targetType, method.ReturnType).Invoke(null, new object[1] { method });
	}

	public static Action<object, object> MagicAction(Type targetType, MethodInfo method)
	{
		return (Action<object, object>)System.Reflection.TypeExtensions.GetMethod(typeof(MagicMethods), "MagicActionHelper", BindingFlags.Static | BindingFlags.NonPublic).MakeGenericMethod(targetType, method.GetParameters().Single().ParameterType).Invoke(null, new object[1] { method });
	}

	private static Func<object, object> MagicFuncHelper<TTarget, TReturn>(MethodInfo method)
	{
		Func<TTarget, TReturn> func = (Func<TTarget, TReturn>)method.CreateDelegate(typeof(Func<TTarget, TReturn>));
		return Func;
		object Func(object target)
		{
			return func((TTarget)target);
		}
	}

	private static Action<object, object> MagicActionHelper<TTarget, TValue>(MethodInfo method)
	{
		Action<TTarget, TValue> action = (Action<TTarget, TValue>)method.CreateDelegate(typeof(Action<TTarget, TValue>));
		return Func;
		void Func(object target, object value)
		{
			if (value != null)
			{
				action((TTarget)target, (TValue)value);
			}
		}
	}
}
