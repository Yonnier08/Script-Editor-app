using System;

namespace BinarySerialization;

internal static class Bytes
{
	public static ushort Reverse(ushort value)
	{
		return (ushort)(((value & 0xFF00) >> 8) | ((value & 0xFF) << 8));
	}

	public static short Reverse(short value)
	{
		return (short)Reverse((ushort)value);
	}

	public static uint Reverse(uint value)
	{
		return ((value & 0xFF000000u) >> 24) | ((value & 0xFF0000) >> 8) | ((value & 0xFF00) << 8) | ((value & 0xFF) << 24);
	}

	public static int Reverse(int value)
	{
		return (int)Reverse((uint)value);
	}

	public static ulong Reverse(ulong value)
	{
		return ((value & 0xFF00000000000000uL) >> 56) | ((value & 0xFF000000000000L) >> 40) | ((value & 0xFF0000000000L) >> 24) | ((value & 0xFF00000000L) >> 8) | ((value & 0xFF000000u) << 8) | ((value & 0xFF0000) << 24) | ((value & 0xFF00) << 40) | ((value & 0xFF) << 56);
	}

	public static long Reverse(long value)
	{
		return (long)Reverse((ulong)value);
	}

	public static float Reverse(float value)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Array.Reverse((Array)bytes);
		return BitConverter.ToSingle(bytes, 0);
	}

	public static double Reverse(double value)
	{
		byte[] bytes = BitConverter.GetBytes(value);
		Array.Reverse((Array)bytes);
		return BitConverter.ToDouble(bytes, 0);
	}
}
