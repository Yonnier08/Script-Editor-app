using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BinarySerialization.Graph;
using BinarySerialization.Graph.ValueGraph;

namespace BinarySerialization;

public class BinarySerializer : IBinarySerializer
{
	private const Endianness DefaultEndianness = Endianness.Little;

	private static readonly Encoding DefaultEncoding = Encoding.UTF8;

	private static readonly GraphGenerator GraphGenerator = new GraphGenerator();

	private readonly EventShuttle _eventShuttle = new EventShuttle();

	public Endianness Endianness { get; set; }

	public Encoding Encoding { get; set; }

	public event EventHandler<MemberSerializedEventArgs> MemberSerialized
	{
		add
		{
			_eventShuttle.MemberSerialized += value;
		}
		remove
		{
			_eventShuttle.MemberSerialized -= value;
		}
	}

	public event EventHandler<MemberSerializedEventArgs> MemberDeserialized
	{
		add
		{
			_eventShuttle.MemberDeserialized += value;
		}
		remove
		{
			_eventShuttle.MemberDeserialized -= value;
		}
	}

	public event EventHandler<MemberSerializingEventArgs> MemberSerializing
	{
		add
		{
			_eventShuttle.MemberSerializing += value;
		}
		remove
		{
			_eventShuttle.MemberSerializing -= value;
		}
	}

	public event EventHandler<MemberSerializingEventArgs> MemberDeserializing
	{
		add
		{
			_eventShuttle.MemberDeserializing += value;
		}
		remove
		{
			_eventShuttle.MemberDeserializing -= value;
		}
	}

	public BinarySerializer()
	{
		Endianness = Endianness.Little;
		Encoding = DefaultEncoding;
	}

	public void Serialize(Stream stream, object value, object context = null)
	{
		if (stream == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (value != null)
		{
			RootValueNode rootValueNode = CreateSerializer(value.GetType(), context);
			rootValueNode.Value = value;
			rootValueNode.Bind();
			rootValueNode.Serialize(new BoundedStream(stream, "root"), _eventShuttle);
		}
	}

	public async Task SerializeAsync(Stream stream, object value, object context = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		if (stream == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (value != null)
		{
			RootValueNode rootValueNode = CreateSerializer(value.GetType(), context);
			rootValueNode.Value = value;
			rootValueNode.Bind();
			await rootValueNode.SerializeAsync(new BoundedStream(stream, "root"), _eventShuttle, align: true, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	public async Task SerializeAsync(Stream stream, object value, CancellationToken cancellationToken)
	{
		if (stream == null)
		{
			throw new ArgumentNullException("stream");
		}
		if (value != null)
		{
			RootValueNode rootValueNode = CreateSerializer(value.GetType(), null);
			rootValueNode.Value = value;
			rootValueNode.Bind();
			await rootValueNode.SerializeAsync(new BoundedStream(stream, "root"), _eventShuttle, align: true, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	public long SizeOf(object value, object context = null)
	{
		NullStream nullStream = new NullStream();
		Serialize(nullStream, value, context);
		return nullStream.Length;
	}

	public async Task<long> SizeOfAsync(object value, object context = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		NullStream nullStream = new NullStream();
		await SerializeAsync(nullStream, value, context, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return nullStream.Length;
	}

	public object Deserialize(Stream stream, Type type, object context = null)
	{
		RootValueNode rootValueNode = CreateSerializer(type, context);
		rootValueNode.Deserialize(new BoundedStream(stream, "root"), _eventShuttle);
		return rootValueNode.Value;
	}

	public async Task<object> DeserializeAsync(Stream stream, Type type, object context, CancellationToken cancellationToken)
	{
		RootValueNode serializer = CreateSerializer(type, context);
		await serializer.DeserializeAsync(new BoundedStream(stream, "root"), _eventShuttle, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return serializer.Value;
	}

	private RootValueNode CreateSerializer(Type type, object context)
	{
		RootValueNode obj = (RootValueNode)GraphGenerator.GenerateGraph(type).CreateSerializer(null);
		obj.EndiannessCallback = () => Endianness;
		obj.EncodingCallback = () => Encoding;
		obj.Context = context;
		return obj;
	}

	public Task<object> DeserializeAsync(Stream stream, Type type, object context = null)
	{
		return DeserializeAsync(stream, type, context, CancellationToken.None);
	}

	public Task<object> DeserializeAsync(Stream stream, Type type, CancellationToken cancellationToken)
	{
		return DeserializeAsync(stream, type, null, cancellationToken);
	}

	public async Task<T> DeserializeAsync<T>(Stream stream, object context = null)
	{
		return (T)(await DeserializeAsync(stream, typeof(T), context).ConfigureAwait(continueOnCapturedContext: false));
	}

	public async Task<T> DeserializeAsync<T>(Stream stream, object context, CancellationToken cancellationToken)
	{
		return (T)(await DeserializeAsync(stream, typeof(T), context, cancellationToken).ConfigureAwait(continueOnCapturedContext: false));
	}

	public async Task<T> DeserializeAsync<T>(Stream stream, CancellationToken cancellationToken)
	{
		return (T)(await DeserializeAsync(stream, typeof(T), cancellationToken).ConfigureAwait(continueOnCapturedContext: false));
	}

	public object Deserialize(byte[] data, Type type, object context = null)
	{
		return Deserialize(new MemoryStream(data), type, context);
	}

	public Task<object> DeserializeAsync(byte[] data, Type type, object context = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return DeserializeAsync(new MemoryStream(data), type, context, cancellationToken);
	}

	public T Deserialize<T>(Stream stream, object context = null)
	{
		return (T)Deserialize(stream, typeof(T), context);
	}

	public T Deserialize<T>(byte[] data, object context = null)
	{
		return Deserialize<T>(new MemoryStream(data), context);
	}

	public Task<T> DeserializeAsync<T>(byte[] data, object context = null)
	{
		return DeserializeAsync<T>(new MemoryStream(data), context);
	}
}
