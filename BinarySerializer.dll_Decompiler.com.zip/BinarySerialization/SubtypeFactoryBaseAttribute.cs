using System;
using System.Reflection;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public abstract class SubtypeFactoryBaseAttribute : FieldBindingBaseAttribute
{
	public Type FactoryType { get; }

	protected SubtypeFactoryBaseAttribute(string path, Type factoryType)
		: base(path)
	{
		if (!System.Reflection.TypeExtensions.IsAssignableFrom(typeof(ISubtypeFactory), factoryType))
		{
			throw new ArgumentException("Factory type must implement ISubtypeFactory", "factoryType");
		}
		FactoryType = factoryType;
	}
}
