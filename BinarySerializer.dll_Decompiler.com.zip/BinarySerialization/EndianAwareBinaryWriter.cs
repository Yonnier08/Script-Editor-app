using System;
using System.IO;
using System.Text;

namespace BinarySerialization;

[Obsolete("This class is no longer used internally and may be removed in the future.")]
public class EndianAwareBinaryWriter : BinaryWriter
{
	public Endianness Endianness { get; set; }

	public EndianAwareBinaryWriter(Stream output)
		: base(output)
	{
	}

	public EndianAwareBinaryWriter(Stream output, Encoding encoding)
		: base(output, encoding)
	{
	}

	public EndianAwareBinaryWriter(Stream output, Encoding encoding, Endianness endianness)
		: base(output, encoding)
	{
		Endianness = endianness;
	}

	public EndianAwareBinaryWriter(Stream output, Endianness endianness)
		: base(output)
	{
		Endianness = endianness;
	}

	public override void Write(short value)
	{
		short value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(ushort value)
	{
		ushort value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(int value)
	{
		int value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(uint value)
	{
		uint value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(long value)
	{
		long value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(ulong value)
	{
		ulong value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(float value)
	{
		float value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}

	public override void Write(double value)
	{
		double value2 = ((Endianness == Endianness.Big) ? Bytes.Reverse(value) : value);
		base.Write(value2);
	}
}
