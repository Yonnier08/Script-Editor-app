using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class SubtypeDefaultAttribute : SubtypeDefaultBaseAttribute
{
	public SubtypeDefaultAttribute(Type subtype)
		: base(subtype)
	{
	}
}
