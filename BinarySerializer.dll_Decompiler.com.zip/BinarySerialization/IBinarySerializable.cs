using System.IO;

namespace BinarySerialization;

public interface IBinarySerializable
{
	void Serialize(Stream stream, Endianness endianness, BinarySerializationContext serializationContext);

	void Deserialize(Stream stream, Endianness endianness, BinarySerializationContext serializationContext);
}
