using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class ItemSubtypeAttribute : SubtypeBaseAttribute
{
	public ItemSubtypeAttribute(string valuePath, object value, Type subtype)
		: base(valuePath, value, subtype)
	{
	}
}
