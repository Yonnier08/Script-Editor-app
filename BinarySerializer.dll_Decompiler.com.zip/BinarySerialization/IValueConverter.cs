namespace BinarySerialization;

public interface IValueConverter
{
	object Convert(object value, object parameter, BinarySerializationContext context);

	object ConvertBack(object value, object parameter, BinarySerializationContext context);
}
