using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

internal class TapStream : BoundedStream
{
	private const string TappingErrorMessage = "Not supported while tapping.";

	private readonly Stream _tap;

	public override bool CanSeek => false;

	public override long Position
	{
		get
		{
			return base.Position;
		}
		set
		{
			throw new InvalidOperationException("Not supported while tapping.");
		}
	}

	protected override bool IsByteBarrier => true;

	public TapStream(Stream source, Stream tap, string name)
		: base(source, name)
	{
		_tap = tap;
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		throw new InvalidOperationException("Not supported while tapping.");
	}

	public override void SetLength(long value)
	{
		throw new InvalidOperationException("Not supported while tapping.");
	}

	protected override void WriteByteAligned(byte[] buffer, int length)
	{
		_tap.Write(buffer, 0, length);
		base.WriteByteAligned(buffer, length);
	}

	protected override async Task WriteByteAlignedAsync(byte[] buffer, int length, CancellationToken cancellationToken)
	{
		await _tap.WriteAsync(buffer, 0, length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await base.WriteByteAlignedAsync(buffer, length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	protected override int ReadByteAligned(byte[] buffer, int length)
	{
		int num = base.ReadByteAligned(buffer, length);
		_tap.Write(buffer, 0, num);
		return num;
	}

	protected override async Task<int> ReadByteAlignedAsync(byte[] buffer, int length, CancellationToken cancellationToken)
	{
		int read = await base.ReadByteAlignedAsync(buffer, length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await _tap.WriteAsync(buffer, 0, read, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return read;
	}

	public override async Task FlushAsync(CancellationToken cancellationToken)
	{
		await _tap.FlushAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		await base.FlushAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	public override void Flush()
	{
		_tap.Flush();
		base.Flush();
	}
}
