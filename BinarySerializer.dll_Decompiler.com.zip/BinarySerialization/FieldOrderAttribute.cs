using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class FieldOrderAttribute : Attribute
{
	public int Order { get; set; }

	public FieldOrderAttribute(int order)
	{
		Order = order;
	}
}
