using System;
using System.IO;
using System.Text;

namespace BinarySerialization;

[Obsolete("This class is no longer used internally and may be removed in the future.")]
public class EndianAwareBinaryReader : BinaryReader
{
	public Endianness Endianness { get; set; }

	public EndianAwareBinaryReader(Stream input)
		: base(input)
	{
	}

	public EndianAwareBinaryReader(Stream input, Encoding encoding)
		: base(input, encoding)
	{
	}

	public EndianAwareBinaryReader(Stream input, Encoding encoding, Endianness endianness)
		: base(input, encoding)
	{
		Endianness = endianness;
	}

	public EndianAwareBinaryReader(Stream input, Endianness endianness)
		: base(input)
	{
		Endianness = endianness;
	}

	public override short ReadInt16()
	{
		short num = base.ReadInt16();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override ushort ReadUInt16()
	{
		ushort num = base.ReadUInt16();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override int ReadInt32()
	{
		int num = base.ReadInt32();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override uint ReadUInt32()
	{
		uint num = base.ReadUInt32();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override long ReadInt64()
	{
		long num = base.ReadInt64();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override ulong ReadUInt64()
	{
		ulong num = base.ReadUInt64();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override float ReadSingle()
	{
		float num = base.ReadSingle();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}

	public override double ReadDouble()
	{
		double num = base.ReadDouble();
		if (Endianness != Endianness.Big)
		{
			return num;
		}
		return Bytes.Reverse(num);
	}
}
