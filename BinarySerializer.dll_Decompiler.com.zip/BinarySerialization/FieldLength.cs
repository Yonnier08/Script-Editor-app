using System;

namespace BinarySerialization;

public class FieldLength : IEquatable<FieldLength>
{
	private const int BitsPerByte = 8;

	public static readonly FieldLength Zero = new FieldLength(0);

	public static readonly FieldLength MaxValue = new FieldLength(long.MaxValue, 0L);

	public long ByteCount { get; }

	public int BitCount { get; }

	public long TotalBitCount => ByteCount * 8 + BitCount;

	public long TotalByteCount
	{
		get
		{
			if (BitCount <= 0)
			{
				return ByteCount;
			}
			return ByteCount + 1;
		}
	}

	public FieldLength(long byteCount, long bitCount = 0L)
	{
		ByteCount = byteCount + bitCount / 8;
		BitCount = (int)bitCount % 8;
	}

	public FieldLength(int byteCount, int bitCount = 0)
		: this(Convert.ToInt64(byteCount), bitCount)
	{
	}

	public bool Equals(FieldLength other)
	{
		if ((object)other == null)
		{
			return false;
		}
		if ((object)this == other)
		{
			return true;
		}
		if (ByteCount == other.ByteCount)
		{
			return BitCount == other.BitCount;
		}
		return false;
	}

	public override bool Equals(object obj)
	{
		if (obj == null)
		{
			return false;
		}
		if (this == obj)
		{
			return true;
		}
		if ((object)obj.GetType() != GetType())
		{
			return false;
		}
		return Equals((FieldLength)obj);
	}

	public override int GetHashCode()
	{
		return (ByteCount.GetHashCode() * 397) ^ BitCount.GetHashCode();
	}

	public static FieldLength FromBitCount(int count)
	{
		return new FieldLength(0, count);
	}

	public static implicit operator FieldLength(long byteCount)
	{
		return new FieldLength(byteCount, 0L);
	}

	public static FieldLength operator +(FieldLength l1, FieldLength l2)
	{
		return new FieldLength(l1.ByteCount + l2.ByteCount, l1.BitCount + l2.BitCount);
	}

	public static FieldLength operator -(FieldLength l1, FieldLength l2)
	{
		return FromBitCount((int)(l1.TotalBitCount - l2.TotalBitCount));
	}

	public static FieldLength operator %(FieldLength l1, FieldLength l2)
	{
		return FromBitCount((int)l1.TotalBitCount % (int)l2.TotalBitCount);
	}

	public static bool operator ==(FieldLength l1, FieldLength l2)
	{
		return object.Equals(l1, l2);
	}

	public static bool operator !=(FieldLength l1, FieldLength l2)
	{
		return !object.Equals(l1, l2);
	}

	public static bool operator >(FieldLength l1, FieldLength l2)
	{
		if (l1.ByteCount > l2.ByteCount)
		{
			return true;
		}
		if (l1.ByteCount < l2.ByteCount)
		{
			return false;
		}
		if (l1.BitCount > l2.BitCount)
		{
			return true;
		}
		_ = l1.BitCount;
		_ = l2.BitCount;
		return false;
	}

	public static bool operator <(FieldLength l1, FieldLength l2)
	{
		if (l1.ByteCount < l2.ByteCount)
		{
			return true;
		}
		if (l1.ByteCount > l2.ByteCount)
		{
			return false;
		}
		if (l1.BitCount < l2.BitCount)
		{
			return true;
		}
		_ = l1.BitCount;
		_ = l2.BitCount;
		return false;
	}

	public static bool operator >=(FieldLength l1, FieldLength l2)
	{
		if (l1.ByteCount > l2.ByteCount)
		{
			return true;
		}
		if (l1.ByteCount < l2.ByteCount)
		{
			return false;
		}
		if (l1.BitCount > l2.BitCount)
		{
			return true;
		}
		if (l1.BitCount < l2.BitCount)
		{
			return false;
		}
		return true;
	}

	public static bool operator <=(FieldLength l1, FieldLength l2)
	{
		if (l1.ByteCount < l2.ByteCount)
		{
			return true;
		}
		if (l1.ByteCount > l2.ByteCount)
		{
			return false;
		}
		if (l1.BitCount < l2.BitCount)
		{
			return true;
		}
		if (l1.BitCount > l2.BitCount)
		{
			return false;
		}
		return true;
	}

	public static FieldLength Min(FieldLength a, FieldLength b)
	{
		if (!(a < b))
		{
			return b;
		}
		return a;
	}

	public static FieldLength Max(FieldLength a, FieldLength b)
	{
		if (!(a > b))
		{
			return b;
		}
		return a;
	}

	public override string ToString()
	{
		if (BitCount == 0)
		{
			return ByteCount.ToString();
		}
		long totalBitCount = TotalBitCount;
		if (totalBitCount != 1)
		{
			return $"{totalBitCount} bits";
		}
		return "1 bit";
	}
}
