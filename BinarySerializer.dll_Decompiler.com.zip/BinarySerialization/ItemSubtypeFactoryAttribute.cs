using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class ItemSubtypeFactoryAttribute : SubtypeFactoryBaseAttribute
{
	public ItemSubtypeFactoryAttribute(string path, Type factoryType)
		: base(path, factoryType)
	{
	}
}
