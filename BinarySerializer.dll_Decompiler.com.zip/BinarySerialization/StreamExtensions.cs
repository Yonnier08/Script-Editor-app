using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

public static class StreamExtensions
{
	public static void CopyTo(this Stream input, Stream output, int length, int bufferSize)
	{
		byte[] array = new byte[bufferSize];
		int num;
		while (length > 0 && (num = input.Read(array, 0, Math.Min(array.Length, length))) > 0)
		{
			output.Write(array, 0, num);
			length -= num;
		}
	}

	public static async Task CopyToAsync(this Stream input, Stream output, int length, int bufferSize, CancellationToken cancellationToken)
	{
		byte[] buffer = new byte[bufferSize];
		int read = default(int);
		while (true)
		{
			bool flag = length > 0;
			if (flag)
			{
				int num;
				read = (num = await input.ReadAsync(buffer, 0, Math.Min(buffer.Length, length), cancellationToken).ConfigureAwait(continueOnCapturedContext: false));
				flag = num > 0;
			}
			if (!flag)
			{
				break;
			}
			await output.WriteAsync(buffer, 0, read, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			length -= read;
		}
	}
}
