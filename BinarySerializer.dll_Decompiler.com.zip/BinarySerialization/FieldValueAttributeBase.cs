using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public abstract class FieldValueAttributeBase : FieldBindingBaseAttribute
{
	public virtual int BlockSize => 81920;

	protected FieldValueAttributeBase(string valuePath)
		: base(valuePath)
	{
	}

	internal virtual object GetInitialStateInternal(BinarySerializationContext context)
	{
		return GetInitialState(context);
	}

	internal object GetUpdatedStateInternal(object state, byte[] buffer, int offset, int count)
	{
		return GetUpdatedState(state, buffer, offset, count);
	}

	internal object GetFinalValueInternal(object state)
	{
		return GetFinalValue(state);
	}

	protected abstract object GetInitialState(BinarySerializationContext context);

	protected abstract object GetUpdatedState(object state, byte[] buffer, int offset, int count);

	protected abstract object GetFinalValue(object state);
}
