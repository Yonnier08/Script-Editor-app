using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

public class BoundedStream : Stream
{
	private const int BitsPerByte = 8;

	private readonly bool _canSeek;

	private readonly long _length;

	private readonly Func<FieldLength> _maxLengthDelegate;

	private readonly string _name;

	private readonly BoundedStream _root;

	private byte _bitBuffer;

	private int _bitOffset;

	public FieldLength GlobalPosition => _root.RelativePosition;

	public Stream Source { get; }

	public override bool CanRead => Source.CanRead;

	public override bool CanSeek => _canSeek;

	public override bool CanWrite => Source.CanWrite;

	public FieldLength MaxLength => _maxLengthDelegate?.Invoke();

	public override long Length
	{
		get
		{
			if (_canSeek)
			{
				return _length;
			}
			return Source.Length;
		}
	}

	public override long Position
	{
		get
		{
			return RelativePosition.ByteCount;
		}
		set
		{
			FieldLength fieldLength = value - RelativePosition;
			Source.Position += fieldLength.ByteCount;
			RelativePosition = value;
		}
	}

	internal FieldLength RelativePosition { get; set; } = FieldLength.Zero;


	internal bool IsAtLimit
	{
		get
		{
			if (MaxLength != null)
			{
				return Position >= MaxLength;
			}
			if (Source is BoundedStream boundedStream)
			{
				return boundedStream.IsAtLimit;
			}
			return false;
		}
	}

	internal FieldLength AvailableForReading
	{
		get
		{
			FieldLength fieldLength;
			if (MaxLength == null)
			{
				if (Source is BoundedStream boundedStream)
				{
					return boundedStream.AvailableForReading;
				}
				fieldLength = FieldLength.MaxValue;
			}
			else
			{
				fieldLength = MaxLength;
			}
			if (!_canSeek)
			{
				return fieldLength - Position;
			}
			return FieldLength.Min(fieldLength, Length) - Position;
		}
	}

	internal FieldLength AvailableForWriting
	{
		get
		{
			if (MaxLength != null)
			{
				return MaxLength - Position;
			}
			return (Source as BoundedStream)?.AvailableForWriting ?? ((FieldLength)long.MaxValue);
		}
	}

	protected virtual bool IsByteBarrier => false;

	internal BoundedStream(Stream source, string name, Func<FieldLength> maxLengthDelegate = null)
	{
		Source = source ?? throw new ArgumentNullException("source");
		_name = name;
		_maxLengthDelegate = maxLengthDelegate;
		_canSeek = source.CanSeek;
		if (_canSeek)
		{
			_length = source.Length;
		}
		_root = this;
		while (_root.Source is BoundedStream)
		{
			_root = (BoundedStream)_root.Source;
		}
	}

	public override void Flush()
	{
		Source.Flush();
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		switch (origin)
		{
		case SeekOrigin.Current:
			Position += offset;
			break;
		case SeekOrigin.Begin:
			Position = offset;
			break;
		case SeekOrigin.End:
			Position = Length + offset;
			break;
		}
		return Position;
	}

	public override void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	public override int Read(byte[] buffer, int offset, int count)
	{
		return (int)ReadImpl(buffer, count).ByteCount;
	}

	public override void Write(byte[] buffer, int offset, int count)
	{
		if (offset != 0)
		{
			throw new ArgumentException("offset");
		}
		WriteImpl(buffer, count);
	}

	public override Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
	{
		if (offset != 0)
		{
			throw new ArgumentException("offset");
		}
		return WriteAsyncImpl(buffer, count, cancellationToken);
	}

	public void Write(byte[] buffer, FieldLength length)
	{
		WriteImpl(buffer, length);
	}

	public Task WriteAsync(byte[] buffer, FieldLength length, CancellationToken cancellationToken)
	{
		return WriteAsyncImpl(buffer, length, cancellationToken);
	}

	private void WriteImpl(byte[] buffer, FieldLength length)
	{
		if (length == FieldLength.Zero)
		{
			return;
		}
		WriteCheck(length);
		if (Source is BoundedStream boundedStream && !IsByteBarrier)
		{
			boundedStream.Write(buffer, length);
		}
		else if (length.BitCount == 0 && _bitOffset == 0)
		{
			WriteByteAligned(buffer, (int)length.ByteCount);
		}
		else
		{
			long num = ((length.BitCount == 0) ? (length.ByteCount - 1) : length.ByteCount);
			int count = ((length.BitCount == 0) ? 8 : length.BitCount);
			WriteBits(buffer[num], count);
			for (long num2 = 0L; num2 < num; num2++)
			{
				WriteBits(buffer[num - (num2 + 1)], 8);
			}
		}
		RelativePosition += length;
	}

	private async Task WriteAsyncImpl(byte[] buffer, FieldLength length, CancellationToken cancellationToken)
	{
		if (length == FieldLength.Zero)
		{
			return;
		}
		WriteCheck(length);
		if (Source is BoundedStream boundedStream && !IsByteBarrier)
		{
			await boundedStream.WriteAsync(buffer, length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		else if (length.BitCount == 0 && _bitOffset == 0)
		{
			await WriteByteAlignedAsync(buffer, (int)length.ByteCount, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		else
		{
			long lastByteIndex = ((length.BitCount == 0) ? (length.ByteCount - 1) : length.ByteCount);
			int count = ((length.BitCount == 0) ? 8 : length.BitCount);
			await WriteBitsAsync(buffer[lastByteIndex], count, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			for (long i = 0L; i < lastByteIndex; i++)
			{
				await WriteBitsAsync(buffer[lastByteIndex - (i + 1)], 8, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			}
		}
		RelativePosition += length;
	}

	protected virtual void WriteByteAligned(byte[] buffer, int length)
	{
		Source.Write(buffer, 0, length);
	}

	protected virtual Task WriteByteAlignedAsync(byte[] buffer, int length, CancellationToken cancellationToken)
	{
		return Source.WriteAsync(buffer, 0, length, cancellationToken);
	}

	private void WriteCheck(FieldLength length)
	{
		if (MaxLength != null && length > MaxLength - Position)
		{
			throw new InvalidOperationException("Unable to write beyond end of stream limit.");
		}
	}

	private void WriteBits(byte value, int count)
	{
		if (count != 0)
		{
			int num = 8 - (count + _bitOffset);
			int num2 = ((num > 0) ? (value << num) : (value >> -num));
			_bitBuffer |= (byte)num2;
			_bitOffset += count;
			if (_bitOffset >= 8)
			{
				byte[] array = new byte[1] { _bitBuffer };
				WriteByteAligned(array, array.Length);
				_bitBuffer = (byte)(value << num + 8);
			}
			_bitOffset %= 8;
		}
	}

	private async Task WriteBitsAsync(byte value, int count, CancellationToken cancellationToken)
	{
		if (count != 0)
		{
			int remaining = 8 - (count + _bitOffset);
			int num = ((remaining > 0) ? (value << remaining) : (value >> -remaining));
			_bitBuffer |= (byte)num;
			_bitOffset += count;
			if (_bitOffset >= 8)
			{
				byte[] array = new byte[1] { _bitBuffer };
				await WriteByteAlignedAsync(array, array.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				_bitBuffer = (byte)(value << remaining + 8);
			}
			_bitOffset %= 8;
		}
	}

	public override async Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
	{
		return (int)(await ReadAsyncImpl(buffer, count, cancellationToken).ConfigureAwait(continueOnCapturedContext: false)).ByteCount;
	}

	public FieldLength Read(byte[] buffer, FieldLength length)
	{
		return ReadImpl(buffer, length);
	}

	public Task<FieldLength> ReadAsync(byte[] buffer, FieldLength length, CancellationToken cancellationToken)
	{
		return ReadAsyncImpl(buffer, length, cancellationToken);
	}

	private FieldLength ReadImpl(byte[] buffer, FieldLength length)
	{
		length = ClampLength(length);
		if (length == FieldLength.Zero)
		{
			return FieldLength.Zero;
		}
		FieldLength fieldLength;
		if (Source is BoundedStream boundedStream && !IsByteBarrier)
		{
			fieldLength = boundedStream.Read(buffer, length);
		}
		else if (length.BitCount == 0 && _bitOffset == 0)
		{
			fieldLength = ReadByteAligned(buffer, (int)length.ByteCount);
		}
		else
		{
			fieldLength = FieldLength.Zero;
			long num = ((length.BitCount == 0) ? (length.ByteCount - 1) : length.ByteCount);
			int count = ((length.BitCount == 0) ? 8 : length.BitCount);
			buffer[num] = ReadBits(count);
			fieldLength += FieldLength.FromBitCount(count);
			for (long num2 = 0L; num2 < num; num2++)
			{
				buffer[num - (num2 + 1)] = ReadBits(8);
				fieldLength += FieldLength.FromBitCount(8);
			}
		}
		RelativePosition += fieldLength;
		return fieldLength;
	}

	private async Task<FieldLength> ReadAsyncImpl(byte[] buffer, FieldLength length, CancellationToken cancellationToken)
	{
		length = ClampLength(length);
		if (length == FieldLength.Zero)
		{
			return FieldLength.Zero;
		}
		FieldLength readLength;
		if (Source is BoundedStream boundedStream && !IsByteBarrier)
		{
			readLength = await boundedStream.ReadAsync(buffer, length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		else if (length.BitCount == 0 && _bitOffset == 0)
		{
			readLength = await ReadByteAlignedAsync(buffer, (int)length.ByteCount, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		else
		{
			readLength = FieldLength.Zero;
			long lastByteIndex = ((length.BitCount == 0) ? (length.ByteCount - 1) : length.ByteCount);
			int bitCount = ((length.BitCount == 0) ? 8 : length.BitCount);
			buffer[lastByteIndex] = await ReadBitsAsync(bitCount, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			readLength += FieldLength.FromBitCount(bitCount);
			for (long i = 0L; i < lastByteIndex; i++)
			{
				byte b = await ReadBitsAsync(8, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				long num = lastByteIndex - (i + 1);
				buffer[num] = b;
				readLength += FieldLength.FromBitCount(8);
			}
		}
		RelativePosition += readLength;
		return readLength;
	}

	protected virtual int ReadByteAligned(byte[] buffer, int length)
	{
		return Source.Read(buffer, 0, length);
	}

	protected virtual Task<int> ReadByteAlignedAsync(byte[] buffer, int length, CancellationToken cancellationToken)
	{
		return Source.ReadAsync(buffer, 0, length, cancellationToken);
	}

	private byte ReadBits(int count)
	{
		if (count == 0)
		{
			return 0;
		}
		byte b = _bitBuffer;
		if (count > _bitOffset)
		{
			byte[] array = new byte[1];
			ReadByteAligned(array, array.Length);
			_bitBuffer = array[0];
			b |= (byte)(_bitBuffer >> _bitOffset);
			_bitBuffer = (byte)(_bitBuffer << count - _bitOffset);
			_bitOffset += 8;
		}
		else
		{
			_bitBuffer = (byte)(_bitBuffer << count);
		}
		b = (byte)(b >> 8 - count);
		_bitOffset -= count;
		return b;
	}

	private async Task<byte> ReadBitsAsync(int count, CancellationToken cancellationToken)
	{
		if (count == 0)
		{
			return 0;
		}
		byte value2 = _bitBuffer;
		if (count > _bitOffset)
		{
			byte[] data = new byte[1];
			await ReadByteAlignedAsync(data, data.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			_bitBuffer = data[0];
			value2 |= (byte)(_bitBuffer >> _bitOffset);
			_bitBuffer = (byte)(_bitBuffer << count - _bitOffset);
			_bitOffset += 8;
		}
		else
		{
			_bitBuffer = (byte)(_bitBuffer << count);
		}
		value2 = (byte)(value2 >> 8 - count);
		_bitOffset -= count;
		return value2;
	}

	private FieldLength ClampLength(FieldLength length)
	{
		if (MaxLength != null && length > MaxLength - Position)
		{
			length = FieldLength.Max(FieldLength.Zero, MaxLength - Position);
		}
		return length;
	}

	public override string ToString()
	{
		return _name;
	}
}
