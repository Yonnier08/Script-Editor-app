using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class FieldEndiannessAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	private readonly Endianness _endianness;

	internal override bool SupportsDeferredBinding => true;

	public FieldEndiannessAttribute(Endianness endianness)
	{
		_endianness = endianness;
		base.BindingMode = BindingMode.OneWay;
	}

	public FieldEndiannessAttribute(string path, Type converterType)
		: base(path)
	{
		base.ConverterType = converterType;
		base.BindingMode = BindingMode.OneWay;
	}

	public object GetConstValue()
	{
		return _endianness;
	}
}
