using System;
using System.Collections.Generic;
using System.Reflection;

namespace BinarySerialization;

internal static class TypeExtensions
{
	internal static readonly Dictionary<Type, Func<object, object>> TypeConverters = new Dictionary<Type, Func<object, object>>
	{
		{
			typeof(char),
			(object o) => Convert.ToChar(o)
		},
		{
			typeof(byte),
			(object o) => Convert.ToByte(o)
		},
		{
			typeof(sbyte),
			(object o) => Convert.ToSByte(o)
		},
		{
			typeof(bool),
			(object o) => Convert.ToBoolean(o)
		},
		{
			typeof(short),
			(object o) => Convert.ToInt16(o)
		},
		{
			typeof(int),
			(object o) => Convert.ToInt32(o)
		},
		{
			typeof(long),
			(object o) => Convert.ToInt64(o)
		},
		{
			typeof(ushort),
			(object o) => Convert.ToUInt16(o)
		},
		{
			typeof(uint),
			(object o) => Convert.ToUInt32(o)
		},
		{
			typeof(ulong),
			(object o) => Convert.ToUInt64(o)
		},
		{
			typeof(float),
			(object o) => Convert.ToSingle(o)
		},
		{
			typeof(double),
			(object o) => Convert.ToDouble(o)
		},
		{
			typeof(string),
			Convert.ToString
		}
	};

	public static object ConvertTo(this object value, Type type)
	{
		if (value == null)
		{
			return null;
		}
		Type type2 = value.GetType();
		if ((object)type2 == type)
		{
			return value;
		}
		if ((object)type2 == typeof(string) && type.GetTypeInfo().IsPrimitive && string.IsNullOrWhiteSpace(value.ToString()))
		{
			value = 0;
		}
		if (TypeConverters.TryGetValue(type, out var value2))
		{
			return value2(value);
		}
		if (type.GetTypeInfo().IsEnum && (type2.GetTypeInfo().IsPrimitive || type2.GetTypeInfo().IsEnum))
		{
			Type underlyingType = Enum.GetUnderlyingType(type);
			if (TypeConverters.TryGetValue(underlyingType, out var value3))
			{
				return Enum.ToObject(type, value3(value));
			}
			return Enum.ToObject(type, (object)Convert.ToUInt64(value));
		}
		return value;
	}

	public static IEnumerable<Type> GetHierarchyGenericArguments(this Type type)
	{
		Type[] genericArguments = System.Reflection.TypeExtensions.GetGenericArguments(type);
		Type[] array = genericArguments;
		for (int i = 0; i < array.Length; i++)
		{
			yield return array[i];
		}
		Type baseType = type.GetTypeInfo().BaseType;
		if ((object)baseType == null)
		{
			yield break;
		}
		IEnumerable<Type> hierarchyGenericArguments = baseType.GetHierarchyGenericArguments();
		foreach (Type item in hierarchyGenericArguments)
		{
			yield return item;
		}
	}
}
