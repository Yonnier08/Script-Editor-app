namespace BinarySerialization;

public sealed class FieldCrc16Attribute : FieldValueAttributeBase
{
	private const ushort DefaultPolynomial = 4129;

	private const ushort DefaultInitialValue = ushort.MaxValue;

	public ushort Polynomial { get; set; } = 4129;


	public ushort InitialValue { get; set; } = ushort.MaxValue;


	public bool IsDataReflected { get; set; }

	public bool IsRemainderReflected { get; set; }

	public ushort FinalXor { get; set; }

	public FieldCrc16Attribute(string crcPath)
		: base(crcPath)
	{
	}

	protected override object GetInitialState(BinarySerializationContext context)
	{
		return new Crc16(Polynomial, InitialValue)
		{
			IsDataReflected = IsDataReflected,
			IsRemainderReflected = IsRemainderReflected,
			FinalXor = FinalXor
		};
	}

	protected override object GetUpdatedState(object state, byte[] buffer, int offset, int count)
	{
		((Crc16)state).Compute(buffer, offset, count);
		return state;
	}

	protected override object GetFinalValue(object state)
	{
		return ((Crc16)state).ComputeFinal();
	}
}
