using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class FieldLengthAttribute : FieldBindingBaseAttribute, ILengthAttribute, IBindableFieldAttribute, IConstAttribute
{
	public ulong ConstLength { get; }

	public FieldLengthAttribute(ulong length)
	{
		ConstLength = length;
	}

	public FieldLengthAttribute(string path)
		: base(path)
	{
	}

	public object GetConstValue()
	{
		return ConstLength;
	}
}
