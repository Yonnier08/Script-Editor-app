using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class FieldOffsetAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	public ulong ConstOffset { get; set; }

	public FieldOffsetAttribute(ulong offset)
	{
		ConstOffset = offset;
	}

	public FieldOffsetAttribute(string path)
		: base(path)
	{
	}

	public object GetConstValue()
	{
		return ConstOffset;
	}
}
