using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class ItemSerializeUntilAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	public string ItemValuePath { get; set; }

	public object ConstValue { get; set; }

	public LastItemMode LastItemMode { get; set; }

	public ItemSerializeUntilAttribute(string itemValuePath, object constValue = null)
	{
		ItemValuePath = itemValuePath;
		ConstValue = constValue;
	}

	public object GetConstValue()
	{
		return ConstValue;
	}
}
