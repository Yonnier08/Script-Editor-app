namespace BinarySerialization;

public enum ChecksumMode
{
	TwosComplement,
	Modulo256,
	Xor
}
