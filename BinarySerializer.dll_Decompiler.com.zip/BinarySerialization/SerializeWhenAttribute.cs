using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class SerializeWhenAttribute : ConditionalAttribute
{
	public SerializeWhenAttribute(string valuePath, object value)
		: base(valuePath, value)
	{
	}
}
