using System.Collections.Generic;

namespace BinarySerialization;

internal abstract class Crc<T>
{
	private static readonly Dictionary<T, T[]> Tables = new Dictionary<T, T[]>();

	private static readonly object TableLock = new object();

	private readonly T _initialValue;

	private readonly T[] _table;

	private T _crc;

	public bool IsDataReflected { get; set; }

	public bool IsRemainderReflected { get; set; }

	public T FinalXor { get; set; }

	protected abstract int Width { get; }

	protected Crc(T polynomial, T initialValue)
	{
		_initialValue = initialValue;
		Reset();
		lock (TableLock)
		{
			if (!Tables.TryGetValue(polynomial, out _table))
			{
				_table = BuildTable(polynomial);
				Tables.Add(polynomial, _table);
			}
		}
	}

	public void Reset()
	{
		_crc = _initialValue;
	}

	public void Compute(byte[] buffer, int offset, int count)
	{
		uint num = ToUInt32(_crc);
		for (int i = offset; i < count; i++)
		{
			byte b = buffer[i];
			if (IsDataReflected)
			{
				b = (byte)Reflect(b, 8);
			}
			byte b2 = (byte)(b ^ (num >> Width - 8));
			num = ToUInt32(_table[b2]) ^ (num << 8);
		}
		_crc = FromUInt32(num);
	}

	public T ComputeFinal()
	{
		T value = _crc;
		if (IsRemainderReflected)
		{
			value = FromUInt32(Reflect(ToUInt32(value), Width));
		}
		return FromUInt32(ToUInt32(value) ^ ToUInt32(FinalXor));
	}

	protected abstract uint ToUInt32(T value);

	protected abstract T FromUInt32(uint value);

	private T[] BuildTable(T polynomial)
	{
		T[] array = new T[256];
		uint num = ToUInt32(polynomial);
		int num2 = Width - 8;
		int num3 = 1 << Width - 1;
		for (uint num4 = 0u; num4 < 256; num4++)
		{
			uint num5 = num4 << num2;
			for (byte b = 8; b > 0; b--)
			{
				num5 = (((num5 & num3) == 0L) ? (num5 << 1) : ((num5 << 1) ^ num));
			}
			array[num4] = FromUInt32(num5);
		}
		return array;
	}

	private static uint Reflect(uint value, int bitCount)
	{
		uint num = 0u;
		for (byte b = 0; b < bitCount; b++)
		{
			if ((value & (true ? 1u : 0u)) != 0)
			{
				num |= (uint)(1 << bitCount - 1 - b);
			}
			value >>= 1;
		}
		return num;
	}
}
