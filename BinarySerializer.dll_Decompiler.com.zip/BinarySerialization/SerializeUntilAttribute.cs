using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public sealed class SerializeUntilAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	public object ConstValue { get; set; }

	public SerializeUntilAttribute(object constValue)
	{
		ConstValue = constValue;
	}

	public object GetConstValue()
	{
		return ConstValue;
	}
}
