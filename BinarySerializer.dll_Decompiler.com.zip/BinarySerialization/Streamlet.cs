using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

public sealed class Streamlet : Stream
{
	private long _length;

	public override bool CanRead => Source.CanRead;

	public override bool CanSeek => Source.CanSeek;

	public override bool CanWrite => false;

	public override long Length => _length;

	public Stream Source { get; }

	public override long Position { get; set; }

	public long Offset { get; set; }

	public Streamlet(Stream source, long offset, long length)
	{
		if (source == null)
		{
			throw new ArgumentNullException("source");
		}
		if (offset < 0)
		{
			throw new ArgumentOutOfRangeException("offset", "The offset cannot be negative");
		}
		if (length < 0)
		{
			throw new ArgumentOutOfRangeException("length", "The length cannot be negative");
		}
		if (offset + length > source.Length)
		{
			throw new ArgumentOutOfRangeException("length", "The length cannot exceed the source stream");
		}
		if (!source.CanSeek)
		{
			throw new ArgumentException("The source stream must support seeking", "source");
		}
		Source = source;
		Offset = offset;
		_length = length;
	}

	public Streamlet(Stream source, long offset)
		: this(source, offset, source.Length - offset)
	{
	}

	public Streamlet(Stream source)
		: this(source, source.Position)
	{
	}

	public override void Flush()
	{
	}

	public override int Read(byte[] buffer, int offset, int count)
	{
		count = ClampCount(count);
		if (count == 0)
		{
			return 0;
		}
		Source.Position = Offset + Position;
		int num = Source.Read(buffer, offset, count);
		Position += num;
		return num;
	}

	public override async Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
	{
		count = ClampCount(count);
		if (count == 0)
		{
			return 0;
		}
		Source.Position = Offset + Position;
		int num = await Source.ReadAsync(buffer, offset, count, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		Position += num;
		return num;
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		switch (origin)
		{
		case SeekOrigin.Current:
			Position += offset;
			break;
		case SeekOrigin.Begin:
			Position = offset;
			break;
		case SeekOrigin.End:
			Position = Length + offset;
			break;
		}
		return Position;
	}

	public override void SetLength(long value)
	{
		_length = value;
	}

	public override void Write(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	protected override void Dispose(bool disposing)
	{
		base.Dispose(disposing);
		Source.Dispose();
	}

	private int ClampCount(int count)
	{
		if (count > Length - Position)
		{
			count = Math.Max(0, (int)(Length - Position));
		}
		return count;
	}
}
