using System;
using System.Reflection;

namespace BinarySerialization;

internal class LazyBinarySerializationContext : BinarySerializationContext
{
	private readonly Lazy<BinarySerializationContext> _lazyContext;

	public override object Value => _lazyContext.Value.Value;

	public override Type ParentType => _lazyContext.Value.ParentType;

	public override object ParentValue => _lazyContext.Value.ParentValue;

	public override BinarySerializationContext ParentContext => _lazyContext.Value.ParentContext;

	public override MemberInfo MemberInfo => _lazyContext.Value.MemberInfo;

	[Obsolete("Use ParentValue")]
	public override object Parent => _lazyContext.Value.Parent;

	public LazyBinarySerializationContext(Lazy<BinarySerializationContext> lazyContext)
	{
		_lazyContext = lazyContext;
	}
}
