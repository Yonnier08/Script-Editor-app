using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class SubtypeFactoryAttribute : SubtypeFactoryBaseAttribute
{
	public SubtypeFactoryAttribute(string path, Type factoryType)
		: base(path, factoryType)
	{
	}
}
