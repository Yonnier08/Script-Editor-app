using System;

namespace BinarySerialization;

public enum SerializedType
{
	Default,
	Int1,
	UInt1,
	Int2,
	UInt2,
	Int4,
	UInt4,
	Int8,
	UInt8,
	Float4,
	Float8,
	ByteArray,
	SizedString,
	[Obsolete("Use TerminatedString")]
	NullTerminatedString,
	TerminatedString,
	LengthPrefixedString
}
