using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Field)]
public sealed class SerializeAsEnumAttribute : Attribute
{
	public string Value { get; set; }

	public SerializeAsEnumAttribute()
	{
	}

	public SerializeAsEnumAttribute(string value)
	{
		Value = value;
	}
}
