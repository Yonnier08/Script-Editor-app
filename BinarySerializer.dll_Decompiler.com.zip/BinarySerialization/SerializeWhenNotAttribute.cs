using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class SerializeWhenNotAttribute : ConditionalAttribute
{
	public SerializeWhenNotAttribute(string valuePath, object value)
		: base(valuePath, value)
	{
	}
}
