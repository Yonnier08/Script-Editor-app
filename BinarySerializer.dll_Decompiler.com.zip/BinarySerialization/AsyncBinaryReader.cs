using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BinarySerialization;

public class AsyncBinaryReader : BinaryReader
{
	public BoundedStream InputStream { get; }

	public AsyncBinaryReader(BoundedStream input, Encoding encoding)
		: base(input, encoding)
	{
		InputStream = input;
	}

	public override byte ReadByte()
	{
		byte[] array = new byte[1];
		Read(array, array.Length);
		return array[0];
	}

	public async Task<byte> ReadByteAsync(CancellationToken cancellationToken)
	{
		byte[] b = new byte[1];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return b[0];
	}

	public override sbyte ReadSByte()
	{
		byte[] array = new byte[1];
		Read(array, array.Length);
		return (sbyte)array[0];
	}

	public async Task<sbyte> ReadSByteAsync(CancellationToken cancellationToken)
	{
		byte[] b = new byte[1];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return (sbyte)b[0];
	}

	public override ushort ReadUInt16()
	{
		byte[] array = new byte[2];
		Read(array, array.Length);
		return BitConverter.ToUInt16(array, 0);
	}

	public async Task<ushort> ReadUInt16Async(CancellationToken cancellationToken)
	{
		byte[] b = new byte[2];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToUInt16(b, 0);
	}

	public override short ReadInt16()
	{
		byte[] array = new byte[2];
		Read(array, array.Length);
		return BitConverter.ToInt16(array, 0);
	}

	public async Task<short> ReadInt16Async(CancellationToken cancellationToken)
	{
		byte[] b = new byte[2];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToInt16(b, 0);
	}

	public override uint ReadUInt32()
	{
		byte[] array = new byte[4];
		Read(array, array.Length);
		return BitConverter.ToUInt32(array, 0);
	}

	public async Task<uint> ReadUInt32Async(CancellationToken cancellationToken)
	{
		byte[] b = new byte[4];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToUInt32(b, 0);
	}

	public override int ReadInt32()
	{
		byte[] array = new byte[4];
		Read(array, array.Length);
		return BitConverter.ToInt32(array, 0);
	}

	public async Task<int> ReadInt32Async(CancellationToken cancellationToken)
	{
		byte[] b = new byte[4];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToInt32(b, 0);
	}

	public override ulong ReadUInt64()
	{
		byte[] array = new byte[8];
		Read(array, array.Length);
		return BitConverter.ToUInt64(array, 0);
	}

	public async Task<ulong> ReadUInt64Async(CancellationToken cancellationToken)
	{
		byte[] b = new byte[8];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToUInt64(b, 0);
	}

	public override long ReadInt64()
	{
		byte[] array = new byte[8];
		Read(array, array.Length);
		return BitConverter.ToInt64(array, 0);
	}

	public async Task<long> ReadInt64Async(CancellationToken cancellationToken)
	{
		byte[] b = new byte[8];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToInt64(b, 0);
	}

	public override float ReadSingle()
	{
		byte[] array = new byte[4];
		Read(array, array.Length);
		return BitConverter.ToSingle(array, 0);
	}

	public async Task<float> ReadSingleAsync(CancellationToken cancellationToken)
	{
		byte[] b = new byte[4];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToSingle(b, 0);
	}

	public override double ReadDouble()
	{
		byte[] array = new byte[8];
		Read(array, array.Length);
		return BitConverter.ToDouble(array, 0);
	}

	public async Task<double> ReadDoubleAsync(CancellationToken cancellationToken)
	{
		byte[] b = new byte[8];
		await ReadAsync(b, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return BitConverter.ToDouble(b, 0);
	}

	public FieldLength Read(byte[] data, FieldLength fieldLength)
	{
		FieldLength length = fieldLength ?? ((FieldLength)data.Length);
		return InputStream.Read(data, length);
	}

	public Task<FieldLength> ReadAsync(byte[] data, FieldLength fieldLength, CancellationToken cancellationToken)
	{
		FieldLength length = fieldLength ?? ((FieldLength)data.Length);
		return InputStream.ReadAsync(data, length, cancellationToken);
	}

	public async Task<byte[]> ReadBytesAsync(int count, CancellationToken cancellationToken)
	{
		byte[] b = new byte[count];
		await BaseStream.ReadAsync(b, 0, b.Length, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		return b;
	}
}
