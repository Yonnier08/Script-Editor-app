using System;

namespace BinarySerialization;

public abstract class FieldBindingBaseAttribute : Attribute, IBindableFieldAttribute
{
	internal BindingInfo Binding { get; set; }

	internal virtual bool SupportsDeferredBinding => false;

	public string Path
	{
		get
		{
			return Binding.Path;
		}
		set
		{
			Binding.Path = value;
		}
	}

	public BindingMode BindingMode
	{
		get
		{
			return Binding.BindingMode;
		}
		set
		{
			Binding.BindingMode = value;
		}
	}

	public int AncestorLevel
	{
		get
		{
			return Binding.AncestorLevel;
		}
		set
		{
			Binding.AncestorLevel = value;
		}
	}

	public Type AncestorType
	{
		get
		{
			return Binding.AncestorType;
		}
		set
		{
			Binding.AncestorType = value;
		}
	}

	public RelativeSourceMode RelativeSourceMode
	{
		get
		{
			return Binding.RelativeSourceMode;
		}
		set
		{
			Binding.RelativeSourceMode = value;
		}
	}

	public Type ConverterType
	{
		get
		{
			return Binding.ConverterType;
		}
		set
		{
			Binding.ConverterType = value;
		}
	}

	public object ConverterParameter
	{
		get
		{
			return Binding.ConverterParameter;
		}
		set
		{
			Binding.ConverterParameter = value;
		}
	}

	protected FieldBindingBaseAttribute()
	{
		Binding = new BindingInfo();
	}

	protected FieldBindingBaseAttribute(string path)
	{
		Binding = new BindingInfo(path);
	}
}
