using System;

namespace BinarySerialization;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true)]
public sealed class FieldAlignmentAttribute : FieldBindingBaseAttribute, IConstAttribute, IBindableFieldAttribute
{
	private readonly int _alignment;

	internal FieldAlignmentMode Mode { get; }

	public FieldAlignmentAttribute(int alignment, FieldAlignmentMode mode = FieldAlignmentMode.LeftAndRight)
	{
		_alignment = alignment;
		Mode = mode;
	}

	public FieldAlignmentAttribute(string path, FieldAlignmentMode mode = FieldAlignmentMode.LeftAndRight)
		: base(path)
	{
		Mode = mode;
	}

	public object GetConstValue()
	{
		return _alignment;
	}
}
