namespace BinarySerialization;

public enum Endianness
{
	Inherit,
	Little,
	Big
}
