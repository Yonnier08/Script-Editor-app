using System;
using System.Reflection;

namespace BinarySerialization;

public class BinarySerializationContext
{
	public virtual object Value { get; }

	public virtual object ParentValue { get; }

	public virtual Type ParentType { get; }

	public virtual BinarySerializationContext ParentContext { get; }

	public virtual MemberInfo MemberInfo { get; }

	public int Depth
	{
		get
		{
			if (ParentContext == null)
			{
				return 0;
			}
			return ParentContext.Depth + 1;
		}
	}

	[Obsolete("Use ParentValue")]
	public virtual object Parent { get; }

	internal BinarySerializationContext()
	{
	}

	internal BinarySerializationContext(object value, object parentValue, Type parentType, BinarySerializationContext parentContext, MemberInfo memberInfo)
	{
		Value = value;
		ParentValue = parentValue;
		ParentType = parentType;
		ParentContext = parentContext;
		MemberInfo = memberInfo;
		Parent = parentValue;
	}

	public T FindAncestor<T>() where T : class
	{
		object parentValue = ParentValue;
		Type parentType = ParentType;
		BinarySerializationContext parentContext = ParentContext;
		while ((object)parentType != typeof(T))
		{
			if (parentContext == null)
			{
				return null;
			}
			parentValue = parentContext.ParentValue;
			parentType = parentContext.ParentType;
			parentContext = parentContext.ParentContext;
		}
		return (T)parentValue;
	}
}
