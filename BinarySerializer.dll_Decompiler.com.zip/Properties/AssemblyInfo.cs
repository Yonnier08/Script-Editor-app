using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: InternalsVisibleTo("BinarySerializer.Test")]
[assembly: AssemblyCompany("Jeff Haynes")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("A declarative serialization framework for controlling formatting of data using field bindings.")]
[assembly: AssemblyFileVersion("8.1.2.0")]
[assembly: AssemblyInformationalVersion("8.1.2")]
[assembly: AssemblyProduct("BinarySerializer")]
[assembly: AssemblyTitle("BinarySerializer")]
[assembly: AssemblyVersion("8.1.2.0")]
