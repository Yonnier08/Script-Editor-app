using System;
using System.Collections.Generic;
using System.Linq;
using DivaScript;
using EditMode.DivaExtend;

namespace ScriptUtilities;

public class DivaExtendEditScript
{
	private const int DEFAULT_TARGET_DISTANCE = 300000;

	private const int DEFAULT_TARGET_AMPLITUDE = 500;

	private const int DEFAULT_TARGET_FREQUENCY = 2;

	private const int DIVA_TIME_FACTOR = 100;

	public static (List<PvCommand> commands, PvDatabaseInfo pvDatabase) GetFtEditCommands(Edit edit, int pvId = 0)
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Expected O, but got Unknown
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Expected O, but got Unknown
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Expected O, but got Unknown
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Invalid comparison between Unknown and I4
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Expected I4, but got Unknown
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Expected O, but got Unknown
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Invalid comparison between Unknown and I4
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_0539: Invalid comparison between Unknown and I4
		//IL_04c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Invalid comparison between Unknown and I4
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Expected O, but got Unknown
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_053e: Invalid comparison between Unknown and I4
		//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ec: Invalid comparison between Unknown and I4
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0512: Invalid comparison between Unknown and I4
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Invalid comparison between Unknown and I4
		//IL_0570: Unknown result type (might be due to invalid IL or missing references)
		//IL_057a: Expected O, but got Unknown
		//IL_0582: Unknown result type (might be due to invalid IL or missing references)
		//IL_0585: Invalid comparison between Unknown and I4
		//IL_059b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a5: Expected O, but got Unknown
		PvDatabaseInfo item = new PvDatabaseInfo(edit, pvId);
		int num = (int)(edit.StartTimeSpan.TotalMilliseconds * -100.0);
		int num2 = (int)(edit.GetTimeAt(edit.SongEndBeat).TotalMilliseconds * 100.0);
		List<PvCommand> list = new List<PvCommand>
		{
			new PvCommand(num, "MUSIC_PLAY", Array.Empty<int>()),
			new PvCommand(num2, "PV_END", Array.Empty<int>()),
			new PvCommand(num2, "END", Array.Empty<int>())
		};
		HashSet<(int, int)> hashSet = new HashSet<(int, int)>();
		int num3 = 0;
		TimeSpan timeSpan = TimeSpan.Zero;
		int num4 = 0;
		foreach (EditPvCommand pvCommand in edit.PvCommands)
		{
			Opcode opcode = pvCommand.Opcode;
			string text = ((object)(Opcode)(ref opcode)).ToString();
			List<int> list2 = new List<int>(pvCommand.Parameters);
			Opcode val = opcode;
			Opcode val2 = val;
			if ((int)val2 != 1)
			{
				switch (val2 - 31)
				{
				default:
					if ((int)val2 == 42 && list2[0] != -1)
					{
						List<int> list3 = list2;
						int value = list3[0] + 1;
						list3[0] = value;
					}
					break;
				case 0:
				{
					int num11 = (int)edit.GetTimeFrom(num4, list2[0]) - (int)edit.increment2;
					if (num11 < 0)
					{
						num11 = 0;
					}
					list2 = new List<int> { num11 };
					for (int j = 2; j < pvCommand.Parameters.Count; j++)
					{
						list2.Add(pvCommand.Parameters[j]);
					}
					break;
				}
				case 3:
				{
					text = "LYRIC";
					int item5 = pvCommand.Parameters[0];
					int num9 = pvCommand.Parameters[1];
					list2 = new List<int> { item5, -1 };
					int num10 = (int)(edit.GetTimeAt(num4 + num9).TotalMilliseconds * 100.0);
					list.Add(new PvCommand(num10, text, new int[2] { -1, -1 }));
					break;
				}
				case 4:
				{
					text = "TARGET";
					int num6 = pvCommand.Parameters[0];
					int item2 = pvCommand.Parameters[1];
					int item3 = pvCommand.Parameters[2];
					int item4 = pvCommand.Parameters[3];
					int num7 = pvCommand.Parameters[4];
					switch (num6)
					{
					case 0:
					case 4:
						num6 = 0;
						break;
					case 1:
					case 5:
						num6 = 1;
						break;
					case 2:
					case 6:
						num6 = 2;
						break;
					case 3:
					case 7:
						num6 = 3;
						break;
					case 8:
						num6 = 4;
						break;
					case 9:
						num6 = 5;
						break;
					case 10:
						num6 = 6;
						break;
					case 11:
						num6 = 7;
						break;
					}
					TimeSpan timeAt = edit.GetTimeAt(num4 + 8);
					timeSpan = edit.GetTimeAt(num4);
					TimeSpan timeSpan2 = timeSpan;
					TimeSpan timeSpan3 = timeAt - timeSpan2;
					int num8 = (int)(timeSpan.TotalMilliseconds * 100.0 + (double)num3);
					list.Add(new PvCommand(num8, "TARGET_FLYING_TIME", new int[1] { (int)timeSpan3.TotalMilliseconds }));
					list2 = new List<int> { num6, item2, item3, item4, 300000, 500, 2 };
					break;
				}
				case 6:
					num3 = list2[0];
					break;
				case 7:
				{
					foreach (int item6 in list2)
					{
					}
					int num5 = (int)edit.GetTimeFrom(num4, list2[0]) - (int)edit.increment2;
					if (num5 < 0)
					{
						num5 = 0;
					}
					list2 = new List<int> { num5 };
					for (int i = 2; i < pvCommand.Parameters.Count; i++)
					{
						list2.Add(pvCommand.Parameters[i]);
					}
					break;
				}
				case 1:
				case 2:
				case 5:
					break;
				}
			}
			else
			{
				num4 = list2[0];
				timeSpan = edit.GetTimeAt(num4);
				list2[0] = (int)(timeSpan.TotalMilliseconds * 100.0 + (double)num3);
			}
			if (list2 != null && list2.Count > 0)
			{
				if ((int)opcode == 30)
				{
					list2[0] = MapExpressionIdToPsp(list2[0]);
				}
				else if ((int)opcode == 36)
				{
					list2[0] = MapMouthIdToPsp(list2[0]);
				}
				else if ((int)opcode != 41)
				{
				}
			}
			int num12 = (int)(timeSpan.TotalMilliseconds * 100.0 + (double)num3);
			if ((int)opcode != 37 && (int)opcode != 1 && hashSet.Add((num12, num3)))
			{
				list.Add(new PvCommand(num12, "SET_CHARA", new List<int> { num3 }));
			}
			if ((int)opcode != 37 && (int)opcode != 1)
			{
				list.Add(new PvCommand(num12, text, list2));
			}
		}
		return (commands: PvScript.OrderListByTime(PvScript.AddTimeCommands(list.Where((PvCommand t) => t.Opcode != "TIME").ToList())), pvDatabase: item);
	}

	private static int MapExpressionIdToPsp(int editId)
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>
		{
			{ 0, 52 },
			{ 1, 66 },
			{ 2, 65 },
			{ 3, 53 },
			{ 5, 68 },
			{ 6, 54 },
			{ 7, 70 },
			{ 8, 55 },
			{ 9, 56 },
			{ 10, 57 },
			{ 11, 58 },
			{ 12, 59 },
			{ 13, 60 },
			{ 15, 61 },
			{ 16, 71 },
			{ 17, 62 },
			{ 18, 63 },
			{ 19, 69 },
			{ 20, 67 },
			{ 21, 72 },
			{ 34, 34 },
			{ 35, 35 },
			{ 36, 36 },
			{ 37, 37 },
			{ 38, 38 },
			{ 39, 39 },
			{ 40, 40 },
			{ 41, 41 },
			{ 42, 51 },
			{ 43, 43 },
			{ 44, 44 },
			{ 45, 45 },
			{ 46, 46 },
			{ 47, 47 },
			{ 48, 48 },
			{ 49, 49 },
			{ 50, 50 },
			{ 51, 74 },
			{ 52, 74 },
			{ 53, 75 },
			{ 54, 75 },
			{ 55, 76 },
			{ 56, 77 },
			{ 57, 77 },
			{ 58, 65 }
		};
		return dictionary.ContainsKey(editId) ? dictionary[editId] : editId;
	}

	private static int MapMouthIdToPsp(int editId)
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>
		{
			{ 0, 24 },
			{ 1, 31 },
			{ 2, 25 },
			{ 3, 26 },
			{ 4, 27 },
			{ 5, 32 },
			{ 6, 23 },
			{ 7, 33 },
			{ 8, 9 },
			{ 10, 10 },
			{ 11, 11 },
			{ 12, 12 },
			{ 13, 13 },
			{ 14, 14 },
			{ 15, 15 },
			{ 16, 16 },
			{ 17, 17 },
			{ 18, 18 },
			{ 19, 25 },
			{ 20, 21 },
			{ 25, 37 },
			{ 26, 38 },
			{ 28, 40 },
			{ 29, 41 },
			{ 30, 42 },
			{ 34, 19 },
			{ 35, 20 }
		};
		return dictionary.ContainsKey(editId) ? dictionary[editId] : editId;
	}
}
