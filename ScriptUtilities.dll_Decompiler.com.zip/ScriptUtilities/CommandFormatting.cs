using System.Collections.Generic;
using System.Linq;
using DivaScript;

namespace ScriptUtilities;

public static class CommandFormatting
{
	private class FtTargetStruct
	{
		public PvCommand OriginalCommand = null;

		public bool ChainStart = false;

		public bool ChainEnd = false;

		public int TimeStamp = -1;

		public int FlyDuration = -1;

		public FtTargetType TargetType;

		public FtTargetStruct(PvCommand command, int flyDuration)
		{
			OriginalCommand = command;
			TimeStamp = command.TimeStamp;
			FlyDuration = flyDuration;
			TargetType = (FtTargetType)command.Parameters.FirstOrDefault();
		}
	}

	public static List<PvCommand> AddTargetFlyingTimeCommands(List<PvCommand> commands)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Expected O, but got Unknown
		for (int i = 0; i < commands.Count; i++)
		{
			PvCommand val = commands[i];
			if (val.Opcode.ToUpper() == "TARGET" && val.Parameters.Count > 9)
			{
				int num = val.Parameters[9];
				if (num > 0)
				{
					commands.Insert(i, new PvCommand(val.TimeStamp, "TARGET_FLYING_TIME", new List<int> { num }));
					i++;
				}
			}
		}
		return commands;
	}

	public static List<PvCommand> ReformatFTargetList(List<PvCommand> pvCommands)
	{
		pvCommands.Where((PvCommand c) => c.Opcode.ToUpper() == "TARGET").ToList().ForEach(delegate(PvCommand c)
		{
			c = FtoFtTarget(c);
		});
		return pvCommands;
	}

	public static List<PvCommand> ReformatFtTargetList(List<PvCommand> pvCommands)
	{
		pvCommands.Where((PvCommand c) => c.Opcode.ToUpper() == "TARGET").ToList().ForEach(delegate(PvCommand c)
		{
			c = FtToFTarget(c);
		});
		return pvCommands;
	}

	public static PvCommand FtoFtTarget(PvCommand fTargetCommand)
	{
		if (fTargetCommand.Parameters.Count < 9)
		{
			return fTargetCommand;
		}
		List<int> parameters = fTargetCommand.Parameters;
		int item = parameters[0];
		int item2 = parameters[3];
		int item3 = parameters[4];
		int item4 = parameters[5];
		int item5 = parameters[7];
		int item6 = parameters[8];
		int item7 = parameters[6];
		List<int> parameters2 = new List<int> { item, item2, item3, item4, item5, item6, item7 };
		fTargetCommand.Parameters = parameters2;
		return fTargetCommand;
	}

	public static PvCommand FtToFTarget(PvCommand ftTargetCommand)
	{
		if (ftTargetCommand.Parameters.Count < 7)
		{
			return ftTargetCommand;
		}
		List<int> parameters = ftTargetCommand.Parameters;
		int item = parameters[0];
		int item2 = -1;
		int item3 = -1;
		int item4 = parameters[1];
		int item5 = parameters[2];
		int item6 = parameters[3];
		int item7 = parameters[6];
		int item8 = parameters[4];
		int item9 = parameters[5];
		int item10 = 0;
		int item11 = 3;
		int item12 = -1;
		List<int> parameters2 = new List<int>
		{
			item, item2, item3, item4, item5, item6, item7, item8, item9, item10,
			item11, item12
		};
		ftTargetCommand.Parameters = parameters2;
		return ftTargetCommand;
	}

	public static List<PvCommand> AdjustTargetTypes(List<PvCommand> commands, params (int inputType, int outputType)[] formats)
	{
		IEnumerable<PvCommand> enumerable = commands.Where((PvCommand c) => c.Opcode.ToUpper() == "TARGET");
		foreach (PvCommand item in enumerable)
		{
			if (item.Parameters.Count >= 1)
			{
				for (int i = 0; i < formats.Length; i++)
				{
					var (inputType, outputType) = formats[i];
					AdjustTargetType(item, inputType, outputType);
				}
			}
		}
		return commands;
	}

	public static PvCommand AdjustTargetType(PvCommand command, int inputType, int outputType)
	{
		if (command.Parameters[0] == inputType)
		{
			command.Parameters[0] = outputType;
		}
		return command;
	}

	public static List<PvCommand> SmartReformatFtoFt(List<PvCommand> pvCommands)
	{
		pvCommands = AddTargetFlyingTimeCommands(pvCommands);
		foreach (PvCommand item in pvCommands.ToList())
		{
			if (item.Opcode.ToUpper() == "TARGET")
			{
				if (item.Parameters[2] > -1)
				{
					pvCommands.Remove(item);
				}
				else
				{
					FtoFtTarget(item);
				}
			}
		}
		AdjustTargetTypes(pvCommands, (4, 0), (5, 1), (6, 2), (7, 3), (8, 4), (9, 5), (10, 6), (11, 7), (12, 13), (22, 12), (23, 13), (14, 13), (16, 23), (15, 24), (25, 4), (26, 5), (27, 6), (28, 7), (17, 5));
		return pvCommands;
	}

	public static List<PvCommand> SmartReformatFtToF(List<PvCommand> pvCommands, bool touchHold = false)
	{
		List<PvCommand> list = new List<PvCommand>(pvCommands);
		List<FtTargetStruct> list2 = new List<FtTargetStruct>();
		List<FtTargetStruct> list3 = new List<FtTargetStruct>();
		int flyDuration = 0;
		for (int i = 0; i < list.Count; i++)
		{
			PvCommand val = list[i];
			if (val.Opcode == "TARGET_FLYING_TIME")
			{
				flyDuration = val.Parameters.FirstOrDefault();
			}
			else if (val.Opcode == "TARGET")
			{
				FtTargetStruct ftTargetStruct = new FtTargetStruct(val, flyDuration);
				if (ftTargetStruct.TargetType == FtTargetType.slide_chain_l)
				{
					list2.Add(ftTargetStruct);
				}
				else if (ftTargetStruct.TargetType == FtTargetType.slide_chain_r)
				{
					list3.Add(ftTargetStruct);
				}
			}
		}
		UpdateChainList(list2);
		UpdateChainList(list3);
		int num = 0;
		foreach (PvCommand command in pvCommands.ToList())
		{
			if (command.Opcode.ToUpper() == "TARGET_FLYING_TIME")
			{
				num = command.Opcode.FirstOrDefault();
			}
			if (command.Opcode.ToUpper() == "TARGET")
			{
				FtToFTarget(command);
				bool flag = pvCommands.Exists((PvCommand t) => t.TimeStamp == command.TimeStamp && t.Opcode == command.Opcode && t != command);
				switch ((FtTargetType)command.Parameters[0])
				{
				case FtTargetType.sankaku:
					command.Parameters[0] = 0;
					break;
				case FtTargetType.maru:
					command.Parameters[0] = 1;
					break;
				case FtTargetType.batsu:
					command.Parameters[0] = 2;
					break;
				case FtTargetType.shikaku:
					command.Parameters[0] = 3;
					break;
				case FtTargetType.sankaku_hold:
					command.Parameters[0] = ((!flag) ? 4 : 0);
					break;
				case FtTargetType.maru_hold:
					command.Parameters[0] = (flag ? 1 : 5);
					break;
				case FtTargetType.batsu_hold:
					command.Parameters[0] = (flag ? 2 : 6);
					break;
				case FtTargetType.shikaku_hold:
					command.Parameters[0] = (flag ? 3 : 7);
					break;
				case FtTargetType.slide_l:
				case FtTargetType.slide_r:
					command.Parameters[0] = 12;
					break;
				case FtTargetType.slide_chain_l:
				case FtTargetType.slide_chain_r:
					pvCommands.Remove(command);
					break;
				case FtTargetType.sankaku_ch:
				case FtTargetType.maru_ch:
				case FtTargetType.batsu_ch:
				case FtTargetType.shikaku_ch:
					command.Parameters[0] = 15;
					break;
				case FtTargetType.slide_l_ch:
				case FtTargetType.slide_r_ch:
					command.Parameters[0] = 15;
					break;
				}
			}
		}
		ChainFragmentListToLongTargets(list2);
		ChainFragmentListToLongTargets(list3);
		pvCommands = pvCommands.Where((PvCommand c) => c.Opcode.ToUpper() != "TIME").ToList();
		pvCommands = PvScript.OrderListByTime(PvScript.AddTimeCommands(pvCommands));
		return pvCommands;
		void ChainFragmentListToLongTargets(List<FtTargetStruct> targets)
		{
			//IL_0117: Unknown result type (might be due to invalid IL or missing references)
			//IL_0121: Expected O, but got Unknown
			//IL_0152: Unknown result type (might be due to invalid IL or missing references)
			//IL_015c: Expected O, but got Unknown
			//IL_0204: Unknown result type (might be due to invalid IL or missing references)
			//IL_020e: Expected O, but got Unknown
			foreach (FtTargetStruct item in targets.ToList())
			{
				if (item.ChainStart)
				{
					PvCommand originalCommand = item.OriginalCommand;
					bool flag2 = item.TargetType == FtTargetType.slide_chain_l;
					originalCommand.Parameters[0] = (flag2 ? 11 : 9);
					if (touchHold)
					{
						originalCommand.Parameters[0] = 13;
					}
					int num2 = 0;
					int num3 = 0;
					foreach (FtTargetStruct item2 in targets.ToList())
					{
						bool flag3 = false;
						if (item2.ChainEnd)
						{
							num2 = num3 - item.TimeStamp;
							flag3 = true;
						}
						num3 = item2.TimeStamp;
						targets.Remove(item2);
						if (flag3)
						{
							break;
						}
					}
					originalCommand.Parameters[1] = num2;
					pvCommands.Add(new PvCommand(originalCommand.TimeStamp, "TIME", new int[1] { originalCommand.TimeStamp }));
					pvCommands.Add(originalCommand);
					int num4 = originalCommand.TimeStamp + num2;
					pvCommands.Add(new PvCommand(num4, "TIME", new int[1] { num4 }));
					pvCommands.Add(new PvCommand(num4, "TARGET", new int[11]
					{
						originalCommand.Parameters[0],
						-1,
						1,
						originalCommand.Parameters[3],
						originalCommand.Parameters[4],
						originalCommand.Parameters[5],
						originalCommand.Parameters[6],
						originalCommand.Parameters[7],
						originalCommand.Parameters[8],
						originalCommand.Parameters[9],
						originalCommand.Parameters[10]
					}));
				}
			}
		}
		static void UpdateChainList(List<FtTargetStruct> targets)
		{
			List<(float, FtTargetStruct)> list4 = new List<(float, FtTargetStruct)>();
			float num5 = 0f;
			for (int j = 0; j < targets.Count - 1; j++)
			{
				FtTargetStruct ftTargetStruct2 = ((j > 0) ? targets[j - 1] : null);
				FtTargetStruct ftTargetStruct3 = targets[j];
				FtTargetStruct ftTargetStruct4 = ((targets.Count + 1 > j) ? targets[j + 1] : null);
				float num6 = (float)ftTargetStruct3.FlyDuration / (float)(ftTargetStruct4.TimeStamp - ftTargetStruct3.TimeStamp);
				bool flag4 = true;
				list4.Add((num6, ftTargetStruct3));
				if (ftTargetStruct2 == null)
				{
					ftTargetStruct3.ChainStart = true;
				}
				else if (ftTargetStruct4.ChainStart = num6 > num5 && !Helper.IsInRange(num6 - num5, 0.2f))
				{
					ftTargetStruct3.ChainEnd = true;
				}
				num5 = num6;
			}
			if (targets.Count > 1 && !targets[targets.Count - 1].ChainEnd)
			{
				targets[targets.Count - 1].ChainEnd = true;
			}
		}
	}
}
