namespace ScriptUtilities;

public enum PSPLineOfSight : uint
{
	上 = 0u,
	下 = 1u,
	右 = 2u,
	左 = 3u,
	右上 = 4u,
	左上 = 5u,
	右下 = 6u,
	左下 = 7u,
	カメラ目線 = 8u,
	上寄り = 11u,
	下寄り = 12u,
	右寄り = 13u,
	左寄り = 14u,
	右上寄り = 15u,
	左上寄り = 16u,
	右下寄り = 17u,
	左下寄り = 18u,
	前髪 = 0u,
	鼻先 = 1u,
	通常 = 9u
}
