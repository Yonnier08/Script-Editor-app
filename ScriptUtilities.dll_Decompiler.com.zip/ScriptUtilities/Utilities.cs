namespace ScriptUtilities;

public static class Utilities
{
}
