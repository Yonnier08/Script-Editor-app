namespace ScriptUtilities;

public struct TimelineIndex
{
	public const int BEATS_PER_BAR = 192;

	public const int BEATS_PER_QUARTER = 48;

	public int Bar;

	public int Beat;

	public static TimelineIndex Zero => new TimelineIndex(0, 0);

	public static TimelineIndex One => new TimelineIndex(1, 0);

	public static TimelineIndex Two => new TimelineIndex(2, 0);

	public int TotalBeats => GetTotalBeats(this);

	public TimelineIndex(int bar)
	{
		Bar = bar;
		Beat = 0;
	}

	public TimelineIndex(int bar, int beat)
	{
		Bar = bar;
		Beat = beat;
	}

	public TimelineIndex(uint bar, uint beat)
	{
		Bar = (int)bar;
		Beat = (int)beat;
	}

	public static int GetTotalBeats(TimelineIndex index)
	{
		return index.Bar * 192 + index.Beat;
	}

	public static TimelineIndex FromBeats(int totalBeat)
	{
		return new TimelineIndex(totalBeat / 192, totalBeat % 192);
	}

	public static bool operator >(TimelineIndex i0, TimelineIndex i1)
	{
		return i0.TotalBeats > i1.TotalBeats;
	}

	public static bool operator <(TimelineIndex i0, TimelineIndex i1)
	{
		return i0.TotalBeats < i1.TotalBeats;
	}

	public static bool operator >=(TimelineIndex i0, TimelineIndex i1)
	{
		return i0.TotalBeats >= i1.TotalBeats;
	}

	public static bool operator <=(TimelineIndex i0, TimelineIndex i1)
	{
		return i0.TotalBeats <= i1.TotalBeats;
	}

	public static TimelineIndex operator +(TimelineIndex i0, TimelineIndex i1)
	{
		return FromBeats(i0.TotalBeats + i1.TotalBeats);
	}

	public static TimelineIndex operator -(TimelineIndex i0, TimelineIndex i1)
	{
		return FromBeats(i0.TotalBeats - i1.TotalBeats);
	}

	public static bool operator ==(TimelineIndex obj0, TimelineIndex obj1)
	{
		return obj0.TotalBeats == obj1.TotalBeats;
	}

	public static bool operator !=(TimelineIndex obj0, TimelineIndex obj1)
	{
		return !(obj0 == obj1);
	}

	public override bool Equals(object obj)
	{
		return base.Equals(obj);
	}

	public override int GetHashCode()
	{
		return base.GetHashCode();
	}

	public override string ToString()
	{
		return $"{{{Bar} : {Beat}/{192}}}";
	}
}
