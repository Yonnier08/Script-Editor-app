namespace ScriptUtilities;

public enum FtTargetType
{
	sankaku = 0,
	maru = 1,
	batsu = 2,
	shikaku = 3,
	sankaku_hold = 4,
	maru_hold = 5,
	batsu_hold = 6,
	shikaku_hold = 7,
	random = 8,
	random_hold = 9,
	crash = 11,
	slide_l = 12,
	slide_r = 13,
	slide_chain_l = 15,
	slide_chain_r = 16,
	green_square_l = 17,
	sankaku_ch = 18,
	maru_ch = 19,
	batsu_ch = 20,
	shikaku_ch = 21,
	slide_l_ch = 23,
	slide_r_ch = 24,
	blank = 25
}
