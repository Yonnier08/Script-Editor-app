using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using DivaScript;
using EditMode;

namespace ScriptUtilities;

public static class EditScript
{
	private struct FadeColor
	{
		public int A;

		public int R;

		public int G;

		public int B;

		public FadeColor(int a, int r, int g, int b)
		{
			A = a;
			R = r;
			G = g;
			B = b;
		}

		public FadeColor(Fade fade)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			FadeColor color = GetColor(fade);
			this = new FadeColor(color.A, color.R, color.G, color.B);
		}

		public static FadeColor GetColor(Fade fade)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0004: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Expected I4, but got Unknown
			return (int)fade switch
			{
				1 => new FadeColor(1000, 1000, 1000, 1000), 
				2 => new FadeColor(0, 1000, 1000, 1000), 
				3 => new FadeColor(1000, 0, 0, 0), 
				4 => new FadeColor(0, 0, 0, 0), 
				5 => new FadeColor(1000, 1000, 0, 0), 
				6 => new FadeColor(0, 1000, 0, 0), 
				7 => new FadeColor(1000, 0, 1000, 0), 
				8 => new FadeColor(0, 0, 1000, 0), 
				9 => new FadeColor(1000, 0, 0, 1000), 
				10 => new FadeColor(0, 0, 0, 1000), 
				11 => new FadeColor(1000, 1000, 1000, 0), 
				12 => new FadeColor(0, 1000, 1000, 0), 
				13 => new FadeColor(1000, 1000, 753, 796), 
				14 => new FadeColor(0, 1000, 753, 796), 
				15 => new FadeColor(1000, 0, 1000, 1000), 
				16 => new FadeColor(0, 0, 1000, 1000), 
				17 => new FadeColor(1000, 1000, 645, 0), 
				18 => new FadeColor(0, 1000, 645, 0), 
				19 => new FadeColor(1000, 500, 0, 500), 
				20 => new FadeColor(0, 500, 0, 500), 
				_ => new FadeColor(0, 0, 0, 0), 
			};
		}
	}

	private const int PV_FACTOR = 1000;

	private const int PV_START_FACTOR = 100000;

	private const float PV_TIME_FACTOR = 1666.666f;

	private const float PV_DURATION_FACTOR = 16.666f;

	internal static readonly List<string> FT_EDIT_MOTIONS = new List<string>
	{
		"CMN_MRA00_13_01", "CMN_MCA00_50_10", "CMN_MCA00_50_12", "CMN_MCA00_50_13", "CMN_MCA00_50_17", "CMN_MCA00_50_18_B", "CMN_MCA00_50_19", "CMN_MCA00_50_20", "CMN_MCA00_50_21", "CMN_MCA00_50_22",
		"CMN_MCA00_50_23", "CMN_MCA00_50_24", "CMN_MCA00_50_25", "CMN_MCA00_50_26_A", "CMN_MCA00_50_26_B", "CMN_MCA00_50_27", "CMN_MCA00_50_28", "CMN_MCA00_50_29", "CMN_MCA00_50_30", "CMN_MCA00_50_31",
		"CMN_MCA00_50_32", "CMN_MCA00_50_33", "CMN_MCA00_50_34", "CMN_MCA00_50_35", "CMN_MCA00_50_36", "CMN_MCA00_50_37", "CMN_MCA00_50_38", "CMN_MCA00_50_39", "CMN_MCA00_50_40", "CMN_MCA00_50_41",
		"CMN_MCA00_50_42", "CMN_MCA00_50_43", "CMN_MCA00_50_46", "CMN_MCA00_50_47", "CMN_MCA00_50_48", "CMN_MCA00_50_49", "CMN_MCA00_50_50", "CMN_MCA00_50_51", "CMN_MCA00_50_53", "CMN_MCA00_50_54",
		"CMN_MCA00_50_55", "CMN_MCA00_50_56_A", "CMN_MCA00_50_56_B", "CMN_MCA00_50_57", "CMN_MCA00_50_58", "CMN_MCA00_50_60_A", "CMN_MCA00_50_60_B", "CMN_MCA00_50_60_C", "CMN_MCA00_70_11", "CMN_MCA00_70_12",
		"CMN_MCA00_70_13", "CMN_MCA00_70_14", "CMN_MCA00_70_15", "CMN_MCA00_70_16", "CMN_MCA00_70_17", "CMN_MCA00_70_19", "CMN_MCA00_70_20", "CMN_MCA00_70_21", "CMN_MCA00_70_22", "CMN_MCA00_70_23",
		"CMN_MCA00_70_24", "CMN_MCA00_70_25", "CMN_MCA00_70_26", "CMN_MCA00_70_28", "CMN_MCA00_70_29", "CMN_MCA00_70_30", "CMN_MCA00_70_31", "CMN_MCA00_70_32", "CMN_EDT_01_000A", "CMN_EDT_01_002A",
		"CMN_EDT_01_004A", "CMN_EDT_01_005A", "CMN_EDT_01_009A", "CMN_EDT_01_010A", "CMN_EDT_01_011A", "CMN_EDT_01_012A", "CMN_EDT_01_014A", "CMN_EDT_01_016A", "CMN_EDT_01_017A", "CMN_EDT_01_019A",
		"CMN_EDT_01_021A", "CMN_EDT_01_022A", "CMN_EDT_01_024A", "CMN_EDT_01_027A", "CMN_EDT_01_028A", "CMN_EDT_01_029A", "CMN_EDT_01_030A", "CMN_EDT_01_031A", "CMN_EDT_01_032A", "CMN_EDT_01_033A",
		"CMN_EDT_01_034A", "CMN_EDT_01_035A", "CMN_EDT_01_036A", "CMN_EDT_01_037A", "CMN_EDT_01_038A", "CMN_EDT_01_039A", "CMN_EDT_01_040A", "CMN_EDT_01_041A", "CMN_EDT_01_042A", "CMN_EDT_01_043A",
		"CMN_EDT_01_045A", "CMN_EDT_01_046A", "CMN_EDT_01_047A", "CMN_EDT_01_048A", "CMN_EDT_01_050A", "CMN_EDT_01_051A", "CMN_EDT_01_052A", "CMN_EDT_01_055A", "CMN_EDT_01_056A", "CMN_EDT_01_058A",
		"CMN_EDT_01_060A", "CMN_EDT_EX_PSP03_011A", "CMN_EDT_EX_PSP03_012A", "CMN_EDT_EX_PSP03_013A", "CMN_EDT_EX_PSP03_015A", "CMN_EDT_EX_PSP03_017A", "CMN_EDT_EX_PSP03_018A", "CMN_EDT_EX_PSP03_019A", "CMN_EDT_EX_PSP03_020A", "CMN_EDT_EX_PSP03_022A",
		"CMN_EDT_EX_PSP03_023A", "CMN_EDT_EX_PSP03_028A", "CMN_EDT_EX_PSP03_031A", "CMN_EDT_EX_PSP03_032A", "CMN_EDT_EX_PSP03_034A", "CMN_EDT_EX_PSP03_035A", "CMN_EDT_EX_PSP03_036A", "CMN_EDT_EX_PSP03_037A", "CMN_EDT_EX_PSP03_041A", "CMN_EDT_EX_PSP03_054A",
		"CMN_EDT_EX_PSP03_057A", "CMN_EDT_EX_PSP03_058A", "CMN_EDT_EX_PSP03_059A", "CMN_EDT_PS3_002A", "CMN_EDT_PS3_006A", "CMN_EDT_PS3_007A", "CMN_EDT_PS3_008A", "CMN_EDT_PS3_011A", "CMN_EDT_PS3_012A", "CMN_EDT_PS3_013A",
		"CMN_EDT_PS3_015A", "CMN_EDT_PS3_017A", "CMN_EDT_PS3_021A", "CMN_EDT_PS3_022A", "CMN_EDT_PS3_023A", "CMN_EDT_PSP01_50_10", "CMN_EDT_PSP01_50_12", "CMN_EDT_PSP01_50_18_B", "CMN_EDT_PSP01_50_21", "CMN_EDT_PSP01_50_22",
		"CMN_EDT_PSP01_50_23", "CMN_EDT_PSP01_50_28", "CMN_EDT_PSP01_50_29", "CMN_EDT_PSP01_50_42", "CMN_EDT_PSP01_50_50", "CMN_EDT_PSP01_50_53", "CMN_EDT_PSP01_50_54", "CMN_EDT_PSP01_50_56_B", "CMN_EDT_PSP01_50_60_A", "CMN_EDT_PSP01_70_11",
		"CMN_EDT_PSP01_70_13", "CMN_EDT_PSP01_70_14", "CMN_EDT_PSP01_70_15", "CMN_EDT_PSP01_70_16", "CMN_EDT_PSP01_70_17", "CMN_EDT_PSP01_70_18", "CMN_EDT_PSP01_70_20", "CMN_EDT_PSP01_70_21", "CMN_EDT_PSP01_70_23", "CMN_EDT_PSP01_70_24",
		"CMN_EDT_PSP01_70_29", "CMN_EDT_PSP01_70_31", "CMN_EDT_PSP01_70_32", "CMN_EDT_PSP02_002A", "CMN_EDT_PSP02_005A", "CMN_EDT_PSP02_011A", "CMN_EDT_PSP02_013A", "CMN_EDT_PSP02_014A", "CMN_EDT_PSP02_016A", "CMN_EDT_PSP02_017A",
		"CMN_EDT_PSP02_024A", "CMN_EDT_PSP02_034A", "CMN_EDT_PSP02_038A", "CMN_EDT_PSP02_039A", "CMN_EDT_PSP02_053A", "CMN_EDT_PSP02_056A", "CMN_EDT_PV441_001", "CMN_EDT_VITA01_002A", "CMN_EDT_VITA01_003A", "CMN_EDT_VITA01_009A",
		"CMN_EDT_VITA01_012A", "CMN_EDT_VITA01_014A", "CMN_EDT_VITA01_015A", "CMN_EDT_VITA01_016A", "CMN_EDT_VITA01_018A", "CMN_EDT_VITA01_IDLE"
	};

	public static int ConvertRotation(float rotation)
	{
		return (int)(rotation * 1000f);
	}

	public static int ConvertToDscUnits(float editUnits)
	{
		return (int)Math.Round(editUnits * 1000f);
	}

	public static int ConvertDuration(float editDurationUnits)
	{
		return (int)Math.Round(editDurationUnits * 16.666f);
	}

	public static (List<PvCommand> commands, PvDatabaseInfo pvDatabase) GetEditCommands(Edit edit, int pvId = 0)
	{
		if (edit == null)
		{
			return (commands: new List<PvCommand>(), pvDatabase: null);
		}
		PvDatabaseInfo pvDatabaseInfo = new PvDatabaseInfo(edit, pvId);
		List<PvCommand> list = new List<PvCommand>();
		HashSet<(int, int)> setChara = new HashSet<(int, int)>();
		list.Add(GetMusicPlayCommand(edit));
		list.AddRange(GetPVEndCommands(edit));
		list.AddRange(GetModelDisplayCommands(edit, setChara));
		list.AddRange(GetPartsDisplayCommands(edit, setChara));
		list.AddRange(GetShadowCommands(edit, setChara));
		list.AddRange(GetPlayerMoveCommands(edit, setChara));
		list.AddRange(GetMotionCommands(edit, pvDatabaseInfo, setChara));
		list.AddRange(GetItemCommands(edit, pvDatabaseInfo, setChara));
		list.AddRange(GetExpressionCommands(edit, setChara));
		list.AddRange(GetBlushCommands(edit, setChara));
		list.AddRange(GetEyeAnimationCommands(edit, setChara));
		list.AddRange(GetEyelidAnimationCommands(edit, setChara));
		list.AddRange(GetHandAnimationCommands(edit, setChara));
		list.AddRange(GetMouthAnimationCommands(edit, setChara));
		list.AddRange(GetStageCommands(edit, pvDatabaseInfo));
		list.AddRange(GetCameraCommands(edit));
		list.AddRange(GetEffectCommands(edit, pvDatabaseInfo));
		list.AddRange(GetFadeCommands(edit));
		list.AddRange(GetLyricCommands(edit, pvDatabaseInfo));
		list.AddRange(GetTargetCommands(edit));
		list = PvScript.AddTimeCommands(list);
		list = PvScript.OrderListByTime(list);
		return (commands: list, pvDatabase: pvDatabaseInfo);
	}

	public static (List<PvCommand> commands, PvDatabaseInfo pvDatabase) GetFtEditCommands(Edit edit, int pvId = 0)
	{
		if (edit == null)
		{
			return (commands: new List<PvCommand>(), pvDatabase: null);
		}
		PvDatabaseInfo pvDatabaseInfo = new PvDatabaseInfo(edit, pvId);
		List<PvCommand> list = new List<PvCommand>();
		HashSet<(int, int)> setChara = new HashSet<(int, int)>();
		list.Add(GetMusicPlayCommand(edit));
		list.AddRange(GetPVEndCommands(edit));
		list.AddRange(GetModelDisplayCommands(edit, setChara));
		list.AddRange(GetPartsDisplayCommands(edit, setChara));
		list.AddRange(GetShadowCommands(edit, setChara));
		list.AddRange(GetPlayerMoveCommands(edit, setChara));
		list.AddRange(GetFtMotionCommands(edit, pvDatabaseInfo, setChara));
		list.AddRange(GetItemCommands(edit, pvDatabaseInfo, setChara));
		list.AddRange(GetExpressionCommands(edit, setChara));
		list.AddRange(GetBlushCommands(edit, setChara));
		list.AddRange(GetEyeAnimationCommands(edit, setChara));
		list.AddRange(GetEyelidAnimationCommands(edit, setChara));
		list.AddRange(GetHandAnimationCommands(edit, setChara));
		list.AddRange(GetFtMouthAnimationCommands(edit, setChara));
		list.AddRange(GetStageCommands(edit, pvDatabaseInfo));
		list.AddRange(GetCameraCommands(edit));
		list.AddRange(GetEffectCommands(edit, pvDatabaseInfo));
		list.AddRange(GetFadeCommands(edit));
		list.AddRange(GetLyricCommands(edit, pvDatabaseInfo));
		list.AddRange(GetFtTargetCommands(edit));
		list = PvScript.AddTimeCommands(list);
		list = PvScript.OrderListByTime(list);
		return (commands: list, pvDatabase: pvDatabaseInfo);
	}

	internal static PvCommand GetMusicPlayCommand(Edit edit)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Expected O, but got Unknown
		return new PvCommand((int)(edit.SongStartTime * 100000f) * -1, "MUSIC_PLAY", new List<int>());
	}

	internal static List<PvCommand> GetPVEndCommands(Edit edit)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Expected O, but got Unknown
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Expected O, but got Unknown
		List<PvCommand> list = new List<PvCommand>();
		int num = (int)((float)edit.PvEnd * 1666.666f);
		list.Add(new PvCommand(num, "PV_END", new List<int>()));
		list.Add(new PvCommand(num + 1, "END", new List<int>()));
		return list;
	}

	internal static List<PvCommand> GetModelDisplayCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddShowModules(edit.ShowModulePlayer1s, 0);
		AddShowModules(edit.ShowModulePlayer2s, 1);
		AddShowModules(edit.ShowModulePlayer3s, 2);
		return commands;
		void AddShowModules(List<PlayerShowModule> playerShowModules, int player)
		{
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			foreach (PlayerShowModule playerShowModule in playerShowModules)
			{
				int num = (int)((float)playerShowModule.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "EDIT_DISP", new List<int> { playerShowModule.ShowPlayer }));
			}
		}
	}

	internal static List<PvCommand> GetPartsDisplayCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddShowMisc(edit.ShowMiscPlayer1s, 0);
		AddShowMisc(edit.ShowMiscPlayer2s, 1);
		AddShowMisc(edit.ShowMiscPlayer3s, 2);
		return commands;
		void AddShowMisc(List<PlayerShowMisc> playerShowMiscs, int player)
		{
			//IL_0094: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Expected O, but got Unknown
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Expected O, but got Unknown
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_0112: Expected O, but got Unknown
			//IL_0142: Unknown result type (might be due to invalid IL or missing references)
			//IL_014c: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			foreach (PlayerShowMisc playerShowMisc in playerShowMiscs)
			{
				int num = (int)((float)playerShowMisc.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "PARTS_DISP", new List<int> { player, 18, playerShowMisc.Head }));
				commands.Add(new PvCommand(num, "PARTS_DISP", new List<int> { player, 19, playerShowMisc.Face }));
				commands.Add(new PvCommand(num, "PARTS_DISP", new List<int> { player, 20, playerShowMisc.Chest }));
				commands.Add(new PvCommand(num, "PARTS_DISP", new List<int> { player, 21, playerShowMisc.Back }));
			}
		}
	}

	internal static List<PvCommand> GetShadowCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddShadows(edit.ShowShadowPlayer1s, 0);
		AddShadows(edit.ShowShadowPlayer2s, 1);
		AddShadows(edit.ShowShadowPlayer3s, 2);
		return commands;
		void AddShadows(List<PlayerShowShadow> playerShowShadows, int player)
		{
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			foreach (PlayerShowShadow playerShowShadow in playerShowShadows)
			{
				int num = (int)((float)playerShowShadow.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "EDIT_SHADOW", new List<int> { playerShowShadow.ShowShadow }));
			}
		}
	}

	internal static List<PvCommand> GetPlayerMoveCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddPositions(edit.PlayerPositionPlayer1s, 0);
		AddPositions(edit.PlayerPositionPlayer2s, 1);
		AddPositions(edit.PlayerPositionPlayer3s, 2);
		return commands;
		void AddPositions(List<PlayerPosition> playerPositions, int player)
		{
			//IL_013a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0144: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			foreach (PlayerPosition playerPosition in playerPositions)
			{
				int num = (int)((float)playerPosition.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "EDIT_MOVE_XYZ", new List<int>
				{
					ConvertDuration(playerPosition.Duration),
					ConvertToDscUnits(playerPosition.Start.X),
					ConvertToDscUnits(playerPosition.Start.Y),
					ConvertToDscUnits(playerPosition.Start.Z),
					ConvertToDscUnits(playerPosition.End.X),
					ConvertToDscUnits(playerPosition.End.Y),
					ConvertToDscUnits(playerPosition.End.Z),
					ConvertToDscUnits(playerPosition.StartRoation),
					ConvertToDscUnits(playerPosition.EndRoation)
				}));
			}
		}
	}

	internal static List<PvCommand> GetMotionCommands(Edit edit, PvDatabaseInfo database, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddMotions(edit.PlayerMotionPlayer1s, database.Motions1P, 0);
		AddMotions(edit.PlayerMotionPlayer2s, database.Motions2P, 1);
		AddMotions(edit.PlayerMotionPlayer3s, database.Motions3P, 2);
		return commands;
		void AddMotions(List<PlayerMotion> playerMotions, List<string> motions, int player)
		{
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Expected O, but got Unknown
			//IL_0106: Unknown result type (might be due to invalid IL or missing references)
			//IL_0110: Expected O, but got Unknown
			//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Expected O, but got Unknown
			foreach (PlayerMotion instruction in playerMotions)
			{
				int item = motions.FindIndex((string s) => s == $"{instruction.MotionID1}");
				int num = (int)((float)instruction.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				if (instruction.Unknown2 > 0)
				{
					commands.Add(new PvCommand(num, "MOT_SMOOTH", new List<int> { player, instruction.Interpolation }));
				}
				commands.Add(new PvCommand(num, "EDIT_MOTION", new List<int>
				{
					item,
					ConvertToDscUnits(instruction.PlaybackSpeed)
				}));
			}
		}
	}

	internal static List<PvCommand> GetFtMotionCommands(Edit edit, PvDatabaseInfo database, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddMotions(edit.PlayerMotionPlayer1s, database.Motions1P, 0);
		AddMotions(edit.PlayerMotionPlayer2s, database.Motions2P, 1);
		AddMotions(edit.PlayerMotionPlayer3s, database.Motions3P, 2);
		return commands;
		void AddMotions(List<PlayerMotion> playerMotions, List<string> motions, int player)
		{
			//IL_0094: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Expected O, but got Unknown
			//IL_0149: Unknown result type (might be due to invalid IL or missing references)
			//IL_0153: Expected O, but got Unknown
			//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Expected O, but got Unknown
			foreach (PlayerMotion instruction in playerMotions)
			{
				int item = motions.FindIndex((string s) => s == $"{instruction.MotionID1}");
				int item2 = ((instruction.Unknown2 > 0) ? 2 : 0);
				int num = (int)((float)instruction.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				if (instruction.Unknown2 > 0)
				{
					commands.Add(new PvCommand(num, "MOT_SMOOTH", new List<int> { player, instruction.Interpolation }));
				}
				commands.Add(new PvCommand(num, "EDIT_MOTION_F", new List<int>
				{
					item,
					ConvertToDscUnits(instruction.PlaybackSpeed),
					item2,
					(int)instruction.PlaybackStartTime,
					item2,
					item2
				}));
			}
		}
	}

	internal static List<PvCommand> GetItemCommands(Edit edit, PvDatabaseInfo database, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddItems(edit.PlayerItemPlayer1s, edit.PlayerMotionPlayer1s, 0);
		AddItems(edit.PlayerItemPlayer2s, edit.PlayerMotionPlayer2s, 1);
		AddItems(edit.PlayerItemPlayer3s, edit.PlayerMotionPlayer3s, 2);
		return commands;
		void AddItems(List<PlayerItem> playerItem, List<PlayerMotion> motions, int player)
		{
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Expected O, but got Unknown
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ba: Expected O, but got Unknown
			//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f1: Expected O, but got Unknown
			//IL_0188: Unknown result type (might be due to invalid IL or missing references)
			//IL_0192: Expected O, but got Unknown
			foreach (PlayerItem instruction in playerItem)
			{
				int num = (int)((float)instruction.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				if (Enum.IsDefined(typeof(HandItem), (object)(HandItem)instruction.ItemID))
				{
					int num2 = database.HandItems.FindIndex((HandItem i) => i == (HandItem)instruction.ItemID);
					if (num2 != -1)
					{
						num2++;
					}
					commands.Add(new PvCommand(num, "EDIT_ITEM", new List<int> { num2 }));
				}
				else if (Enum.IsDefined(typeof(InstrumentItem), (object)(InstrumentItem)instruction.ItemID))
				{
					int item = database.PvItems.FindIndex((InstrumentItem i) => i == (InstrumentItem)instruction.ItemID);
					PlayerMotion val = ((IEnumerable<PlayerMotion>)motions).FirstOrDefault((Func<PlayerMotion, bool>)((PlayerMotion m) => m.Time == instruction.Time));
					int item2 = ((val != null) ? ConvertToDscUnits(val.PlaybackSpeed) : 0);
					commands.Add(new PvCommand(num, "EDIT_INSTRUMENT_ITEM", new List<int> { item, item2 }));
				}
				else
				{
					commands.Add(new PvCommand(num, "EDIT_ITEM", new List<int> { -1 }));
				}
			}
		}
	}

	internal static List<PvCommand> GetExpressionCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddExpressions(edit.PlayerExpressionPlayer1s, 0);
		AddExpressions(edit.PlayerExpressionPlayer2s, 1);
		AddExpressions(edit.PlayerExpressionPlayer3s, 2);
		return commands;
		void AddExpressions(List<PlayerExpression> playerExpressions, int player)
		{
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Expected O, but got Unknown
			//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00da: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_0135: Unknown result type (might be due to invalid IL or missing references)
			//IL_013f: Expected O, but got Unknown
			foreach (PlayerExpression playerExpression in playerExpressions)
			{
				int num = (int)((float)playerExpression.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				string text = ((object)edit).GetType().Namespace ?? string.Empty;
				Expression expressionID;
				int item;
				if (text.Contains("Diva2nd") || text.Contains("DivaExtend"))
				{
					expressionID = playerExpression.ExpressionID;
					item = (int)((!Enum.TryParse<PSPExpression>(((object)(Expression)(ref expressionID)).ToString(), out var result)) ? PSPExpression.通常 : result);
				}
				else
				{
					expressionID = playerExpression.ExpressionID;
					item = (int)((!Enum.TryParse<FtExpression>(((object)(Expression)(ref expressionID)).ToString(), out var result2)) ? FtExpression.通常 : result2);
				}
				commands.Add(new PvCommand(num, "EXPRESSION", new List<int>
				{
					player,
					item,
					(int)playerExpression.Interpolation,
					-1
				}));
			}
		}
	}

	internal static List<PvCommand> GetBlushCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddBlushes(edit.PlayerFaceEffectPlayer1s, 0);
		AddBlushes(edit.PlayerFaceEffectPlayer2s, 1);
		AddBlushes(edit.PlayerFaceEffectPlayer3s, 2);
		return commands;
		void AddBlushes(List<PlayerFaceEffect> playerFaceEffects, int player)
		{
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Expected I4, but got Unknown
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			foreach (PlayerFaceEffect playerFaceEffect in playerFaceEffects)
			{
				int num = (int)((float)playerFaceEffect.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "EDIT_BLUSH", new List<int> { (int)playerFaceEffect.FaceID }));
			}
		}
	}

	internal static List<PvCommand> GetEyeAnimationCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddEyeAnimations(edit.PlayerLineOfSightPlayer1s, 0);
		AddEyeAnimations(edit.PlayerLineOfSightPlayer2s, 1);
		AddEyeAnimations(edit.PlayerLineOfSightPlayer3s, 2);
		return commands;
		void AddEyeAnimations(List<PlayerLineOfSight> playerLineOfSights, int player)
		{
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			//IL_006d: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Expected O, but got Unknown
			//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d3: Expected O, but got Unknown
			//IL_017f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0189: Expected O, but got Unknown
			//IL_0121: Unknown result type (might be due to invalid IL or missing references)
			//IL_012b: Expected O, but got Unknown
			//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e1: Expected O, but got Unknown
			foreach (PlayerLineOfSight playerLineOfSight in playerLineOfSights)
			{
				int num = (int)((float)playerLineOfSight.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				Sight sightID = playerLineOfSight.SightID;
				if (Enum.TryParse<FtLineOfSight>(((object)(Sight)(ref sightID)).ToString(), out var result))
				{
					int num2 = (int)result;
					if (num2 >= 0 && num2 <= 9)
					{
						commands.Add(new PvCommand(num, "EDIT_EYE_ANIM", new List<int>
						{
							num2,
							0,
							(int)playerLineOfSight.Interpolation
						}));
					}
					else
					{
						commands.Add(new PvCommand(num, "LOOK_ANIM", new List<int>
						{
							player,
							num2,
							(int)playerLineOfSight.Interpolation,
							1000
						}));
					}
				}
				else
				{
					int num3 = 9;
					if (num3 >= 0 && num3 <= 9)
					{
						commands.Add(new PvCommand(num, "EDIT_EYE_ANIM", new List<int>
						{
							num3,
							0,
							(int)playerLineOfSight.Interpolation
						}));
					}
					else
					{
						commands.Add(new PvCommand(num, "LOOK_ANIM", new List<int>
						{
							player,
							num3,
							(int)playerLineOfSight.Interpolation,
							1000
						}));
					}
				}
			}
		}
	}

	internal static List<PvCommand> GetEyelidAnimationCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddEyelidAnimations(edit.PlayerBlinkPlayer1s, 0);
		AddEyelidAnimations(edit.PlayerBlinkPlayer2s, 1);
		AddEyelidAnimations(edit.PlayerBlinkPlayer3s, 2);
		return commands;
		void AddEyelidAnimations(List<PlayerBlink> playerBlinks, int player)
		{
			//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ae: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			foreach (PlayerBlink playerBlink in playerBlinks)
			{
				int num = (int)((float)playerBlink.Time * 1666.666f) + player;
				int item = playerBlink.BlinkLevel * 10;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "EDIT_EYELID_ANIM", new List<int>
				{
					(int)playerBlink.BlinkID,
					(int)playerBlink.Interpolation,
					item
				}));
			}
		}
	}

	internal static List<PvCommand> GetHandAnimationCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddPlayerHands(edit.PlayerLeftHandPlayer1s, 0, 0);
		AddPlayerHands(edit.PlayerLeftHandPlayer2s, 1, 0);
		AddPlayerHands(edit.PlayerLeftHandPlayer3s, 2, 0);
		AddPlayerHands(edit.PlayerRightHandPlayer1s, 0, 1);
		AddPlayerHands(edit.PlayerRightHandPlayer2s, 1, 1);
		AddPlayerHands(edit.PlayerRightHandPlayer3s, 2, 1);
		return commands;
		void AddPlayerHands(List<PlayerHand> playerHands, int player, int hand)
		{
			//IL_008c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0096: Expected I4, but got Unknown
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Expected O, but got Unknown
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Expected O, but got Unknown
			foreach (PlayerHand playerHand in playerHands)
			{
				int item = -1;
				int num = (int)((float)playerHand.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "HAND_ANIM", new List<int>
				{
					player,
					hand,
					(int)playerHand.HandID,
					(int)playerHand.Interpolation,
					item
				}));
			}
		}
	}

	internal static List<PvCommand> GetMouthAnimationCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddMouthAnimations(edit.PlayerLipsyncPlayer1s, 0);
		AddMouthAnimations(edit.PlayerLipsyncPlayer2s, 1);
		AddMouthAnimations(edit.PlayerLipsyncPlayer3s, 2);
		return commands;
		void AddMouthAnimations(List<PlayerLipsync> playerLipsyncs, int player)
		{
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Expected I4, but got Unknown
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			//IL_009a: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			foreach (PlayerLipsync playerLipsync in playerLipsyncs)
			{
				int num = (int)((float)playerLipsync.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				commands.Add(new PvCommand(num, "EDIT_MOUTH_ANIM", new List<int>
				{
					(int)playerLipsync.MouthID,
					(int)playerLipsync.Interpolation
				}));
			}
		}
	}

	internal static List<PvCommand> GetFtMouthAnimationCommands(Edit edit, HashSet<(int, int)> setChara)
	{
		List<PvCommand> commands = new List<PvCommand>();
		AddMouthAnimations(edit.PlayerLipsyncPlayer1s, 0);
		AddMouthAnimations(edit.PlayerLipsyncPlayer2s, 1);
		AddMouthAnimations(edit.PlayerLipsyncPlayer3s, 2);
		return commands;
		void AddMouthAnimations(List<PlayerLipsync> playerLipsyncs, int player)
		{
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Expected O, but got Unknown
			//IL_0136: Unknown result type (might be due to invalid IL or missing references)
			//IL_013b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01bb: Expected O, but got Unknown
			//IL_017e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0188: Expected O, but got Unknown
			//IL_0123: Unknown result type (might be due to invalid IL or missing references)
			//IL_012d: Expected O, but got Unknown
			//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f9: Expected O, but got Unknown
			foreach (PlayerLipsync playerLipsync in playerLipsyncs)
			{
				int num = (int)((float)playerLipsync.Time * 1666.666f) + player;
				if (setChara.Add((num, player)))
				{
					commands.Add(new PvCommand(num, "SET_CHARA", new List<int> { player }));
				}
				string text = ((object)edit).GetType().Namespace ?? string.Empty;
				MouthShape mouthID;
				if (text.Contains("Diva2nd") || text.Contains("DivaExtend"))
				{
					mouthID = playerLipsync.MouthID;
					if (Enum.TryParse<PSPMouth>(((object)(MouthShape)(ref mouthID)).ToString(), out var result))
					{
						commands.Add(new PvCommand(num, "EDIT_MOUTH_ANIM", new List<int>
						{
							(int)result,
							(int)playerLipsync.Interpolation
						}));
					}
					else
					{
						commands.Add(new PvCommand(num, "EDIT_MOUTH_ANIM", new List<int>
						{
							9,
							(int)playerLipsync.Interpolation
						}));
					}
				}
				else
				{
					mouthID = playerLipsync.MouthID;
					if (Enum.TryParse<FtMouth>(((object)(MouthShape)(ref mouthID)).ToString(), out var result2))
					{
						commands.Add(new PvCommand(num, "EDIT_MOUTH_ANIM", new List<int>
						{
							(int)result2,
							(int)playerLipsync.Interpolation
						}));
					}
					else
					{
						commands.Add(new PvCommand(num, "EDIT_MOUTH_ANIM", new List<int>
						{
							8,
							(int)playerLipsync.Interpolation
						}));
					}
				}
			}
		}
	}

	internal static List<PvCommand> GetStageCommands(Edit edit, PvDatabaseInfo database)
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Expected O, but got Unknown
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Expected O, but got Unknown
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Expected O, but got Unknown
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Expected I4, but got Unknown
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Expected O, but got Unknown
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Expected O, but got Unknown
		List<PvCommand> list = new List<PvCommand>();
		(int, int, int, int, int, int) tuple = (-1, -1, -1, -1, -1, -1);
		int num = -1;
		(int, int) tuple2 = (-1, -1);
		foreach (EditStage instruction in edit.EditStages)
		{
			int item = database.Stages.FindIndex((Stage s) => ((int)instruction.StageID1 == -1110002437) ? (s == instruction.StageID3) : (s == instruction.StageID1)) + 1;
			int num2 = (int)((float)instruction.Time * 1666.666f);
			list.Add(new PvCommand(num2, "CHANGE_FIELD", new List<int> { item }));
			(int, int, int, int, int, int) toneParams = GetToneParams(instruction.StageShader);
			(int, int, int, int, int, int) tuple3 = toneParams;
			(int, int, int, int, int, int) tuple4 = tuple;
			if (tuple3.Item1 != tuple4.Item1 || tuple3.Item2 != tuple4.Item2 || tuple3.Item3 != tuple4.Item3 || tuple3.Item4 != tuple4.Item4 || tuple3.Item5 != tuple4.Item5 || tuple3.Item6 != tuple4.Item6)
			{
				list.Add(new PvCommand(num2, "TONE_TRANS", new List<int> { toneParams.Item1, toneParams.Item2, toneParams.Item3, toneParams.Item4, toneParams.Item5, toneParams.Item6 }));
				tuple = toneParams;
			}
			int saturateValue = GetSaturateValue(instruction.StageShader);
			if (saturateValue != num)
			{
				list.Add(new PvCommand(num2, "SATURATE", new List<int> { saturateValue }));
				num = saturateValue;
			}
			(int, int) pseParams = GetPseParams(instruction.StageShader);
			(int, int) tuple5 = pseParams;
			(int, int) tuple6 = tuple2;
			if (tuple5.Item1 != tuple6.Item1 || tuple5.Item2 != tuple6.Item2)
			{
				list.Add(new PvCommand(num2, "PSE", new List<int> { pseParams.Item1, pseParams.Item2 }));
				tuple2 = pseParams;
			}
			list.Add(new PvCommand(num2, "EDIT_STAGE_PARAM", new List<int> { (int)instruction.StageShader }));
		}
		return list;
	}

	private static (int duration, int r, int g, int b, int extra1, int extra2) GetToneParams(Shader shader)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected I4, but got Unknown
		return (int)shader switch
		{
			0 => (duration: 0, r: 0, g: 0, b: 1000, extra1: 1000, extra2: 1000), 
			10 => (duration: 300, r: 100, g: 0, b: 1000, extra1: 1000, extra2: 1000), 
			11 => (duration: 40, r: 220, g: 380, b: 980, extra1: 1000, extra2: 1000), 
			8 => (duration: 0, r: 550, g: 580, b: 800, extra1: 930, extra2: 940), 
			9 => (duration: 680, r: 300, g: 0, b: 980, extra1: 1000, extra2: 840), 
			2 => (duration: 250, r: 20, g: 30, b: 1000, extra1: 900, extra2: 900), 
			3 => (duration: -100, r: -100, g: -100, b: 800, extra1: 800, extra2: 800), 
			1 => (duration: 0, r: 130, g: 170, b: 960, extra1: 1000, extra2: 1000), 
			4 => (duration: 250, r: 250, g: 250, b: 850, extra1: 850, extra2: 950), 
			5 => (duration: 450, r: 450, g: 450, b: 700, extra1: 700, extra2: 800), 
			6 => (duration: 600, r: 350, g: 0, b: 930, extra1: 1000, extra2: 1000), 
			7 => (duration: 100, r: 260, g: 600, b: 700, extra1: 850, extra2: 800), 
			_ => (duration: 0, r: 0, g: 0, b: 1000, extra1: 1000, extra2: 1000), 
		};
	}

	private static int GetSaturateValue(Shader shader)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected I4, but got Unknown
		return (int)shader switch
		{
			0 => 1000, 
			10 => 0, 
			11 => 0, 
			8 => 190, 
			9 => 190, 
			2 => 700, 
			3 => 1000, 
			4 => 1000, 
			5 => 1000, 
			6 => 450, 
			7 => 550, 
			1 => 750, 
			_ => 1000, 
		};
	}

	private static (int exposure, int gamma) GetPseParams(Shader shader)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected I4, but got Unknown
		return (int)shader switch
		{
			0 => (exposure: 1000, gamma: 1000), 
			10 => (exposure: 1000, gamma: 1000), 
			11 => (exposure: 1000, gamma: 1000), 
			8 => (exposure: 1000, gamma: 1000), 
			9 => (exposure: 1000, gamma: 1000), 
			2 => (exposure: 1000, gamma: 900), 
			3 => (exposure: 1000, gamma: 900), 
			1 => (exposure: 1000, gamma: 1000), 
			4 => (exposure: 900, gamma: 650), 
			5 => (exposure: 850, gamma: 650), 
			6 => (exposure: 1000, gamma: 1000), 
			7 => (exposure: 1000, gamma: 1000), 
			_ => (exposure: 1000, gamma: 1000), 
		};
	}

	internal static List<PvCommand> GetCameraCommands(Edit edit)
	{
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Expected O, but got Unknown
		List<PvCommand> list = new List<PvCommand>();
		foreach (EditCamera editCamera in edit.EditCameras)
		{
			int num = (int)((float)editCamera.Time * 1666.666f);
			foreach (CameraKeyPoint cameraKeyPoint in editCamera.CameraKeyPoints)
			{
				if (cameraKeyPoint.CameraDuration != 0)
				{
					list.Add(new PvCommand(num, "EDIT_CAMERA", new List<int>
					{
						ConvertDuration(cameraKeyPoint.CameraDuration),
						ConvertToDscUnits(cameraKeyPoint.CameraStart.X),
						ConvertToDscUnits(cameraKeyPoint.CameraStart.Y),
						ConvertToDscUnits(cameraKeyPoint.CameraStart.Z),
						ConvertToDscUnits(cameraKeyPoint.FocusPointStart.X),
						ConvertToDscUnits(cameraKeyPoint.FocusPointStart.Y),
						ConvertToDscUnits(cameraKeyPoint.FocusPointStart.Z),
						ConvertToDscUnits(cameraKeyPoint.UnknowntStart.X),
						ConvertToDscUnits(cameraKeyPoint.UnknowntStart.Y),
						ConvertToDscUnits(cameraKeyPoint.UnknowntStart.Z),
						ConvertToDscUnits(cameraKeyPoint.CameraEnd.X),
						ConvertToDscUnits(cameraKeyPoint.CameraEnd.Y),
						ConvertToDscUnits(cameraKeyPoint.CameraEnd.Z),
						ConvertToDscUnits(cameraKeyPoint.FocusPointEnd.X),
						ConvertToDscUnits(cameraKeyPoint.FocusPointEnd.Y),
						ConvertToDscUnits(cameraKeyPoint.FocusPointEnd.Z),
						ConvertToDscUnits(cameraKeyPoint.UnknowntEnd.X),
						ConvertToDscUnits(cameraKeyPoint.UnknowntEnd.Y),
						ConvertToDscUnits(cameraKeyPoint.UnknowntEnd.Z),
						ConvertToDscUnits(cameraKeyPoint.CameraAccelerationStart),
						ConvertToDscUnits(cameraKeyPoint.CameraAccelerationEnd),
						GetIsPlayerFocus(cameraKeyPoint.PlayerFocus),
						GetPlayer(cameraKeyPoint.PlayerFocus),
						GetPart(cameraKeyPoint.PlayerFocus)
					}));
					num += (int)((float)cameraKeyPoint.CameraDuration * 1666.666f);
				}
			}
		}
		return list;
		static int GetIsPlayerFocus(PlayerFocus pf)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Invalid comparison between Unknown and I4
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			if ((int)pf == 256 || !Enum.IsDefined(typeof(PlayerFocus), pf))
			{
				return 0;
			}
			return 1;
		}
		static int GetPart(PlayerFocus pf)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0004: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a1: Invalid comparison between Unknown and I4
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Invalid comparison between Unknown and I4
			//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Invalid comparison between Unknown and I4
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Invalid comparison between Unknown and I4
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Invalid comparison between Unknown and I4
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Invalid comparison between Unknown and I4
			//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Invalid comparison between Unknown and I4
			//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Invalid comparison between Unknown and I4
			//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Invalid comparison between Unknown and I4
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Invalid comparison between Unknown and I4
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_0077: Invalid comparison between Unknown and I4
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Invalid comparison between Unknown and I4
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0031: Invalid comparison between Unknown and I4
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Invalid comparison between Unknown and I4
			//IL_0103: Unknown result type (might be due to invalid IL or missing references)
			//IL_0109: Invalid comparison between Unknown and I4
			//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f5: Invalid comparison between Unknown and I4
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cf: Invalid comparison between Unknown and I4
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bb: Invalid comparison between Unknown and I4
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0084: Invalid comparison between Unknown and I4
			//IL_0061: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Invalid comparison between Unknown and I4
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Invalid comparison between Unknown and I4
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Invalid comparison between Unknown and I4
			//IL_010d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0113: Invalid comparison between Unknown and I4
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d9: Invalid comparison between Unknown and I4
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Invalid comparison between Unknown and I4
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Invalid comparison between Unknown and I4
			if ((int)pf <= 151)
			{
				if ((int)pf <= 37)
				{
					if ((int)pf <= 7)
					{
						if ((int)pf == 5 || (int)pf == 7)
						{
							goto IL_011b;
						}
					}
					else if ((int)pf == 21 || (int)pf == 23 || (int)pf == 37)
					{
						goto IL_011b;
					}
				}
				else if ((int)pf <= 133)
				{
					if ((int)pf == 39)
					{
						goto IL_011b;
					}
					if ((int)pf == 133)
					{
						goto IL_011f;
					}
				}
				else if ((int)pf == 135 || (int)pf == 149 || (int)pf == 151)
				{
					goto IL_011f;
				}
			}
			else if ((int)pf <= 263)
			{
				if ((int)pf <= 167)
				{
					if ((int)pf == 165 || (int)pf == 167)
					{
						goto IL_011f;
					}
				}
				else
				{
					if ((int)pf == 256)
					{
						return 0;
					}
					if ((int)pf == 261 || (int)pf == 263)
					{
						goto IL_0123;
					}
				}
			}
			else if ((int)pf <= 279)
			{
				if ((int)pf == 277 || (int)pf == 279)
				{
					goto IL_0123;
				}
			}
			else
			{
				if ((int)pf == 293 || (int)pf == 295)
				{
					goto IL_0123;
				}
				if ((int)pf == 1029)
				{
					goto IL_011b;
				}
			}
			return 0;
			IL_0123:
			return 2;
			IL_011f:
			return 1;
			IL_011b:
			return 0;
		}
		static int GetPlayer(PlayerFocus pf)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0004: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a1: Invalid comparison between Unknown and I4
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Invalid comparison between Unknown and I4
			//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Invalid comparison between Unknown and I4
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Invalid comparison between Unknown and I4
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Invalid comparison between Unknown and I4
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Invalid comparison between Unknown and I4
			//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Invalid comparison between Unknown and I4
			//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Invalid comparison between Unknown and I4
			//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Invalid comparison between Unknown and I4
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Invalid comparison between Unknown and I4
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_0077: Invalid comparison between Unknown and I4
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Invalid comparison between Unknown and I4
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0031: Invalid comparison between Unknown and I4
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Invalid comparison between Unknown and I4
			//IL_0103: Unknown result type (might be due to invalid IL or missing references)
			//IL_0109: Invalid comparison between Unknown and I4
			//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f5: Invalid comparison between Unknown and I4
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cf: Invalid comparison between Unknown and I4
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bb: Invalid comparison between Unknown and I4
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0084: Invalid comparison between Unknown and I4
			//IL_0061: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Invalid comparison between Unknown and I4
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Invalid comparison between Unknown and I4
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Invalid comparison between Unknown and I4
			//IL_010d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0113: Invalid comparison between Unknown and I4
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d9: Invalid comparison between Unknown and I4
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Invalid comparison between Unknown and I4
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Invalid comparison between Unknown and I4
			if ((int)pf <= 151)
			{
				if ((int)pf <= 37)
				{
					if ((int)pf <= 7)
					{
						if ((int)pf == 5 || (int)pf == 7)
						{
							goto IL_011b;
						}
					}
					else
					{
						if ((int)pf == 21 || (int)pf == 23)
						{
							goto IL_011f;
						}
						if ((int)pf == 37)
						{
							goto IL_0123;
						}
					}
				}
				else if ((int)pf <= 133)
				{
					if ((int)pf == 39)
					{
						goto IL_0123;
					}
					if ((int)pf == 133)
					{
						goto IL_011b;
					}
				}
				else
				{
					if ((int)pf == 135)
					{
						goto IL_011b;
					}
					if ((int)pf == 149 || (int)pf == 151)
					{
						goto IL_011f;
					}
				}
			}
			else if ((int)pf <= 263)
			{
				if ((int)pf <= 167)
				{
					if ((int)pf == 165 || (int)pf == 167)
					{
						goto IL_0123;
					}
				}
				else
				{
					if ((int)pf == 256)
					{
						return -1;
					}
					if ((int)pf == 261 || (int)pf == 263)
					{
						goto IL_011b;
					}
				}
			}
			else if ((int)pf <= 279)
			{
				if ((int)pf == 277 || (int)pf == 279)
				{
					goto IL_011f;
				}
			}
			else
			{
				if ((int)pf == 293 || (int)pf == 295)
				{
					goto IL_0123;
				}
				if ((int)pf == 1029)
				{
					goto IL_011b;
				}
			}
			return -1;
			IL_0123:
			return 2;
			IL_011f:
			return 1;
			IL_011b:
			return 0;
		}
	}

	internal static List<PvCommand> GetEffectCommands(Edit edit, PvDatabaseInfo database)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Invalid comparison between Unknown and I4
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		List<PvCommand> list = new List<PvCommand>();
		foreach (EditEffect instruction in edit.EditEffects)
		{
			int item = (((int)instruction.EffectID == -1) ? (-1) : database.Effects.FindIndex((Effect s) => s == instruction.EffectID));
			int num = (int)((float)instruction.Time * 1666.666f);
			list.Add(new PvCommand(num, "EDIT_EFFECT", new List<int>
			{
				item,
				ConvertToDscUnits(instruction.PlaybackSpeed)
			}));
		}
		return list;
	}

	internal static List<PvCommand> GetFadeCommands(Edit edit)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Expected O, but got Unknown
		List<PvCommand> list = new List<PvCommand>();
		foreach (EditFade editFade in edit.EditFades)
		{
			int num = (int)((float)editFade.Time * 1666.666f);
			FadeColor fadeColor = new FadeColor(editFade.FadeType);
			bool isFadeIn = editFade.GetIsFadeIn();
			list.Add(new PvCommand(num, "SCENE_FADE", new List<int>
			{
				ConvertToDscUnits(editFade.PlaybackSpeed),
				(int)((float)(isFadeIn ? 1000 : 0) - editFade.StartTime * (float)(isFadeIn ? 10 : (-10))),
				((int)editFade.FadeType != 0) ? ((int)(editFade.EffectProgress * 10f)) : 0,
				fadeColor.R,
				fadeColor.G,
				fadeColor.B
			}));
		}
		return list;
	}

	internal static List<PvCommand> GetLyricCommands(Edit edit, PvDatabaseInfo database)
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Expected O, but got Unknown
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Expected O, but got Unknown
		List<PvCommand> list = new List<PvCommand>();
		int i;
		for (i = 0; i < edit.EditLyrics.Count; i++)
		{
			int item = database.Lyrics.FindIndex((string s) => s == edit.EditLyrics[i].Lyrics);
			EditLyric val = edit.EditLyrics[i];
			int num = (int)((float)val.Time * 1666.666f);
			int num2 = num + (int)((float)val.Duration * 1666.666f) - 1;
			list.Add(new PvCommand(num, "LYRIC", new List<int>
			{
				item,
				(int)GetBGRA(val)
			}));
			list.Add(new PvCommand(num2, "LYRIC", new List<int>
			{
				-1,
				(int)GetBGRA(val)
			}));
		}
		return list;
		static uint GetBGRA(EditLyric lyric)
		{
			int num3 = lyric.B | (lyric.G << 8) | (lyric.R << 16);
			byte b2 = (lyric.Alpha = byte.MaxValue);
			return (uint)(num3 | (b2 << 24));
		}
	}

	internal static List<PvCommand> GetTargetCommands(Edit edit)
	{
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Expected I4, but got Unknown
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Expected O, but got Unknown
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Expected O, but got Unknown
		EditTime.NormalizeTimelineIndexes(edit);
		List<PvCommand> list = new List<PvCommand>();
		foreach (EditTarget editTarget in edit.EditTargets)
		{
			int num = 1;
			int num2 = EditTime.DivaTimeFromNormalizedTimelineIndex((ushort)(editTarget.BarIndex - num), editTarget.BeatIndex, edit.BPMChanges);
			int num3 = EditTime.DivaTimeFromNormalizedTimelineIndex(editTarget.BarIndex, editTarget.BeatIndex, edit.BPMChanges);
			int num4 = num3 - num2;
			bool flag = editTarget.HoldEndBar != 0 || editTarget.HoldEndBeat != 0;
			int num5 = (flag ? EditTime.DivaTimeFromNormalizedTimelineIndex((ushort)(editTarget.HoldEndBar - 1), editTarget.HoldEndBeat, edit.BPMChanges) : 0);
			int num6 = (flag ? EditTime.DivaTimeFromNormalizedTimelineIndex(editTarget.HoldEndBar, editTarget.HoldEndBeat, edit.BPMChanges) : 0);
			int num7 = (flag ? (num6 - num5) : 0);
			int item = (flag ? (num5 - num2) : 0);
			int item2 = (int)(editTarget.XPosition * 362.5f);
			int item3 = (int)(editTarget.YPosition * 362.5f);
			int item4 = ConvertRotation(editTarget.EntryAngle);
			int item5 = (int)editTarget.TargetType;
			List<int> list2 = new List<int>(11)
			{
				item5,
				item,
				-1,
				item2,
				item3,
				item4,
				2,
				300000,
				500,
				num4 / 100,
				EditTime.GetSigAt(editTarget.BarIndex, edit.TimeSigChanges),
				-1
			};
			list.Add(new PvCommand(num2, "TARGET", list2));
			if (flag)
			{
				List<int> list3 = new List<int>(11)
				{
					item5,
					-1,
					1,
					item2,
					item3,
					item4,
					2,
					300000,
					500,
					num7 / 100,
					EditTime.GetSigAt(editTarget.HoldEndBar, edit.TimeSigChanges),
					-1
				};
				list.Add(new PvCommand(num5, "TARGET", list3));
			}
		}
		return list;
	}

	internal static List<PvCommand> GetFtTargetCommands(Edit edit)
	{
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Expected I4, but got Unknown
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Expected O, but got Unknown
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Expected O, but got Unknown
		EditTime.NormalizeTimelineIndexes(edit);
		List<PvCommand> list = new List<PvCommand>();
		foreach (EditTarget editTarget in edit.EditTargets)
		{
			int num = 1;
			int num2 = EditTime.DivaTimeFromNormalizedTimelineIndex((ushort)(editTarget.BarIndex - num), editTarget.BeatIndex, edit.BPMChanges);
			int num3 = EditTime.DivaTimeFromNormalizedTimelineIndex(editTarget.BarIndex, editTarget.BeatIndex, edit.BPMChanges);
			int num4 = num3 - num2;
			bool flag = editTarget.HoldEndBar != 0 || editTarget.HoldEndBeat != 0;
			int item = (int)(editTarget.XPosition * 362.5f);
			int item2 = (int)(editTarget.YPosition * 362.5f);
			int item3 = ConvertRotation(editTarget.EntryAngle);
			int item4 = (int)editTarget.TargetType;
			List<int> list2 = new List<int>(11) { item4, item, item2, item3, 300000, 500, 2 };
			list.Add(new PvCommand(num2, "TARGET_FLYING_TIME", new List<int> { num4 / 100 }));
			list.Add(new PvCommand(num2, "TARGET", list2));
		}
		return list;
	}

	public static void CheckForFtMotions()
	{
		StringBuilder stringBuilder = new StringBuilder();
		string path = "C:\\Dev\\EditSaveData\\SaveData";
		string[] directories = Directory.GetDirectories(path);
		string[] array = directories;
		foreach (string path2 in array)
		{
			string[] directories2 = Directory.GetDirectories(path2);
			foreach (string text in directories2)
			{
				string text2 = text + "\\SECURE.BIN";
				if (text2.Contains("EXEDIT"))
				{
					continue;
				}
				try
				{
					Edit val = Edit.Deserialize(text2);
					PvDatabaseInfo pvDatabaseInfo = new PvDatabaseInfo(val, 0);
					IEnumerable<string> source = pvDatabaseInfo.Motions1P.Concat(pvDatabaseInfo.Motions2P).Concat(pvDatabaseInfo.Motions3P);
					bool flag = source.Any((string m) => IsFtCompatable(m));
					IEnumerable<string> source2 = source.Where((string m) => IsFtCompatable(m));
					stringBuilder.Append($"[{val.EditTitle} by {val.EditCreator}] - compatible motions: ({source2.ToArray().Length}/{source.ToArray().Length}) \n" + text2 + " \n");
				}
				catch (Exception arg)
				{
					Console.WriteLine($"{arg}");
				}
			}
		}
		Console.WriteLine(stringBuilder);
		string path3 = "C:\\Dev\\EditSaveData\\SaveData\\compatibility_output_log.txt";
		File.WriteAllText(path3, stringBuilder.ToString());
	}

	internal static bool IsFtCompatable(string motion)
	{
		return FT_EDIT_MOTIONS.Contains(motion);
	}

	internal static bool IsFtCompatable(Motion motion)
	{
		return IsFtCompatable(((object)(Motion)(ref motion)).ToString());
	}
}
