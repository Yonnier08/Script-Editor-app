using System;

namespace ScriptUtilities;

public static class Helper
{
	public static T Clamp<T>(this T value, T min, T max) where T : IComparable<T>
	{
		if (value.CompareTo(min) < 0)
		{
			return min;
		}
		if (value.CompareTo(max) > 0)
		{
			return max;
		}
		return value;
	}

	public static bool IsInRange(float value, float range)
	{
		return value <= range && value >= 0f - range;
	}
}
