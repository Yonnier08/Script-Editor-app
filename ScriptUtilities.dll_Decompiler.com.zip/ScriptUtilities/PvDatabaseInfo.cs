using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EditMode;
using EditMode.Diva2nd;
using EditMode.DivaExtend;

namespace ScriptUtilities;

public class PvDatabaseInfo
{
	public int PvId { get; set; } = 0;


	public string PvIdString => $"pv_{PvId:D3}";

	public string ScriptFileName { get; set; } = string.Empty;


	public string SongName { get; set; } = string.Empty;


	public string SongFileName { get; set; } = string.Empty;


	public int BPM { get; set; } = -1;


	public int Level { get; set; } = -1;


	public DifficultyLevel Difficulty { get; set; } = DifficultyLevel.normal;


	public string PvEditor { get; set; } = "---";


	public List<Performer> Performers { get; set; } = new List<Performer>();


	public List<string> Lyrics { get; set; } = new List<string>();


	public List<Stage> Stages { get; set; } = new List<Stage>();


	public List<Stage> Diva2ndStages { get; set; } = new List<Stage>();


	public List<Effect> Effects { get; set; } = new List<Effect>();


	public List<Effect> Diva2ndEffects { get; set; } = new List<Effect>();


	public List<HandItem> HandItems { get; set; } = new List<HandItem>();


	public List<HandItem> Diva2ndHandItems { get; set; } = new List<HandItem>();


	public List<InstrumentItem> PvItems { get; set; } = new List<InstrumentItem>();


	public List<Motion> Diva2ndMotions { get; set; } = new List<Motion>();


	public List<Stage> DivaExtendStages { get; set; } = new List<Stage>();


	public List<Effect> DivaExtendEffects { get; set; } = new List<Effect>();


	public List<HandItem> DivaExtendHandItems { get; set; } = new List<HandItem>();


	public List<Motion> DivaExtendMotions { get; set; } = new List<Motion>();


	public List<string> Motions1P { get; set; } = new List<string>();


	public List<string> Motions2P { get; set; } = new List<string>();


	public List<string> Motions3P { get; set; } = new List<string>();


	public string SeName { get; set; } = "01_button1";


	public PvDatabaseInfo(Edit edit, int pvId)
	{
		PvId = pvId;
		BPM = (int)edit.DisplayBpm;
		GetPerformers(edit);
		GetLyrics(edit);
		GetStages(edit);
		GetMotions(edit);
		GetEffects(edit);
		GetHandItems(edit);
		GetPvItems(edit);
		Level = edit.EditDifficulty;
		PvEditor = edit.EditCreator;
		SongName = edit.EditTitle ?? "";
		SongFileName = edit.EditTitle ?? "";
		ScriptFileName = edit.EditTitle ?? "";
	}

	public PvDatabaseInfo(Edit edit, int pvId)
	{
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Invalid comparison between Unknown and I4
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Invalid comparison between Unknown and I4
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		PvId = pvId;
		BPM = edit.BpmChanges.FirstOrDefault().Item1;
		Lyrics = new List<string>(edit.Lyrics);
		Diva2ndStages = new List<Stage>(edit.Stages);
		Diva2ndMotions = new List<Motion>(edit.Motions);
		Diva2ndEffects = new List<Effect>(edit.Effects);
		Diva2ndHandItems = new List<HandItem>(edit.HandItems);
		Level = 10;
		if ((int)edit.Module1 != -1)
		{
			Performers.Add(new Performer
			{
				Id = 0,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.Character.MIK,
				PvCostume = (Module)0
			});
		}
		if ((int)edit.Module2 != -1)
		{
			Performers.Add(new Performer
			{
				Id = 0,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.Character.MIK,
				PvCostume = (Module)0
			});
		}
		SeName buttonSound = edit.ButtonSound;
		SeName = ((object)(SeName)(ref buttonSound)).ToString().TrimStart(new char[1] { '_' });
		PvEditor = edit.EditName ?? "";
		SongName = edit.SongName ?? "";
		SongFileName = edit.SongName ?? "";
		ScriptFileName = edit.SongName ?? "";
	}

	public PvDatabaseInfo(Edit edit, int pvId)
	{
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Invalid comparison between Unknown and I4
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Invalid comparison between Unknown and I4
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		PvId = pvId;
		BPM = edit.BpmChanges.FirstOrDefault().Item1;
		Lyrics = new List<string>(edit.Lyrics);
		DivaExtendStages = new List<Stage>(edit.Stages);
		DivaExtendMotions = new List<Motion>(edit.Motions);
		DivaExtendEffects = new List<Effect>(edit.Effects);
		DivaExtendHandItems = new List<HandItem>(edit.HandItems);
		Level = 10;
		if ((int)edit.Module1 != -1)
		{
			Performers.Add(new Performer
			{
				Id = 0,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.Character.MIK,
				PvCostume = (Module)0
			});
		}
		if ((int)edit.Module2 != -1)
		{
			Performers.Add(new Performer
			{
				Id = 0,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.Character.MIK,
				PvCostume = (Module)0
			});
		}
		SeName buttonSound = edit.ButtonSound;
		SeName = ((object)(SeName)(ref buttonSound)).ToString().TrimStart(new char[1] { '_' });
		PvEditor = edit.EditName ?? "";
		SongName = edit.SongName ?? "";
		SongFileName = edit.SongName ?? "";
		ScriptFileName = edit.SongName ?? "";
	}

	public void GetPerformers(Edit edit)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Invalid comparison between Unknown and I4
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Invalid comparison between Unknown and I4
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		if ((int)edit.Module1 != 65535)
		{
			Performers.Add(new Performer
			{
				Id = 0,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.GetCharacter(edit.Module1),
				PvCostume = edit.Module1,
				Back = edit.Module1Back,
				Face = edit.Module1Face,
				Neck = edit.Module1Chest,
				Zujo = edit.Module1Head
			});
		}
		if ((int)edit.Module2 != 65535)
		{
			Performers.Add(new Performer
			{
				Id = 1,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.GetCharacter(edit.Module2),
				PvCostume = edit.Module2,
				Back = edit.Module2Back,
				Face = edit.Module2Face,
				Neck = edit.Module2Chest,
				Zujo = edit.Module2Head
			});
		}
		if ((int)edit.Module3 != 65535)
		{
			Performers.Add(new Performer
			{
				Id = 2,
				Type = Performer.CharaType.VOCAL,
				Chara = Performer.GetCharacter(edit.Module3),
				PvCostume = edit.Module3,
				Back = edit.Module3Back,
				Face = edit.Module3Face,
				Neck = edit.Module3Chest,
				Zujo = edit.Module3Head
			});
		}
	}

	public void GetLyrics(Edit edit)
	{
		edit.EditLyrics.ForEach(delegate(EditLyric l)
		{
			string item = l.Lyrics ?? "";
			if (!Lyrics.Contains(item))
			{
				Lyrics.Add(item);
			}
		});
	}

	public void GetEffects(Edit edit)
	{
		edit.EditEffects.ForEach(delegate(EditEffect e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Invalid comparison between Unknown and I4
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			Effect effectID = e.EffectID;
			if (!Effects.Contains(effectID) && (int)effectID != -1)
			{
				Effects.Add(effectID);
			}
		});
	}

	public void GetHandItems(Edit edit)
	{
		edit.PlayerItemPlayer1s.ForEach(delegate(PlayerItem e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Invalid comparison between Unknown and I4
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			HandItem itemID3 = (HandItem)e.ItemID;
			if (Enum.IsDefined(typeof(HandItem), itemID3) && !HandItems.Contains(itemID3) && (int)itemID3 != -1)
			{
				HandItems.Add(itemID3);
			}
		});
		edit.PlayerItemPlayer2s.ForEach(delegate(PlayerItem e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Invalid comparison between Unknown and I4
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			HandItem itemID2 = (HandItem)e.ItemID;
			if (Enum.IsDefined(typeof(HandItem), itemID2) && !HandItems.Contains(itemID2) && (int)itemID2 != -1)
			{
				HandItems.Add(itemID2);
			}
		});
		edit.PlayerItemPlayer3s.ForEach(delegate(PlayerItem e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Invalid comparison between Unknown and I4
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			HandItem itemID = (HandItem)e.ItemID;
			if (Enum.IsDefined(typeof(HandItem), itemID) && !HandItems.Contains(itemID) && (int)itemID != -1)
			{
				HandItems.Add(itemID);
			}
		});
	}

	public void GetPvItems(Edit edit)
	{
		edit.PlayerItemPlayer1s.ForEach(delegate(PlayerItem e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Invalid comparison between Unknown and I4
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			InstrumentItem itemID3 = (InstrumentItem)e.ItemID;
			if (Enum.IsDefined(typeof(InstrumentItem), itemID3) && !PvItems.Contains(itemID3) && (int)itemID3 != -1)
			{
				PvItems.Add(itemID3);
			}
		});
		edit.PlayerItemPlayer2s.ForEach(delegate(PlayerItem e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Invalid comparison between Unknown and I4
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			InstrumentItem itemID2 = (InstrumentItem)e.ItemID;
			if (Enum.IsDefined(typeof(InstrumentItem), itemID2) && !PvItems.Contains(itemID2) && (int)itemID2 != -1)
			{
				PvItems.Add(itemID2);
			}
		});
		edit.PlayerItemPlayer3s.ForEach(delegate(PlayerItem e)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Invalid comparison between Unknown and I4
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			InstrumentItem itemID = (InstrumentItem)e.ItemID;
			if (Enum.IsDefined(typeof(InstrumentItem), itemID) && !PvItems.Contains(itemID) && (int)itemID != -1)
			{
				PvItems.Add(itemID);
			}
		});
	}

	public void GetStages(Edit edit)
	{
		edit.EditStages.ForEach(delegate(EditStage s)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Invalid comparison between Unknown and I4
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			Stage item = (((int)s.StageID1 == -1110002437) ? s.StageID3 : s.StageID1);
			if (!Stages.Contains(item))
			{
				Stages.Add(item);
			}
		});
	}

	public void GetMotions(Edit edit)
	{
		edit.PlayerMotionPlayer1s.ForEach(delegate(PlayerMotion m)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			string item3 = $"{m.MotionID1}";
			if (!Motions1P.Contains(item3))
			{
				Motions1P.Add(item3);
			}
		});
		edit.PlayerMotionPlayer2s.ForEach(delegate(PlayerMotion m)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			string item2 = $"{m.MotionID1}";
			if (!Motions2P.Contains(item2))
			{
				Motions2P.Add(item2);
			}
		});
		edit.PlayerMotionPlayer3s.ForEach(delegate(PlayerMotion m)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			string item = $"{m.MotionID1}";
			if (!Motions3P.Contains(item))
			{
				Motions3P.Add(item);
			}
		});
	}

	public List<string> GetPvDb()
	{
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0451: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a0: Expected I4, but got Unknown
		//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Expected I4, but got Unknown
		//IL_0559: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Expected I4, but got Unknown
		//IL_05dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0622: Unknown result type (might be due to invalid IL or missing references)
		//IL_062c: Expected I4, but got Unknown
		//IL_0661: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b0: Expected I4, but got Unknown
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " ---");
		stringBuilder.AppendLine($"{PvIdString}.bpm={BPM}");
		stringBuilder.AppendLine($"{PvIdString}.date={DateTime.Now.Year:D4}{DateTime.Now.Month:D2}{DateTime.Now.Day:D2}");
		ScriptFileName = $"rom/script/pv{PvId:D3}/{ScriptFileName}.dsc";
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.level={Level}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.script_file_name={ScriptFileName}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.script_format=0x00000000");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.version=1");
		stringBuilder.AppendLine($"# {PvIdString}.disp2d.set_name={PvId:D3}");
		stringBuilder.AppendLine("# " + PvIdString + ".edit_chara_scale=1");
		stringBuilder.AppendLine("# " + PvIdString + ".edit=2");
		for (int i = 0; i < Effects.Count; i++)
		{
			stringBuilder.AppendLine($"# edit_effect.{i:D2}.name={Effects[i]}");
			Effect val = Effects[i];
			if (Enum.TryParse<FtEditEffect>(((object)(Effect)(ref val)).ToString(), out var result))
			{
				stringBuilder.AppendLine($"{PvIdString}.edit_effect.{i:D2}={(int)result:D3}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.edit_effect.{i:D2}=666");
			}
		}
		stringBuilder.AppendLine(PvIdString + ".is_extra=1");
		for (int j = 0; j < Lyrics.Count; j++)
		{
			stringBuilder.AppendLine($"{PvIdString}.lyric.{j:D3}={Lyrics[j]}");
		}
		for (int k = 0; k < Motions1P.Count; k++)
		{
			stringBuilder.AppendLine($"{PvIdString}.motion.{k:D2}={Motions1P[k]}");
		}
		for (int l = 0; l < Motions2P.Count; l++)
		{
			stringBuilder.AppendLine($"{PvIdString}.motion2P.{l:D2}={Motions2P[l]}");
		}
		for (int m = 0; m < Motions3P.Count; m++)
		{
			stringBuilder.AppendLine($"{PvIdString}.motion3P.{m:D2}={Motions3P[m]}");
		}
		for (int n = 0; n < Performers.Count; n++)
		{
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.chara={Performers[n].Chara}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_back.name={Performers[n].Back}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_back={(int)Performers[n].Back}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_face.name={Performers[n].Face}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_face={(int)Performers[n].Face}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_neck.name={Performers[n].Neck}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_neck={(int)Performers[n].Neck}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_zujo.name={Performers[n].Zujo}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_zujo={(int)Performers[n].Zujo}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.pv_costume.name={Performers[n].PvCostume}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.pv_costume={(int)Performers[n].PvCostume}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.size={Performers[n].CharaSize}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.type={Performers[n].Type}");
		}
		stringBuilder.AppendLine($"{PvIdString}.performer.num={Performers.Count}");
		SongFileName = "rom/sound/song/" + SongFileName + ".ogg";
		stringBuilder.AppendLine(PvIdString + ".song_file_name=" + SongFileName);
		stringBuilder.AppendLine(PvIdString + ".song_name=" + SongName);
		stringBuilder.AppendLine(PvIdString + ".song_name_reading=" + PvIdString);
		stringBuilder.AppendLine(PvIdString + ".songinfo.arranger=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.lyrics=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.music=---");
		stringBuilder.AppendLine("# " + PvIdString + ".songinfo.pv_editor=" + PvEditor);
		stringBuilder.AppendLine($"{PvIdString}.sort_index={PvId:D3}");
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public List<string> GetFtPvDb()
	{
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Expected I4, but got Unknown
		//IL_03cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Expected I4, but got Unknown
		//IL_0923: Unknown result type (might be due to invalid IL or missing references)
		//IL_0945: Unknown result type (might be due to invalid IL or missing references)
		//IL_094b: Invalid comparison between Unknown and I4
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		//IL_0975: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a02: Expected I4, but got Unknown
		//IL_0f35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f66: Expected I4, but got Unknown
		//IL_0a39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a61: Invalid comparison between Unknown and I4
		//IL_0f8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f99: Expected I4, but got Unknown
		//IL_0a86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b18: Expected I4, but got Unknown
		//IL_0b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b77: Invalid comparison between Unknown and I4
		//IL_0b9c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2e: Expected I4, but got Unknown
		//IL_0c65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8d: Invalid comparison between Unknown and I4
		//IL_0cb2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d44: Expected I4, but got Unknown
		//IL_0d7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2e: Expected I4, but got Unknown
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " --- " + SongName);
		stringBuilder.AppendLine($"{PvIdString}.bpm={BPM}");
		stringBuilder.AppendLine($"{PvIdString}.date={DateTime.Now.Year:D4}{DateTime.Now.Month:D2}{DateTime.Now.Day:D2}");
		ScriptFileName = ("rom/script/" + ScriptFileName + ".dsc").Replace(' ', '_');
		Level = Level.Clamp(0, 20);
		string arg = $"PV_LV_{Level / 2:D2}_{((Level % 2 != 0) ? 5 : 0)}";
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.edition=0");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.level={arg}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.level_sort_index={PvId}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.script_file_name={ScriptFileName}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.script_format=0x00000000");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.version=1");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.length=1");
		stringBuilder.AppendLine("# --- EDIT ---");
		stringBuilder.AppendLine(PvIdString + ".edit=2");
		stringBuilder.AppendLine(PvIdString + ".edit_chara_scale=1");
		stringBuilder.AppendLine("# --- EFFECTS ---");
		for (int l = 0; l < Effects.Count; l++)
		{
			stringBuilder.AppendLine($"# edit_effect.{l:D2}.name={Effects[l]}");
			Effect val = Effects[l];
			if (Enum.TryParse<FtEditEffect>(((object)(Effect)(ref val)).ToString(), out var result))
			{
				stringBuilder.AppendLine($"{PvIdString}.edit_effect.{l:D2}={(int)result:D3}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.edit_effect.{l:D2}=666");
			}
		}
		stringBuilder.AppendLine("# --- FIELDS ---");
		AppendFields(stringBuilder);
		stringBuilder.AppendLine("# --- HAND ITEMS ---");
		for (int n = 0; n < HandItems.Count; n++)
		{
			stringBuilder.AppendLine($"# hand_item.{n + 1:D2}.name={HandItems[n]}");
			if (Enum.IsDefined(typeof(FtHandItem), (FtHandItem)(int)HandItems[n]))
			{
				stringBuilder.AppendLine($"{PvIdString}.hand_item.{n + 1:D2}={(FtHandItem)(int)HandItems[n]}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.hand_item.{n + 1:D2}=DUMMY");
			}
		}
		stringBuilder.AppendLine("# --- MODIFIERS ---");
		stringBuilder.AppendLine(PvIdString + ".hidden_timing=0.3");
		stringBuilder.AppendLine(PvIdString + ".high_speed_rate=4");
		stringBuilder.AppendLine("# --- LYRICS ---");
		if (Lyrics.Count > 0)
		{
			for (int num = 0; num < Lyrics.Count; num++)
			{
				stringBuilder.AppendLine($"{PvIdString}.lyric.{num:D3}={Lyrics[num]}");
			}
		}
		else
		{
			stringBuilder.AppendLine($"{PvIdString}.lyric.{0:D3}={string.Empty}");
		}
		stringBuilder.AppendLine("# --- MOTIONS ---");
		if (Performers.Count > 0)
		{
			int k;
			for (k = 0; k < Motions1P.Count; k++)
			{
				Settings.MotionEntry motionEntry = Settings.UserSettings.MotionLookup.FirstOrDefault((Settings.MotionEntry m) => m.InputMotion == Motions1P[k].ToString());
				if (!string.IsNullOrEmpty(motionEntry.InputMotion) && !string.IsNullOrEmpty(motionEntry.OutputMotion))
				{
					stringBuilder.AppendLine("# " + motionEntry.InputMotion + " => " + motionEntry.OutputMotion);
					stringBuilder.AppendLine($"{PvIdString}.motion.{k:D2}={motionEntry.OutputMotion}");
				}
				else
				{
					stringBuilder.AppendLine($"{PvIdString}.motion.{k:D2}={Motions1P[k]}");
				}
			}
		}
		if (Performers.Count > 1)
		{
			int j;
			for (j = 0; j < Motions2P.Count; j++)
			{
				Settings.MotionEntry motionEntry2 = Settings.UserSettings.MotionLookup.FirstOrDefault((Settings.MotionEntry m) => m.InputMotion == Motions2P[j].ToString());
				if (!string.IsNullOrEmpty(motionEntry2.InputMotion) && !string.IsNullOrEmpty(motionEntry2.OutputMotion))
				{
					stringBuilder.AppendLine("# " + motionEntry2.InputMotion + " => " + motionEntry2.OutputMotion);
					stringBuilder.AppendLine($"{PvIdString}.motion2P.{j:D2}={motionEntry2.OutputMotion}");
				}
				else
				{
					stringBuilder.AppendLine($"{PvIdString}.motion2P.{j:D2}={Motions2P[j]}");
				}
			}
		}
		if (Performers.Count > 2)
		{
			int i;
			for (i = 0; i < Motions3P.Count; i++)
			{
				Settings.MotionEntry motionEntry3 = Settings.UserSettings.MotionLookup.FirstOrDefault((Settings.MotionEntry m) => m.InputMotion == Motions3P[i].ToString());
				if (!string.IsNullOrEmpty(motionEntry3.InputMotion) && !string.IsNullOrEmpty(motionEntry3.OutputMotion))
				{
					stringBuilder.AppendLine("# " + motionEntry3.InputMotion + " => " + motionEntry3.OutputMotion);
					stringBuilder.AppendLine($"{PvIdString}.motion3P.{i:D2}={motionEntry3.OutputMotion}");
				}
				else
				{
					stringBuilder.AppendLine($"{PvIdString}.motion3P.{i:D2}={Motions3P[i]}");
				}
			}
		}
		stringBuilder.AppendLine("# --- PERFORMERS ---");
		for (int num2 = 0; num2 < Performers.Count; num2++)
		{
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.chara={Performers[num2].Chara}");
			stringBuilder.AppendLine($"# performer.{Performers[num2].Id}.item_back.name={Performers[num2].Back}");
			if ((int)Performers[num2].Back == 0)
			{
				stringBuilder.Append("# ");
			}
			CustomizeItem val2 = Performers[num2].Back;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result2))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_back={(int)result2}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_back={(int)Performers[num2].Back}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[num2].Id}.item_face.name={Performers[num2].Face}");
			if ((int)Performers[num2].Face == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[num2].Face;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result3))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_face={(int)result3}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_face={(int)Performers[num2].Face}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[num2].Id}.item_neck.name={Performers[num2].Neck}");
			if ((int)Performers[num2].Neck == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[num2].Neck;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result4))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_neck={(int)result4}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_neck={(int)Performers[num2].Neck}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[num2].Id}.item_zujo.name={Performers[num2].Zujo}");
			if ((int)Performers[num2].Zujo == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[num2].Zujo;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result5))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_zujo={(int)result5}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.item_zujo={(int)Performers[num2].Zujo}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[num2].Id}.pv_costume.name={Performers[num2].PvCostume}");
			Module pvCostume = Performers[num2].PvCostume;
			if (Enum.TryParse<FtModules>(((object)(Module)(ref pvCostume)).ToString(), out var result6))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.pv_costume={(int)result6}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.pv_costume={(int)Performers[num2].PvCostume}");
			}
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.size={Performers[num2].CharaSize}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[num2].Id}.type={Performers[num2].Type}");
		}
		stringBuilder.AppendLine($"{PvIdString}.performer.num={Performers.Count}");
		stringBuilder.AppendLine("# --- PV ITEMS ---");
		for (int num3 = 0; num3 < PvItems.Count; num3++)
		{
			stringBuilder.AppendLine($"# pv_item.{num3 + 1:D2}.name={PvItems[num3]}");
			if (Enum.IsDefined(typeof(FtPvItem), (FtPvItem)(int)PvItems[num3]))
			{
				stringBuilder.AppendLine($"{PvIdString}.pv_item.{num3 + 1:D2}={(FtPvItem)(int)PvItems[num3]}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.pv_item.{num3 + 1:D2}=DUMMY");
			}
		}
		stringBuilder.AppendLine("# --- SABI ---");
		stringBuilder.AppendLine(PvIdString + ".sabi.play_time=1.0");
		stringBuilder.AppendLine("# --- SOUND EFFECTS ---");
		stringBuilder.AppendLine(PvIdString + ".se_name=01_button1");
		stringBuilder.AppendLine(PvIdString + ".slide_name=slide_se13");
		stringBuilder.AppendLine(PvIdString + ".slidertouch_name=slide_windchime");
		stringBuilder.AppendLine("# --- SONG INFO ---");
		SongFileName = ("rom/sound/song/" + SongFileName + ".ogg").Replace(' ', '_');
		stringBuilder.AppendLine(PvIdString + ".song_file_name=" + SongFileName);
		stringBuilder.AppendLine(PvIdString + ".song_name=" + SongName);
		stringBuilder.AppendLine(PvIdString + ".song_name_reading=" + PvIdString);
		stringBuilder.AppendLine(PvIdString + ".songinfo.arranger=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.lyrics=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.music=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.pv_editor=" + PvEditor);
		stringBuilder.AppendLine("# --- MODIFIERS ---");
		stringBuilder.AppendLine(PvIdString + ".sudden_timing=0.6");
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public List<string> GetDiva2ndPvDb()
	{
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_049f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05be: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e6: Invalid comparison between Unknown and I4
		//IL_0507: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0610: Unknown result type (might be due to invalid IL or missing references)
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_069d: Expected I4, but got Unknown
		//IL_06d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fc: Invalid comparison between Unknown and I4
		//IL_0721: Unknown result type (might be due to invalid IL or missing references)
		//IL_0726: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Expected I4, but got Unknown
		//IL_07ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_080c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0812: Invalid comparison between Unknown and I4
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_083c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c9: Expected I4, but got Unknown
		//IL_0900: Unknown result type (might be due to invalid IL or missing references)
		//IL_0922: Unknown result type (might be due to invalid IL or missing references)
		//IL_0928: Invalid comparison between Unknown and I4
		//IL_094d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0952: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09df: Expected I4, but got Unknown
		//IL_0a15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac9: Expected I4, but got Unknown
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# DIVA 2nd EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " --- " + SongName);
		stringBuilder.AppendLine($"{PvIdString}.bpm={BPM}");
		stringBuilder.AppendLine($"{PvIdString}.date={DateTime.Now.Year:D4}{DateTime.Now.Month:D2}{DateTime.Now.Day:D2}");
		ScriptFileName = ("rom/script/" + ScriptFileName + ".dsc").Replace(' ', '_');
		Level = Level.Clamp(0, 20);
		string arg = $"PV_LV_{Level / 2:D2}_{((Level % 2 != 0) ? 5 : 0)}";
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.edition=0");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.level={arg}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.level_sort_index={PvId}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.script_file_name={ScriptFileName}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.script_format=0x00000000");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.version=1");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.length=1");
		stringBuilder.AppendLine("# --- EDIT ---");
		stringBuilder.AppendLine(PvIdString + ".disable_calc_motfrm_limit=1");
		stringBuilder.AppendLine(PvIdString + ".edit=1");
		stringBuilder.AppendLine(PvIdString + ".edit_chara_scale=1");
		stringBuilder.AppendLine("# --- EFFECTS ---");
		for (int i = 0; i < Diva2ndEffects.Count; i++)
		{
			Effect val = Diva2ndEffects[i];
			int.TryParse(((object)(Effect)(ref val)).ToString().Substring("aet_gam_eff".Length), out var result);
			stringBuilder.AppendLine($"{PvIdString}.edit_effect.{i:D2}={result:D3}");
		}
		stringBuilder.AppendLine("# --- FIELDS ---");
		AppendDiva2ndFields(stringBuilder);
		stringBuilder.AppendLine("# --- HAND ITEMS ---");
		for (int j = 0; j < Diva2ndHandItems.Count; j++)
		{
			stringBuilder.AppendLine($"{PvIdString}.hand_item.{j + 1:D2}={Diva2ndHandItems[j]}");
		}
		stringBuilder.AppendLine("# --- MODIFIERS ---");
		stringBuilder.AppendLine(PvIdString + ".hidden_timing=0.3");
		stringBuilder.AppendLine(PvIdString + ".high_speed_rate=4");
		stringBuilder.AppendLine(PvIdString + ".is_old_pv=1");
		stringBuilder.AppendLine("# --- LYRICS ---");
		if (Lyrics.Count > 0)
		{
			for (int k = 0; k < Lyrics.Count; k++)
			{
				stringBuilder.AppendLine($"{PvIdString}.lyric.{k + 1:D3}={Lyrics[k]}");
			}
		}
		else
		{
			stringBuilder.AppendLine($"{PvIdString}.lyric.{0:D3}={string.Empty}");
		}
		stringBuilder.AppendLine("# --- MOTIONS ---");
		if (Performers.Count > 0)
		{
			for (int l = 0; l < Diva2ndMotions.Count; l++)
			{
				stringBuilder.AppendLine($"{PvIdString}.motion.{l:D2}={Diva2ndMotions[l]}");
			}
		}
		if (Performers.Count > 1)
		{
			for (int m = 0; m < Diva2ndMotions.Count; m++)
			{
				stringBuilder.AppendLine($"{PvIdString}.motion2P.{m:D2}={Diva2ndMotions[m]}");
			}
		}
		stringBuilder.AppendLine("# --- PERFORMERS ---");
		for (int n = 0; n < Performers.Count; n++)
		{
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.chara={Performers[n].Chara}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_back.name={Performers[n].Back}");
			if ((int)Performers[n].Back == 0)
			{
				stringBuilder.Append("# ");
			}
			CustomizeItem val2 = Performers[n].Back;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result2))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_back={(int)result2}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_back={(int)Performers[n].Back}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_face.name={Performers[n].Face}");
			if ((int)Performers[n].Face == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[n].Face;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result3))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_face={(int)result3}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_face={(int)Performers[n].Face}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_neck.name={Performers[n].Neck}");
			if ((int)Performers[n].Neck == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[n].Neck;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result4))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_neck={(int)result4}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_neck={(int)Performers[n].Neck}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_zujo.name={Performers[n].Zujo}");
			if ((int)Performers[n].Zujo == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[n].Zujo;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result5))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_zujo={(int)result5}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_zujo={(int)Performers[n].Zujo}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.pv_costume.name={Performers[n].PvCostume}");
			Module pvCostume = Performers[n].PvCostume;
			if (Enum.TryParse<FtModules>(((object)(Module)(ref pvCostume)).ToString(), out var result6))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.pv_costume={(int)result6}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.pv_costume={(int)Performers[n].PvCostume}");
			}
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.size={Performers[n].CharaSize}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.type={Performers[n].Type}");
		}
		stringBuilder.AppendLine($"{PvIdString}.performer.num={Performers.Count}");
		stringBuilder.AppendLine("# --- SABI ---");
		stringBuilder.AppendLine(PvIdString + ".sabi.play_time=1.0");
		stringBuilder.AppendLine("# --- SOUND EFFECTS ---");
		stringBuilder.AppendLine(PvIdString + ".se_name=" + SeName);
		stringBuilder.AppendLine(PvIdString + ".slide_name=slide_se13");
		stringBuilder.AppendLine(PvIdString + ".slidertouch_name=slide_windchime");
		stringBuilder.AppendLine("# --- SONG INFO ---");
		SongFileName = ("rom/sound/song/" + SongFileName + ".ogg").Replace(' ', '_');
		stringBuilder.AppendLine(PvIdString + ".song_file_name=" + SongFileName);
		stringBuilder.AppendLine(PvIdString + ".song_name=" + SongName);
		stringBuilder.AppendLine(PvIdString + ".song_name_reading=" + PvIdString);
		stringBuilder.AppendLine(PvIdString + ".songinfo.arranger=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.lyrics=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.music=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.pv_editor=" + PvEditor);
		stringBuilder.AppendLine("# --- MODIFIERS ---");
		stringBuilder.AppendLine(PvIdString + ".sudden_timing=0.6");
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public List<string> GetDivaExtendPvDb()
	{
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_049f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05be: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e6: Invalid comparison between Unknown and I4
		//IL_0507: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0610: Unknown result type (might be due to invalid IL or missing references)
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_069d: Expected I4, but got Unknown
		//IL_06d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fc: Invalid comparison between Unknown and I4
		//IL_0721: Unknown result type (might be due to invalid IL or missing references)
		//IL_0726: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Expected I4, but got Unknown
		//IL_07ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_080c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0812: Invalid comparison between Unknown and I4
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_083c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c9: Expected I4, but got Unknown
		//IL_0900: Unknown result type (might be due to invalid IL or missing references)
		//IL_0922: Unknown result type (might be due to invalid IL or missing references)
		//IL_0928: Invalid comparison between Unknown and I4
		//IL_094d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0952: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09df: Expected I4, but got Unknown
		//IL_0a15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac9: Expected I4, but got Unknown
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# DIVA Extend EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " --- " + SongName);
		stringBuilder.AppendLine($"{PvIdString}.bpm={BPM}");
		stringBuilder.AppendLine($"{PvIdString}.date={DateTime.Now.Year:D4}{DateTime.Now.Month:D2}{DateTime.Now.Day:D2}");
		ScriptFileName = ("rom/script/" + ScriptFileName + ".dsc").Replace(' ', '_');
		Level = Level.Clamp(0, 20);
		string arg = $"PV_LV_{Level / 2:D2}_{((Level % 2 != 0) ? 5 : 0)}";
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.edition=0");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.level={arg}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.level_sort_index={PvId}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.script_file_name={ScriptFileName}");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.script_format=0x00000000");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.0.version=1");
		stringBuilder.AppendLine($"{PvIdString}.difficulty.{Difficulty}.length=1");
		stringBuilder.AppendLine("# --- EDIT ---");
		stringBuilder.AppendLine(PvIdString + ".disable_calc_motfrm_limit=1");
		stringBuilder.AppendLine(PvIdString + ".edit=1");
		stringBuilder.AppendLine(PvIdString + ".edit_chara_scale=1");
		stringBuilder.AppendLine("# --- EFFECTS ---");
		for (int i = 0; i < DivaExtendEffects.Count; i++)
		{
			Effect val = DivaExtendEffects[i];
			int.TryParse(((object)(Effect)(ref val)).ToString().Substring("aet_gam_eff".Length), out var result);
			stringBuilder.AppendLine($"{PvIdString}.edit_effect.{i:D2}={result:D3}");
		}
		stringBuilder.AppendLine("# --- FIELDS ---");
		AppendDivaExtendFields(stringBuilder);
		stringBuilder.AppendLine("# --- HAND ITEMS ---");
		for (int j = 0; j < DivaExtendHandItems.Count; j++)
		{
			stringBuilder.AppendLine($"{PvIdString}.hand_item.{j + 1:D2}={DivaExtendHandItems[j]}");
		}
		stringBuilder.AppendLine("# --- MODIFIERS ---");
		stringBuilder.AppendLine(PvIdString + ".hidden_timing=0.3");
		stringBuilder.AppendLine(PvIdString + ".high_speed_rate=4");
		stringBuilder.AppendLine(PvIdString + ".is_old_pv=1");
		stringBuilder.AppendLine("# --- LYRICS ---");
		if (Lyrics.Count > 0)
		{
			for (int k = 0; k < Lyrics.Count; k++)
			{
				stringBuilder.AppendLine($"{PvIdString}.lyric.{k + 1:D3}={Lyrics[k]}");
			}
		}
		else
		{
			stringBuilder.AppendLine($"{PvIdString}.lyric.{0:D3}={string.Empty}");
		}
		stringBuilder.AppendLine("# --- MOTIONS ---");
		if (Performers.Count > 0)
		{
			for (int l = 0; l < DivaExtendMotions.Count; l++)
			{
				stringBuilder.AppendLine($"{PvIdString}.motion.{l:D2}={DivaExtendMotions[l]}");
			}
		}
		if (Performers.Count > 1)
		{
			for (int m = 0; m < DivaExtendMotions.Count; m++)
			{
				stringBuilder.AppendLine($"{PvIdString}.motion2P.{m:D2}={DivaExtendMotions[m]}");
			}
		}
		stringBuilder.AppendLine("# --- PERFORMERS ---");
		for (int n = 0; n < Performers.Count; n++)
		{
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.chara={Performers[n].Chara}");
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_back.name={Performers[n].Back}");
			if ((int)Performers[n].Back == 0)
			{
				stringBuilder.Append("# ");
			}
			CustomizeItem val2 = Performers[n].Back;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result2))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_back={(int)result2}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_back={(int)Performers[n].Back}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_face.name={Performers[n].Face}");
			if ((int)Performers[n].Face == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[n].Face;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result3))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_face={(int)result3}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_face={(int)Performers[n].Face}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_neck.name={Performers[n].Neck}");
			if ((int)Performers[n].Neck == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[n].Neck;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result4))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_neck={(int)result4}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_neck={(int)Performers[n].Neck}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.item_zujo.name={Performers[n].Zujo}");
			if ((int)Performers[n].Zujo == 0)
			{
				stringBuilder.Append("# ");
			}
			val2 = Performers[n].Zujo;
			if (Enum.TryParse<FtCustomizeItem>(((object)(CustomizeItem)(ref val2)).ToString(), out var result5))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_zujo={(int)result5}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.item_zujo={(int)Performers[n].Zujo}");
			}
			stringBuilder.AppendLine($"# performer.{Performers[n].Id}.pv_costume.name={Performers[n].PvCostume}");
			Module pvCostume = Performers[n].PvCostume;
			if (Enum.TryParse<FtModules>(((object)(Module)(ref pvCostume)).ToString(), out var result6))
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.pv_costume={(int)result6}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.pv_costume={(int)Performers[n].PvCostume}");
			}
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.size={Performers[n].CharaSize}");
			stringBuilder.AppendLine($"{PvIdString}.performer.{Performers[n].Id}.type={Performers[n].Type}");
		}
		stringBuilder.AppendLine($"{PvIdString}.performer.num={Performers.Count}");
		stringBuilder.AppendLine("# --- SABI ---");
		stringBuilder.AppendLine(PvIdString + ".sabi.play_time=1.0");
		stringBuilder.AppendLine("# --- SOUND EFFECTS ---");
		stringBuilder.AppendLine(PvIdString + ".se_name=" + SeName);
		stringBuilder.AppendLine(PvIdString + ".slide_name=slide_se13");
		stringBuilder.AppendLine(PvIdString + ".slidertouch_name=slide_windchime");
		stringBuilder.AppendLine("# --- SONG INFO ---");
		SongFileName = ("rom/sound/song/" + SongFileName + ".ogg").Replace(' ', '_');
		stringBuilder.AppendLine(PvIdString + ".song_file_name=" + SongFileName);
		stringBuilder.AppendLine(PvIdString + ".song_name=" + SongName);
		stringBuilder.AppendLine(PvIdString + ".song_name_reading=" + PvIdString);
		stringBuilder.AppendLine(PvIdString + ".songinfo.arranger=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.lyrics=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.music=---");
		stringBuilder.AppendLine(PvIdString + ".songinfo.pv_editor=" + PvEditor);
		stringBuilder.AppendLine("# --- MODIFIERS ---");
		stringBuilder.AppendLine(PvIdString + ".sudden_timing=0.6");
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	private void AppendFields(StringBuilder stringBuilder)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Expected I4, but got Unknown
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Expected I4, but got Unknown
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		int i;
		for (i = 0; i < Stages.Count; i++)
		{
			string text = (Enum.IsDefined(typeof(SprEditFtStages), (SprEditFtStages)(int)Stages[i]) ? "spr_set_back" : "stage");
			stringBuilder.AppendLine($"# field.{i + 1:D2}.name={(object)(StageName)Stages[i]}");
			Settings.FieldEntry fieldEntry = Settings.UserSettings.FieldLookup.FirstOrDefault(delegate(Settings.FieldEntry f)
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				//IL_001c: Unknown result type (might be due to invalid IL or missing references)
				string inputField = f.InputField;
				Stage val = Stages[i];
				return inputField == ((object)(Stage)(ref val)).ToString();
			});
			if (fieldEntry.InputField != null && fieldEntry.OutputFields != null && fieldEntry.OutputFields.Count > 0)
			{
				if (fieldEntry.OutputFields.Count == 1 && !fieldEntry.OutputFields[0].Contains("="))
				{
					stringBuilder.AppendLine($"# {Stages[i]} => {fieldEntry.OutputFields[0]}");
					stringBuilder.AppendLine($"{PvIdString}.field.{i + 1:D2}.{text}={fieldEntry.OutputFields[0]}");
					continue;
				}
				string text2 = fieldEntry.OutputFields.LastOrDefault((string f) => f.Contains("stage="));
				if (text2 != null)
				{
					string[] array = text2.Split(new char[1] { '=' }, 2);
					if (array.Length > 1)
					{
						stringBuilder.AppendLine($"# {Stages[i]} => {array[1]}");
					}
				}
				foreach (string outputField in fieldEntry.OutputFields)
				{
					stringBuilder.AppendLine($"{PvIdString}.field.{i + 1:D2}.{outputField}");
				}
			}
			else if (text == "spr_set_back")
			{
				string name = Enum.GetName(typeof(SprEditFtStages), (SprEditFtStages)(int)Stages[i]);
				stringBuilder.AppendLine($"{PvIdString}.field.{i + 1:D2}.{text}={name}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.field.{i + 1:D2}.{text}={Stages[i]}");
			}
		}
		stringBuilder.AppendLine($"{PvIdString}.field.length={Stages.Count}");
	}

	private void AppendDiva2ndFields(StringBuilder stringBuilder)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < Diva2ndStages.Count; i++)
		{
			string text = (Enum.IsDefined(typeof(StageBack), (object)(StageBack)Diva2ndStages[i]) ? "spr_set_back" : "stage");
			object[] obj = new object[4]
			{
				PvIdString,
				i + 1,
				text,
				null
			};
			Stage val = Diva2ndStages[i];
			obj[3] = ((object)(Stage)(ref val)).ToString().ToUpper();
			stringBuilder.AppendLine(string.Format("{0}.field.{1:D2}.{2}={3}", obj));
		}
		stringBuilder.AppendLine($"{PvIdString}.field.length={Diva2ndStages.Count}");
	}

	private void AppendDivaExtendFields(StringBuilder stringBuilder)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < DivaExtendStages.Count; i++)
		{
			string text = (Enum.IsDefined(typeof(StageBack), (object)(StageBack)DivaExtendStages[i]) ? "spr_set_back" : "stage");
			object[] obj = new object[4]
			{
				PvIdString,
				i + 1,
				text,
				null
			};
			Stage val = DivaExtendStages[i];
			obj[3] = ((object)(Stage)(ref val)).ToString().ToUpper();
			stringBuilder.AppendLine(string.Format("{0}.field.{1:D2}.{2}={3}", obj));
		}
		stringBuilder.AppendLine($"{PvIdString}.field.length={DivaExtendStages.Count}");
	}

	public List<string> GetFieldDb()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Expected I4, but got Unknown
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Expected I4, but got Unknown
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " ---");
		for (int i = 0; i < Stages.Count; i++)
		{
			string text = (Enum.IsDefined(typeof(SprEditFtStages), (SprEditFtStages)(int)Stages[i]) ? "spr_set_back" : "stage");
			stringBuilder.AppendLine($"# field.{i + 1:D2}.name={(object)(StageName)Stages[i]}");
			if (text == "spr_set_back")
			{
				string name = Enum.GetName(typeof(SprEditFtStages), (SprEditFtStages)(int)Stages[i]);
				stringBuilder.AppendLine($"{PvIdString}.field.{i + 1:D2}.{text}={name}");
			}
			else
			{
				stringBuilder.AppendLine($"{PvIdString}.field.{i + 1:D2}.{text}={Stages[i]}");
			}
		}
		stringBuilder.AppendLine($"{PvIdString}.field.length={Stages.Count}");
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public List<string> GetFtFieldDb()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " ---");
		AppendFields(stringBuilder);
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public List<string> GetDiva2ndFieldDb()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# DIVA 2nd EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " ---");
		AppendDiva2ndFields(stringBuilder);
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public List<string> GetDivaExtendFieldDb()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# DIVA Extend EditScript.Import : " + DateTime.Now.ToShortDateString());
		stringBuilder.AppendLine("# --- " + PvIdString.ToUpper() + " ---");
		AppendDivaExtendFields(stringBuilder);
		stringBuilder.AppendLine("# --- EOF ---");
		return SortDbStrings(stringBuilder.ToString());
	}

	public static List<string> SortDbStrings(string unsorted)
	{
		List<string> list = new List<string>();
		list.AddRange(unsorted.Replace("\r", "").Split(new char[1] { '\n' }));
		list.OrderBy((string s) => s);
		return list;
	}
}
