using System;
using System.Collections.Generic;
using System.Linq;
using EditMode;

namespace ScriptUtilities;

public static class EditTime
{
	public static int DivaTimeFromTimelineIndex(ushort bar, ushort beat, List<BpmChange> bpmChanges, List<TimeSigChange> sigChanges)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected I4, but got Unknown
		if (bpmChanges.Count < 1)
		{
			return 0;
		}
		float bPM = bpmChanges[0].BPM;
		int num = sigChanges[0].Signature + 1;
		double num2 = 0.0;
		for (int i = 0; i < bar; i++)
		{
			bPM = GetBpmAt(i, bpmChanges);
			num = GetSigAt(i, sigChanges);
			num2 += (double)(60f / bPM * (float)(num + 1));
		}
		bPM = GetBpmAt(bar, bpmChanges);
		num = GetSigAt(bar, sigChanges);
		if (beat != 0)
		{
			num2 += (double)(60f / bPM / 192f * (float)(num + 1) * (float)(int)beat);
		}
		return (int)(num2 * 100000.0);
	}

	public static int DivaTimeFromNormalizedTimelineIndex(ushort bar, ushort beat, List<BpmChange> bpmChanges)
	{
		if (bpmChanges.Count < 1)
		{
			return 0;
		}
		TimelineIndex timelineIndex = new TimelineIndex(bar, beat);
		double num = bpmChanges[0].BPM;
		double num2 = 0.0;
		int totalBeats = timelineIndex.TotalBeats;
		int num3 = 0;
		for (num3 = 0; num3 < totalBeats; num3 += 48)
		{
			num = GetBpmAt(TimelineIndex.FromBeats(num3), bpmChanges).BPM;
			num2 += 60.0 / num;
		}
		if (num3 > totalBeats)
		{
			int num4 = totalBeats - num3;
			num2 += 60.0 / num / 192.0 * 4.0 * (double)num4;
		}
		return (int)(num2 * 100000.0);
	}

	private static BpmChange GetBpmAt(TimelineIndex index, List<BpmChange> bpmChanges)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Expected O, but got Unknown
		if (bpmChanges.Count < 1)
		{
			return new BpmChange
			{
				BPM = 0f
			};
		}
		BpmChange result = bpmChanges[0];
		for (int i = 0; i < bpmChanges.Count && new TimelineIndex(bpmChanges[i].BarIndex, bpmChanges[i].BeatIndex) <= index; i++)
		{
			result = bpmChanges[i];
		}
		return result;
	}

	private static TimeSigChange GetSigAt(TimelineIndex index, List<TimeSigChange> timeSigChanges)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		if (timeSigChanges.Count < 1)
		{
			return new TimeSigChange
			{
				Signature = (TimeSig)3
			};
		}
		TimeSigChange result = timeSigChanges[0];
		for (int i = 0; i < timeSigChanges.Count && new TimelineIndex(timeSigChanges[i].BarIndex, timeSigChanges[i].BeatIndex) <= index; i++)
		{
			result = timeSigChanges[i];
		}
		return result;
	}

	private static float GetBpmAt(int bar, List<BpmChange> bpmChanges)
	{
		if (bpmChanges.Count < 1)
		{
			return 0f;
		}
		BpmChange val = ((IEnumerable<BpmChange>)bpmChanges).LastOrDefault((Func<BpmChange, bool>)((BpmChange b) => b.BarIndex <= bar));
		return (val != null) ? val.BPM : bpmChanges[0].BPM;
	}

	public static int GetSigAt(int bar, List<TimeSigChange> sigChanges)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected I4, but got Unknown
		if (sigChanges.Count < 1)
		{
			return 0;
		}
		TimeSigChange val = ((IEnumerable<TimeSigChange>)sigChanges).LastOrDefault((Func<TimeSigChange, bool>)((TimeSigChange s) => s.BarIndex <= bar));
		return (int)((val != null) ? val.Signature : sigChanges[0].Signature);
	}

	public static void NormalizeTimelineIndexes(Edit edit)
	{
		TimeSigChange[] array = (TimeSigChange[])(object)new TimeSigChange[edit.TimeSigChanges.Count];
		edit.TimeSigChanges.CopyTo(array);
		List<TimeSigChange> timeSigChanges2 = array.ToList();
		foreach (EditTarget editTarget in edit.EditTargets)
		{
			TimelineIndex timelineIndex = NormalizeIndex(new TimelineIndex(editTarget.BarIndex, editTarget.BeatIndex), timeSigChanges2);
			editTarget.BarIndex = (ushort)timelineIndex.Bar;
			editTarget.BeatIndex = (ushort)timelineIndex.Beat;
			timelineIndex = NormalizeIndex(new TimelineIndex(editTarget.HoldEndBar, editTarget.HoldEndBeat), timeSigChanges2);
			editTarget.HoldEndBar = (ushort)timelineIndex.Bar;
			editTarget.HoldEndBeat = (ushort)timelineIndex.Beat;
		}
		foreach (BpmChange bPMChange in edit.BPMChanges)
		{
			TimelineIndex timelineIndex2 = NormalizeIndex(new TimelineIndex((int)bPMChange.BarIndex), timeSigChanges2);
			bPMChange.BarIndex = (uint)timelineIndex2.Bar;
			bPMChange.BeatIndex = (uint)timelineIndex2.Beat;
		}
		foreach (TimeSigChange timeSigChange in edit.TimeSigChanges)
		{
			TimelineIndex timelineIndex3 = NormalizeIndex(new TimelineIndex((int)timeSigChange.BarIndex), timeSigChanges2);
			timeSigChange.BarIndex = (uint)timelineIndex3.Bar;
			timeSigChange.BeatIndex = (uint)timelineIndex3.Beat;
		}
		static int GetSigAt(TimelineIndex index, List<TimeSigChange> timeSigChanges)
		{
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Expected I4, but got Unknown
			if (timeSigChanges.Count < 1)
			{
				return 0;
			}
			TimeSigChange val = timeSigChanges[0];
			for (int i = 0; i < timeSigChanges.Count && timeSigChanges[i].BarIndex <= index.Bar; i++)
			{
				val = timeSigChanges[i];
			}
			return (int)val.Signature;
		}
		static TimelineIndex NormalizeIndex(TimelineIndex index, List<TimeSigChange> timeSigChanges)
		{
			int totalBeats = index.TotalBeats;
			int num = 0;
			for (int j = 0; j < index.Bar; j++)
			{
				int sigAt = GetSigAt(new TimelineIndex(j), timeSigChanges);
				num += 48 * (sigAt + 1);
			}
			num += index.Beat;
			return TimelineIndex.FromBeats(num);
		}
	}
}
