namespace ScriptUtilities;

public enum DifficultyLevel
{
	easy,
	normal,
	hard,
	extreme,
	encore
}
