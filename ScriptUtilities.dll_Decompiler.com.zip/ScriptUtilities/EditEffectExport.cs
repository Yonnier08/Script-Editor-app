using System;
using System.Collections.Generic;
using System.Text;
using EditMode;

namespace ScriptUtilities;

public static class EditEffectExport
{
	public static void AppendFtEditEffects(StringBuilder sb, string pvIdString, IList<Effect> effects)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (effects == null)
		{
			return;
		}
		for (int i = 0; i < effects.Count; i++)
		{
			sb.AppendLine($"# edit_effect.{i:D2}.name={effects[i]}");
			Effect val = effects[i];
			if (Enum.TryParse<FtEditEffect>(((object)(Effect)(ref val)).ToString(), out var result))
			{
				sb.AppendLine($"{pvIdString}.edit_effect.{i:D2}={(int)result:D3}");
			}
			else
			{
				sb.AppendLine($"{pvIdString}.edit_effect.{i:D2}=666");
			}
		}
	}

	public static void AppendDiva2ndEditEffects(StringBuilder sb, string pvIdString, IList<string> diva2ndEffects)
	{
		if (diva2ndEffects == null)
		{
			return;
		}
		for (int i = 0; i < diva2ndEffects.Count; i++)
		{
			int result = 0;
			string text = diva2ndEffects[i] ?? string.Empty;
			if (text.StartsWith("aet_gam_eff", StringComparison.OrdinalIgnoreCase))
			{
				string s = text.Substring("aet_gam_eff".Length);
				int.TryParse(s, out result);
			}
			sb.AppendLine($"{pvIdString}.edit_effect.{i:D2}={result:D3}");
		}
	}
}
