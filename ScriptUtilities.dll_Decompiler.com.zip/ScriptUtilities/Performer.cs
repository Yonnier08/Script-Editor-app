using System;
using EditMode;

namespace ScriptUtilities;

public class Performer
{
	public enum Character : short
	{
		MIKU,
		MIK,
		RIN,
		LEN,
		LUKA,
		LUK,
		NERU,
		NER,
		HAKU,
		HAK,
		KAITO,
		KAI,
		MEIKO,
		MEI,
		SAKINE,
		SAK,
		TETO,
		TET,
		EXTRA,
		EXT
	}

	public enum CharaType : short
	{
		GUEST,
		PSEUDO_DEFAULT,
		PSEUDO_MYCHARA,
		PSEUDO_SAME,
		PSEUDO_SWIM,
		PSEUDO_SWIM_S,
		VOCAL
	}

	public enum Size : short
	{
		NORMAL,
		PLAY_CHARA,
		PV_CHARA,
		SHORT,
		TALL
	}

	public int Id { get; set; } = 0;


	public bool Exclude { get; set; }

	public bool Fixed { get; set; }

	public CustomizeItem Back { get; set; } = (CustomizeItem)0;


	public CustomizeItem Face { get; set; } = (CustomizeItem)0;


	public CustomizeItem Neck { get; set; } = (CustomizeItem)0;


	public CustomizeItem Zujo { get; set; } = (CustomizeItem)0;


	public Character Chara { get; set; } = Character.MIK;


	public Module PvCostume { get; set; } = (Module)0;


	public Size CharaSize
	{
		get
		{
			switch (Chara)
			{
			case Character.MIKU:
			case Character.MIK:
			case Character.LUKA:
			case Character.LUK:
			case Character.HAKU:
			case Character.HAK:
			case Character.SAKINE:
			case Character.SAK:
			case Character.TETO:
			case Character.TET:
			case Character.EXTRA:
			case Character.EXT:
				return Size.NORMAL;
			case Character.RIN:
			case Character.LEN:
			case Character.NERU:
			case Character.NER:
				return Size.SHORT;
			case Character.KAITO:
			case Character.KAI:
			case Character.MEIKO:
			case Character.MEI:
				return Size.TALL;
			default:
				return Size.NORMAL;
			}
		}
	}

	public CharaType Type { get; set; } = CharaType.VOCAL;


	public static Character GetCharacter(Module module)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Expected I4, but got Unknown
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Invalid comparison between Unknown and I4
		//IL_0abe: Unknown result type (might be due to invalid IL or missing references)
		switch ((int)module)
		{
		default:
			if ((int)module != 65535)
			{
				break;
			}
			throw new InvalidOperationException($"Module type {module} does not contain a character definition.");
		case 0:
			return Character.MIK;
		case 1:
			return Character.MIK;
		case 10:
			return Character.MIK;
		case 104:
			return Character.MIK;
		case 105:
			return Character.MIK;
		case 106:
			return Character.MIK;
		case 107:
			return Character.MIK;
		case 108:
			return Character.MIK;
		case 109:
			return Character.MIK;
		case 110:
			return Character.MIK;
		case 111:
			return Character.MIK;
		case 112:
			return Character.MIK;
		case 113:
			return Character.MIK;
		case 11:
			return Character.MIK;
		case 114:
			return Character.MIK;
		case 115:
			return Character.MIK;
		case 116:
			return Character.MIK;
		case 117:
			return Character.MIK;
		case 118:
			return Character.MIK;
		case 119:
			return Character.MIK;
		case 120:
			return Character.MIK;
		case 121:
			return Character.MIK;
		case 122:
			return Character.MIK;
		case 123:
			return Character.MIK;
		case 12:
			return Character.MIK;
		case 124:
			return Character.MIK;
		case 125:
			return Character.MIK;
		case 126:
			return Character.MIK;
		case 127:
			return Character.MIK;
		case 128:
			return Character.MIK;
		case 129:
			return Character.MIK;
		case 130:
			return Character.MIK;
		case 131:
			return Character.MIK;
		case 132:
			return Character.MIK;
		case 133:
			return Character.MIK;
		case 13:
			return Character.MIK;
		case 134:
			return Character.MIK;
		case 135:
			return Character.MIK;
		case 136:
			return Character.MIK;
		case 137:
			return Character.MIK;
		case 138:
			return Character.MIK;
		case 139:
			return Character.MIK;
		case 140:
			return Character.MIK;
		case 189:
			return Character.MIK;
		case 198:
			return Character.MIK;
		case 217:
			return Character.MIK;
		case 205:
			return Character.MIK;
		case 206:
			return Character.MIK;
		case 207:
			return Character.MIK;
		case 208:
			return Character.MIK;
		case 209:
			return Character.MIK;
		case 210:
			return Character.MIK;
		case 211:
			return Character.MIK;
		case 212:
			return Character.MIK;
		case 213:
			return Character.MIK;
		case 214:
			return Character.MIK;
		case 215:
			return Character.MIK;
		case 216:
			return Character.MIK;
		case 218:
			return Character.MIK;
		case 219:
			return Character.MIK;
		case 248:
			return Character.MIK;
		case 141:
			return Character.RIN;
		case 142:
			return Character.RIN;
		case 143:
			return Character.RIN;
		case 14:
			return Character.MIK;
		case 144:
			return Character.RIN;
		case 145:
			return Character.RIN;
		case 146:
			return Character.RIN;
		case 147:
			return Character.RIN;
		case 148:
			return Character.RIN;
		case 149:
			return Character.RIN;
		case 150:
			return Character.RIN;
		case 190:
			return Character.RIN;
		case 199:
			return Character.RIN;
		case 223:
			return Character.RIN;
		case 220:
			return Character.RIN;
		case 221:
			return Character.RIN;
		case 222:
			return Character.RIN;
		case 151:
			return Character.LEN;
		case 152:
			return Character.LEN;
		case 153:
			return Character.LEN;
		case 15:
			return Character.MIK;
		case 154:
			return Character.LEN;
		case 155:
			return Character.LEN;
		case 156:
			return Character.LEN;
		case 157:
			return Character.LEN;
		case 158:
			return Character.LEN;
		case 159:
			return Character.LEN;
		case 160:
			return Character.LEN;
		case 191:
			return Character.LEN;
		case 200:
			return Character.LEN;
		case 226:
			return Character.LEN;
		case 224:
			return Character.LEN;
		case 225:
			return Character.LEN;
		case 161:
			return Character.LUK;
		case 162:
			return Character.LUK;
		case 163:
			return Character.LUK;
		case 16:
			return Character.MIK;
		case 164:
			return Character.LUK;
		case 165:
			return Character.LUK;
		case 166:
			return Character.LUK;
		case 167:
			return Character.LUK;
		case 168:
			return Character.LUK;
		case 169:
			return Character.LUK;
		case 170:
			return Character.LUK;
		case 192:
			return Character.LUK;
		case 201:
			return Character.LUK;
		case 231:
			return Character.LUK;
		case 227:
			return Character.LUK;
		case 228:
			return Character.LUK;
		case 229:
			return Character.LUK;
		case 230:
			return Character.LUK;
		case 232:
			return Character.LUK;
		case 171:
			return Character.KAI;
		case 172:
			return Character.KAI;
		case 173:
			return Character.KAI;
		case 17:
			return Character.MIK;
		case 174:
			return Character.KAI;
		case 175:
			return Character.KAI;
		case 176:
			return Character.KAI;
		case 177:
			return Character.KAI;
		case 178:
			return Character.KAI;
		case 179:
			return Character.KAI;
		case 193:
			return Character.KAI;
		case 202:
			return Character.KAI;
		case 236:
			return Character.KAI;
		case 203:
			return Character.KAI;
		case 237:
			return Character.KAI;
		case 233:
			return Character.KAI;
		case 234:
			return Character.KAI;
		case 235:
			return Character.KAI;
		case 180:
			return Character.MEI;
		case 181:
			return Character.MEI;
		case 182:
			return Character.MEI;
		case 183:
			return Character.MEI;
		case 18:
			return Character.MIK;
		case 184:
			return Character.MEI;
		case 185:
			return Character.MEI;
		case 186:
			return Character.MEI;
		case 188:
			return Character.LUK;
		case 19:
			return Character.MIK;
		case 2:
			return Character.MIK;
		case 20:
			return Character.MIK;
		case 21:
			return Character.MIK;
		case 22:
			return Character.MIK;
		case 23:
			return Character.MIK;
		case 24:
			return Character.MIK;
		case 25:
			return Character.MIK;
		case 26:
			return Character.MIK;
		case 27:
			return Character.RIN;
		case 28:
			return Character.RIN;
		case 29:
			return Character.RIN;
		case 3:
			return Character.MIK;
		case 30:
			return Character.RIN;
		case 31:
			return Character.RIN;
		case 32:
			return Character.RIN;
		case 33:
			return Character.RIN;
		case 34:
			return Character.RIN;
		case 35:
			return Character.RIN;
		case 36:
			return Character.RIN;
		case 37:
			return Character.RIN;
		case 38:
			return Character.RIN;
		case 39:
			return Character.LEN;
		case 4:
			return Character.MIK;
		case 40:
			return Character.LEN;
		case 41:
			return Character.LEN;
		case 42:
			return Character.LEN;
		case 43:
			return Character.LEN;
		case 44:
			return Character.LEN;
		case 45:
			return Character.LEN;
		case 46:
			return Character.LEN;
		case 47:
			return Character.LEN;
		case 48:
			return Character.LEN;
		case 49:
			return Character.LEN;
		case 5:
			return Character.MIK;
		case 50:
			return Character.MEI;
		case 51:
			return Character.LUK;
		case 52:
			return Character.LUK;
		case 53:
			return Character.LUK;
		case 54:
			return Character.LUK;
		case 55:
			return Character.LUK;
		case 56:
			return Character.LUK;
		case 57:
			return Character.LUK;
		case 58:
			return Character.LUK;
		case 59:
			return Character.LUK;
		case 6:
			return Character.MIK;
		case 60:
			return Character.LUK;
		case 61:
			return Character.LUK;
		case 62:
			return Character.KAI;
		case 63:
			return Character.KAI;
		case 64:
			return Character.KAI;
		case 65:
			return Character.KAI;
		case 66:
			return Character.KAI;
		case 67:
			return Character.KAI;
		case 68:
			return Character.KAI;
		case 69:
			return Character.KAI;
		case 7:
			return Character.MIK;
		case 70:
			return Character.MEI;
		case 71:
			return Character.MEI;
		case 72:
			return Character.MEI;
		case 73:
			return Character.MEI;
		case 74:
			return Character.MEI;
		case 75:
			return Character.MEI;
		case 76:
			return Character.MEI;
		case 77:
			return Character.MEI;
		case 194:
			return Character.MEI;
		case 204:
			return Character.MEI;
		case 241:
			return Character.MEI;
		case 238:
			return Character.MEI;
		case 239:
			return Character.MEI;
		case 240:
			return Character.MEI;
		case 78:
			return Character.SAK;
		case 79:
			return Character.LEN;
		case 8:
			return Character.MIK;
		case 80:
			return Character.KAI;
		case 82:
			return Character.MIK;
		case 83:
			return Character.RIN;
		case 84:
			return Character.LEN;
		case 85:
			return Character.LUK;
		case 86:
			return Character.MEI;
		case 87:
			return Character.KAI;
		case 88:
			return Character.MIK;
		case 89:
			return Character.RIN;
		case 90:
			return Character.LEN;
		case 9:
			return Character.MIK;
		case 91:
			return Character.MIK;
		case 92:
			return Character.RIN;
		case 93:
			return Character.LUK;
		case 94:
			return Character.MIK;
		case 98:
			return Character.MIK;
		case 99:
			return Character.MIK;
		case 100:
			return Character.RIN;
		case 101:
			return Character.MIK;
		case 102:
			return Character.MIK;
		case 103:
			return Character.MIK;
		case 95:
			return Character.NER;
		case 244:
			return Character.NER;
		case 195:
			return Character.NER;
		case 96:
			return Character.HAK;
		case 245:
			return Character.HAK;
		case 196:
			return Character.HAK;
		case 187:
			return Character.HAK;
		case 97:
			return Character.TET;
		case 242:
			return Character.TET;
		case 247:
			return Character.TET;
		case 197:
			return Character.SAK;
		case 246:
			return Character.SAK;
		case 81:
		case 243:
			break;
		}
		return Character.EXTRA;
	}
}
