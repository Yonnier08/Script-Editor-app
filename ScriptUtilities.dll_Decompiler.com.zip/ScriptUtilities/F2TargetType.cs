namespace ScriptUtilities;

public enum F2TargetType
{
	sankaku = 0,
	maru = 1,
	batsu = 2,
	shikaku = 3,
	sankaku_w = 4,
	maru_w = 5,
	batsu_w = 6,
	shikaku_w = 7,
	sankaku_long = 8,
	maru_long = 9,
	batsu_long = 10,
	shikaku_long = 11,
	touch = 12,
	touch_w = 14,
	touch_ch1 = 15,
	touch_ch0 = 16,
	touch_link = 22,
	touch_link_end = 23,
	sankaku_touch = 18,
	maru_touch = 19,
	batsu_touch = 20,
	shikaku_touch = 21,
	touch_rush = 17,
	sankaku_rush = 25,
	maru_rush = 26,
	batsu_rush = 27,
	shikaku_rush = 28
}
