using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Xml.Serialization;

namespace ScriptUtilities;

public class Settings
{
	public struct FieldEntry
	{
		public string InputField;

		public List<string> OutputFields;

		public FieldEntry(string input, List<string> output)
		{
			InputField = input;
			OutputFields = output;
		}
	}

	public struct MotionEntry
	{
		public string InputMotion;

		public string OutputMotion;

		public MotionEntry(string input, string output)
		{
			InputMotion = input;
			OutputMotion = output;
		}
	}

	public static Settings UserSettings = new Settings();

	public const string FileName = "UserConfig.xml";

	public static string ConfigPath => Directory + "\\UserConfig.xml";

	public static string Directory => Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

	public List<FieldEntry> FieldLookup { get; set; } = new List<FieldEntry>();


	public List<MotionEntry> MotionLookup { get; set; } = new List<MotionEntry>();


	public void SaveSettings()
	{
		XmlSerializer xmlSerializer = new XmlSerializer(GetType());
		XmlSerializerNamespaces xmlSerializerNamespaces = new XmlSerializerNamespaces();
		xmlSerializerNamespaces.Add(string.Empty, string.Empty);
		using FileStream stream = new FileStream(ConfigPath, FileMode.Create, FileAccess.Write);
		xmlSerializer.Serialize(stream, this, xmlSerializerNamespaces);
	}

	public static Settings TryLoadSettings()
	{
		try
		{
			if (!File.Exists(ConfigPath))
			{
				File.Create(ConfigPath);
			}
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(Settings));
			using MemoryStream stream = new MemoryStream(File.ReadAllBytes(ConfigPath));
			return (Settings)xmlSerializer.Deserialize(stream);
		}
		catch (Exception)
		{
			return new Settings();
		}
	}
}
