namespace ScriptUtilities;

public enum FtHand : uint
{
	開いた手 = 0u,
	閉じた手 = 1u,
	通常 = 2u,
	ピース = 3u,
	ネギ持ち = 4u,
	グッド = 5u,
	一本指差し = 6u,
	自然 = 7u,
	三本指立て = 10u,
	手刀 = 15u,
	リセット = 14u,
	グー = 8u,
	ハート = 17u,
	パー = 18u,
	指鉄砲_2本 = 19u,
	指鉄砲_1本 = 20u,
	つまむ = 21u,
	オーケー = 22u,
	キツネ = 23u,
	手の器 = 24u
}
